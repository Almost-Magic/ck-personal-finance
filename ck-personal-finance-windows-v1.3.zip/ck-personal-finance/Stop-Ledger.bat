@echo off
cd /d "%~dp0"
set "PY=%~dp0runtime\python\ck-ledger.exe"

"%PY%" "%~dp0wait_stopped.py" check
if %errorlevel%==0 goto NOTRUNNING

if not exist "%~dp0data\shutdown.token" goto MANUAL
set /p TOKEN=<"%~dp0data\shutdown.token"
for /f %%C in ('curl.exe -s -o nul -w "%%{http_code}" -X POST -H "X-CKPF-Stop-Token: %TOKEN%" http://127.0.0.1:5002/api/personal-finance/shutdown 2^>nul') do set "CODE=%%C"
if not "%CODE%"=="200" goto MANUAL

"%PY%" "%~dp0wait_stopped.py" wait
if %errorlevel%==0 goto STOPPED
echo WARNING: the app accepted the stop request but something still listens on port 5002.
goto END

:NOTRUNNING
echo The app is not running. Nothing to stop.
goto END

:STOPPED
echo Stopped. Verified: nothing is listening on port 5002 any more.
goto END

:MANUAL
echo Automatic stop is not available for this run (the app did not recognise this folder).
echo Close the "CK Personal Finance" window yourself - that always stops the app.
echo Then run this file again to confirm.
pause
exit /b 1

:END
pause
