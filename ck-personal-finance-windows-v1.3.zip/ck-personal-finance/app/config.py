"""Application configuration."""
import os
from pathlib import Path

PORT = int(os.environ.get("PORT", "5002"))
APP_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.environ.get("CKPF_DATA_DIR", str(APP_ROOT / "data"))).expanduser()
if not DATA_DIR.is_absolute():
    DATA_DIR = APP_ROOT / DATA_DIR
DATA_DIR = DATA_DIR.resolve()
DATABASE_PATH = str(DATA_DIR / "ledger.db")


def init_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "uploads").mkdir(exist_ok=True)


STOP_TOKEN_FILE = os.environ.get("CKPF_STOP_TOKEN_FILE", "")
_stop_token = None


def get_stop_token():
    """Per-launch token that authenticates THIS instance for local shutdown.

    Enabled only when CKPF_STOP_TOKEN_FILE is set (the Windows giveaway
    launcher sets it to <data>/shutdown.token). The long-running VPS demo
    leaves it unset, which disables the shutdown endpoint entirely.
    Possession of the token - readable only from this instance's own data
    folder - is what proves identity; no PID or image-name guessing.
    """
    global _stop_token
    if not STOP_TOKEN_FILE:
        return None
    if _stop_token is None:
        import secrets
        _stop_token = secrets.token_urlsafe(32)
        p = Path(STOP_TOKEN_FILE)
        p.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            fh.write(_stop_token + "\n")
    return _stop_token
