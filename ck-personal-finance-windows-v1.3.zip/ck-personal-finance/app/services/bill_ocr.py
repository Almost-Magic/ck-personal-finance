"""Local OCR for bills and scanned documents (proposal 1, approved 25 Oct 2026).

Tesseract on this machine only - no cloud OCR, no external calls, which fits
the local-only ruling. Extracted vendor, amount and due date are UNVERIFIED
suggestions: they become data only when the owner confirms them. The source
image and a per-field extraction receipt (context line) are kept for every
field. No handwriting promises; amounts are never auto-trusted.

Retention: ocr_extractions and ocr_field_suggestions are retained audit
records - the owner-confirm flow only transitions status
(unverified -> confirmed/discarded) and records the confirmed value. Uploaded
files are stored local-only under data/uploads/ocr/ (mode 0600). These rows
are never routine cleanup.
"""
from __future__ import annotations

import json
import re
import sqlite3
import subprocess
import sys
import time
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from app.config import DATA_DIR, APP_ROOT

DB_PATH = DATA_DIR / "personal-finance.sqlite3"
OCR_ROOT = DATA_DIR / "uploads" / "ocr"
MAX_OCR_BYTES = 15 * 1024 * 1024
MAX_PDF_PAGES = 3
OCR_TIMEOUT_SECONDS = 90

_IMAGE_SUFFIXES = {"png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp"}
_PDF_SUFFIX = "pdf"

_DDL = """
CREATE TABLE IF NOT EXISTS ocr_extractions(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  original_filename TEXT NOT NULL,
  stored_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size_bytes INTEGER NOT NULL,
  pages_processed INTEGER NOT NULL DEFAULT 1,
  raw_text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unverified',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ocr_field_suggestions(
  id INTEGER PRIMARY KEY,
  extraction_id INTEGER NOT NULL REFERENCES ocr_extractions(id) ON DELETE CASCADE,
  field TEXT NOT NULL,
  suggested_value TEXT NOT NULL,
  context_line TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  confirmed_value TEXT,
  created_at TEXT NOT NULL
);
"""

_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}

_DUE_HINT = re.compile(r"due|pay\s*by|payment\s*date|payable|before|remit", re.I)
_TOTAL_HINT = re.compile(r"total|amount\s*due|balance\s*due|current\s*charges|new\s*charges|pay\s*this", re.I)
_AMOUNT_RE = re.compile(r"\$?\s*(\d{1,3}(?:,\d{3})*\.\d{2})\b")
_DATE_RES = [
    re.compile(r"\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})\b"),
    re.compile(r"\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b"),
    re.compile(r"\b([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})\b"),
    re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"),
]

_SKIP_VENDOR_LINE = re.compile(
    r"^\s*(tax\s+invoice|invoice|bill|statement|page\s+\d|abn|a\.c\.n|account\s+(number|no)|"
    r"customer\s+(number|no)|bill\s+summary|payment\s+slip|remittance)\b", re.I)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_ocr_store() -> None:
    OCR_ROOT.mkdir(parents=True, exist_ok=True)
    conn = _conn()
    try:
        conn.executescript(_DDL)
        conn.commit()
    finally:
        conn.close()


def _profile_id(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    if row:
        return row["id"]
    cur = conn.execute("INSERT INTO personal_profiles(name) VALUES ('Local user')")
    return int(cur.lastrowid)


def _path_has_symlink(path: Path, stop: Path) -> bool:
    """True when path or any ancestor up to and including stop is a symlink."""
    current = Path(path)
    stop = Path(stop)
    while True:
        if current.is_symlink():
            return True
        if current == stop or current.parent == current:
            return False
        current = current.parent


def _tesseract_command(*args: str) -> list[str]:
    bundle = APP_ROOT / "runtime" / "ocr"
    # PATH fallback is allowed only when no bundled directory exists at all.
    # Any symlinked component from the bundle up to APP_ROOT (for example a
    # symlinked runtime/ directory) is refused rather than followed.
    if _path_has_symlink(bundle, APP_ROOT):
        raise RuntimeError("Bundled OCR directory must not contain symlinks.")
    if not bundle.exists():
        return ["tesseract", *args]
    required = ["bin/tesseract.exe", "bin/libtesseract55.dll", "bin/libleptonica-1.87.0.dll",
                "bin/libpng16.dll", "bin/libz.dll", "bin/libc++.dll", "bin/libunwind.dll",
                "tessdata/eng.traineddata", "INVENTORY.json"]
    for name in required:
        target = bundle / name
        if _path_has_symlink(target, bundle) or not target.is_file():
            raise RuntimeError("Bundled OCR is missing or invalid. Reinstall the full reviewed bundle.")
    return [str(bundle / "bin/tesseract.exe"), *args, "--tessdata-dir", str(bundle / "tessdata")]


def _run(cmd: list[str], timeout: float = OCR_TIMEOUT_SECONDS) -> str:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        raise RuntimeError("OCR tool failed: %s" % (proc.stderr.strip() or proc.args[0]))
    return proc.stdout


def ocr_available() -> dict[str, Any]:
    try:
        out = _run(_tesseract_command("--version"))
        version = out.splitlines()[0] if out else "tesseract"
        return {"available": True, "engine": version.strip(), "mode": "local_only"}
    except (FileNotFoundError, RuntimeError, subprocess.TimeoutExpired):
        return {"available": False, "engine": None, "mode": "local_only",
                "reason": "The local tesseract package is not installed on this machine."}


def _extract_text(stored: Path, suffix: str) -> tuple[str, int]:
    """Render and OCR under one 90s tool budget; always remove raster files.

    Subprocess separation is not an OS sandbox. Storage/field parsing outside
    this function is not included in the render/OCR tool deadline.
    """
    deadline = time.monotonic() + OCR_TIMEOUT_SECONDS

    def run_before_deadline(cmd):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RuntimeError("Local OCR render/read deadline exceeded.")
        return _run(cmd, timeout=remaining)

    if suffix == _PDF_SUFFIX:
        prefix = stored.parent / (stored.stem + "-page")
        images = []
        try:
            run_before_deadline([sys.executable, str(Path(__file__).with_name("pdf_render_worker.py")),
                                 str(stored), str(prefix), str(MAX_PDF_PAGES)])
            images = sorted(stored.parent.glob(stored.stem + "-page-*.png"))[:MAX_PDF_PAGES]
            if not images:
                raise ValueError("The PDF produced no pages to read.")
            texts = [run_before_deadline(_tesseract_command(str(img), "stdout", "--psm", "6"))
                     for img in images]
            return "\n".join(texts), len(images)
        except FileNotFoundError:
            raise RuntimeError("The local tesseract package is not installed on this machine, so OCR is unavailable.")
        except subprocess.TimeoutExpired:
            raise RuntimeError("Local OCR render/read deadline exceeded.")
        finally:
            for partial in stored.parent.glob(stored.stem + "-page-*.png"):
                partial.unlink(missing_ok=True)
    normal = stored.parent / (stored.stem + "-normalised")
    try:
        metadata = json.loads(run_before_deadline([sys.executable, str(Path(__file__).with_name("image_render_worker.py")),
                                                   str(stored), str(normal)]))
        images = sorted(stored.parent.glob(stored.stem + "-normalised-*.png"))[:MAX_PDF_PAGES]
        if not images:
            raise ValueError("The image produced no frames to read.")
        texts = [run_before_deadline(_tesseract_command(str(img), "stdout", "--psm", "6")) for img in images]
        if metadata["frames_total"] > len(images):
            texts.append("[Only the first %d of %d image frames were read; later frames were skipped.]"
                         % (len(images), metadata["frames_total"]))
        return "\n".join(texts), len(images)
    except FileNotFoundError:
        raise RuntimeError("The local tesseract package is not installed on this machine, so OCR is unavailable.")
    except subprocess.TimeoutExpired:
        raise RuntimeError("Local OCR render/read deadline exceeded.")
    finally:
        for partial in stored.parent.glob(stored.stem + "-normalised-*.png"):
            partial.unlink(missing_ok=True)


def _parse_amount(line: str) -> float | None:
    m = _AMOUNT_RE.findall(line)
    if not m:
        return None
    return round(float(m[-1].replace(",", "")), 2)


def _parse_date(line: str) -> str | None:
    for rx in _DATE_RES:
        m = rx.search(line)
        if not m:
            continue
        g = m.groups()
        try:
            if rx is _DATE_RES[0]:
                d, mo, y = int(g[0]), int(g[1]), int(g[2])
                if y < 100:
                    y += 2000
                if mo > 12 and d <= 12:
                    d, mo = mo, d
                return date(y, mo, d).isoformat()
            if rx is _DATE_RES[1]:
                mo = _MONTHS.get(g[1][:3].lower())
                if mo:
                    return date(int(g[2]), mo, int(g[0])).isoformat()
            if rx is _DATE_RES[2]:
                mo = _MONTHS.get(g[0][:3].lower())
                if mo:
                    return date(int(g[2]), mo, int(g[1])).isoformat()
            if rx is _DATE_RES[3]:
                return date(int(g[0]), int(g[1]), int(g[2])).isoformat()
        except ValueError:
            continue
    return None


def _suggest_fields(raw_text: str) -> list[dict[str, str]]:
    """Per-field UNVERIFIED suggestions with their context lines."""
    lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
    suggestions: list[dict[str, str]] = []

    vendor = None
    for ln in lines[:12]:
        if len(ln) < 3 or len(ln) > 60:
            continue
        if _SKIP_VENDOR_LINE.search(ln):
            continue
        if _AMOUNT_RE.search(ln) or any(rx.search(ln) for rx in _DATE_RES):
            continue
        letters = sum(ch.isalpha() for ch in ln)
        if letters >= 3 and letters / max(len(ln), 1) > 0.5:
            vendor = ln
            break
    if vendor:
        suggestions.append({"field": "vendor", "suggested_value": vendor[:120], "context_line": vendor})

    amount = None
    for ln in lines:
        if _TOTAL_HINT.search(ln):
            amt = _parse_amount(ln)
            if amt is not None:
                amount = (amt, ln)
                break
    if amount is None:
        for ln in lines:
            amt = _parse_amount(ln)
            if amt is not None and amt > 0:
                amount = (amt, ln)
                break
    if amount:
        suggestions.append({"field": "amount", "suggested_value": "%.2f" % amount[0], "context_line": amount[1]})

    due = None
    for ln in lines:
        if _DUE_HINT.search(ln):
            d = _parse_date(ln)
            if d:
                due = (d, ln)
                break
    if due is None:
        for ln in lines:
            d = _parse_date(ln)
            if d:
                due = (d, ln)
                break
    if due:
        suggestions.append({"field": "due_date", "suggested_value": due[0], "context_line": due[1]})
    return suggestions


def create_extraction(file_bytes: bytes, filename: str, content_type: str | None = None) -> dict[str, Any]:
    """Store the source file, run local OCR, record UNVERIFIED suggestions."""
    if not file_bytes:
        raise ValueError("Uploaded file was empty.")
    if len(file_bytes) > MAX_OCR_BYTES:
        raise ValueError("File is too large (15 MB max).")
    suffix = (filename or "").lower().rsplit(".", 1)[-1] if "." in (filename or "") else ""
    if suffix != _PDF_SUFFIX and suffix not in _IMAGE_SUFFIXES:
        raise ValueError("Only images (png, jpg, tiff, bmp, webp) and PDF files are accepted for OCR.")
    init_ocr_store()
    stored_name = "%s-%s" % (uuid.uuid4().hex[:12], re.sub(r"[^A-Za-z0-9_.-]", "_", filename or "scan"))
    stored = OCR_ROOT / stored_name
    stored.write_bytes(file_bytes)
    stored.chmod(0o600)
    try:
        raw_text, pages = _extract_text(stored, suffix)
    except Exception:
        stored.unlink(missing_ok=True)
        raise
    if not raw_text.strip():
        stored.unlink(missing_ok=True)
        raise ValueError("No text could be read from that file. Try a sharper photo or scan.")

    suggestions = _suggest_fields(raw_text)
    conn = _conn()
    try:
        with conn:
            pid = _profile_id(conn)
            cur = conn.execute(
                "INSERT INTO ocr_extractions(profile_id, original_filename, stored_path, file_type, file_size_bytes,"
                " pages_processed, raw_text, status, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (pid, (filename or "scan")[:200], str(stored), suffix, len(file_bytes), pages,
                 raw_text, "unverified", _now()),
            )
            extraction_id = int(cur.lastrowid)
            for s in suggestions:
                conn.execute(
                    "INSERT INTO ocr_field_suggestions(extraction_id, field, suggested_value, context_line, created_at)"
                    " VALUES (?,?,?,?,?)",
                    (extraction_id, s["field"], s["suggested_value"], s["context_line"], _now()),
                )
        return {
            "extraction_id": extraction_id,
            "status": "unverified",
            "pages_processed": pages,
            "processing_notice": next((line.strip("[]") for line in raw_text.splitlines()
                                       if line.startswith("[Only the first ")), None),
            "suggestions": suggestions,
            "fields_found": [s["field"] for s in suggestions],
            "boundary": "UNVERIFIED OCR suggestions. Nothing becomes a bill until you confirm each value. "
                        "The source file and the line each value came from are kept with it.",
            "engine": "local_tesseract",
        }
    finally:
        conn.close()


def list_extractions(limit: int = 20) -> dict[str, Any]:
    init_ocr_store()
    conn = _conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT id, original_filename, file_type, file_size_bytes, pages_processed, status, created_at"
            " FROM ocr_extractions ORDER BY id DESC LIMIT ?", (min(limit, 100),)).fetchall()]
        return {"extractions": rows}
    finally:
        conn.close()


def get_extraction(extraction_id: int) -> dict[str, Any]:
    init_ocr_store()
    conn = _conn()
    try:
        row = conn.execute(
            "SELECT id, original_filename, file_type, pages_processed, raw_text, status, created_at"
            " FROM ocr_extractions WHERE id = ?", (extraction_id,)).fetchone()
        if not row:
            raise LookupError("OCR extraction %s not found." % extraction_id)
        fields = [dict(r) for r in conn.execute(
            "SELECT id, field, suggested_value, context_line, verified, confirmed_value"
            " FROM ocr_field_suggestions WHERE extraction_id = ? ORDER BY id", (extraction_id,)).fetchall()]
        d = dict(row)
        d["fields"] = fields
        return d
    finally:
        conn.close()


def confirm_extraction(extraction_id: int, vendor: str, amount: float | None,
                       due_date: str, note: str = "") -> dict[str, Any]:
    """Owner confirms values -> becomes a bill (source='ocr'). Values may differ
    from the suggestions; what the owner types is what is stored."""
    from app.services.bills import _insert_bill, _row_dict, _validate, init_bills_store

    init_ocr_store()
    init_bills_store()
    vendor, amt, due = _validate(vendor, amount, due_date)
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM ocr_extractions WHERE id = ?", (extraction_id,)).fetchone()
        if not row:
            raise LookupError("OCR extraction %s not found." % extraction_id)
        if row["status"] == "confirmed":
            raise ValueError("That extraction was already confirmed into a bill.")
        if row["status"] == "discarded":
            raise ValueError("That extraction was discarded.")
        with conn:
            conn.execute("UPDATE ocr_extractions SET status = 'confirmed' WHERE id = ?", (extraction_id,))
            for field, value in (("vendor", vendor), ("amount", None if amt is None else "%.2f" % amt), ("due_date", due)):
                existing = conn.execute(
                    "SELECT id, suggested_value FROM ocr_field_suggestions WHERE extraction_id = ? AND field = ?",
                    (extraction_id, field)).fetchone()
                if existing:
                    conn.execute(
                        "UPDATE ocr_field_suggestions SET verified = 1, confirmed_value = ? WHERE id = ?",
                        (value, existing["id"]))
                else:
                    conn.execute(
                        "INSERT INTO ocr_field_suggestions(extraction_id, field, suggested_value, context_line,"
                        " verified, confirmed_value, created_at) VALUES (?,?,?,?,1,?,?)",
                        (extraction_id, field, "", "Not detected by OCR; entered by owner.", value, _now()))
            bill_id = _insert_bill(conn, vendor, amt, due, "ocr", "ocr:%d" % extraction_id,
                                   None, note or "Confirmed from scanned document '%s'." % row["original_filename"])
            conn.execute(
                "INSERT INTO bill_events(bill_id, event_type, detail, created_at) VALUES (?,?,?,?)",
                (bill_id, "ocr_confirmed",
                 json.dumps({"extraction_id": extraction_id, "source_file": row["original_filename"]}), _now()))
        brow = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        return {"bill": _row_dict(brow), "extraction_id": extraction_id, "event": "ocr_confirmed"}
    finally:
        conn.close()


def discard_extraction(extraction_id: int) -> dict[str, Any]:
    """Owner rejects the suggestions. Source file and raw text stay on record."""
    init_ocr_store()
    conn = _conn()
    try:
        row = conn.execute("SELECT status FROM ocr_extractions WHERE id = ?", (extraction_id,)).fetchone()
        if not row:
            raise LookupError("OCR extraction %s not found." % extraction_id)
        if row["status"] != "unverified":
            raise ValueError("Only an unverified extraction can be discarded.")
        with conn:
            conn.execute("UPDATE ocr_extractions SET status = 'discarded' WHERE id = ?", (extraction_id,))
        return {"extraction_id": extraction_id, "status": "discarded"}
    finally:
        conn.close()
