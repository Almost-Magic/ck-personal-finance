"""Custom reports for CK Personal Finance (proposal 3, approved 25 Oct 2026).

Picker first: the owner chooses measures, one dimension, filters and a date
range, and gets a table. Every total drills down to its underlying
transactions, so a report can never hide a wrong number. Drag-and-drop layout
is deliberately NOT in this version - it comes only after the picker proves
out. Local-only; exports are marked not_sent. No advice wording.
"""
from __future__ import annotations

import csv
import io
import json
import sqlite3
from datetime import date, datetime, timezone
from typing import Any

from app.config import DATA_DIR

DB_PATH = DATA_DIR / "personal-finance.sqlite3"

DIMENSIONS: dict[str, dict[str, str]] = {
    "category": {"column": "t.category", "label": "Category"},
    "account": {"column": "g.name", "label": "Account"},
    "merchant": {"column": "t.description", "label": "Description"},
    "month": {"column": "substr(t.tx_date, 1, 7)", "label": "Month"},
    "week": {"column": "strftime('%Y-W%W', t.tx_date)", "label": "Week"},
    "day": {"column": "t.tx_date", "label": "Day"},
}

MEASURES: dict[str, dict[str, str]] = {
    "total_spent": {"expr": "ROUND(COALESCE(SUM(CASE WHEN t.amount < 0 THEN -t.amount END), 0), 2)", "label": "Spent"},
    "total_income": {"expr": "ROUND(COALESCE(SUM(CASE WHEN t.amount > 0 THEN t.amount END), 0), 2)", "label": "Income"},
    "net": {"expr": "ROUND(COALESCE(SUM(t.amount), 0), 2)", "label": "Net"},
    "count": {"expr": "COUNT(*)", "label": "Transactions"},
}

MAX_FILTER_LIST = 40
MAX_ROWS = 500


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _profile_id(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    return int(row["id"]) if row else 1


def fields_catalog() -> dict[str, Any]:
    """What the picker may offer - the whole public contract of this module."""
    conn = _conn()
    try:
        categories = [r["c"] for r in conn.execute(
            "SELECT DISTINCT t.category AS c FROM personal_transactions t"
            " JOIN personal_account_groups g ON g.id = t.account_group_id AND COALESCE(g.demo_hidden,0)=0"
            " ORDER BY c").fetchall()]
        accounts = [r["a"] for r in conn.execute(
            "SELECT DISTINCT g.name AS a FROM personal_account_groups g"
            " JOIN personal_transactions t ON t.account_group_id = g.id"
            " WHERE COALESCE(g.demo_hidden,0)=0 ORDER BY a").fetchall()]
        bounds = conn.execute("SELECT MIN(tx_date) AS lo, MAX(tx_date) AS hi FROM personal_transactions").fetchone()
    finally:
        conn.close()
    return {
        "dimensions": [{"id": k, "label": v["label"]} for k, v in DIMENSIONS.items()],
        "measures": [{"id": k, "label": v["label"]} for k, v in MEASURES.items()],
        "filters": {
            "date_from": "YYYY-MM-DD (optional)",
            "date_to": "YYYY-MM-DD (optional)",
            "categories": categories,
            "accounts": accounts,
            "direction": ["all", "debit", "credit"],
            "search": "text in description (optional)",
        },
        "data_range": {"from": bounds["lo"], "to": bounds["hi"]},
        "boundary": "Drag-and-drop layouts are not in this version; the picker table comes first. "
                    "Every total can be opened to its exact transactions.",
    }


def _validate_spec(spec: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(spec, dict):
        raise ValueError("Report spec must be an object.")
    dimension = spec.get("dimension", "category")
    if dimension not in DIMENSIONS:
        raise ValueError("Unknown dimension '%s'. Choose one of: %s." % (dimension, ", ".join(sorted(DIMENSIONS))))
    measures = spec.get("measures") or ["total_spent", "count"]
    if not isinstance(measures, list) or not measures or len(measures) > len(MEASURES):
        raise ValueError("Choose between 1 and %d measures." % len(MEASURES))
    for m in measures:
        if m not in MEASURES:
            raise ValueError("Unknown measure '%s'. Choose from: %s." % (m, ", ".join(sorted(MEASURES))))

    filters = spec.get("filters") or {}
    if not isinstance(filters, dict):
        raise ValueError("Filters must be an object.")
    clean: dict[str, Any] = {}
    for key in ("date_from", "date_to"):
        value = filters.get(key)
        if value:
            try:
                clean[key] = date.fromisoformat(str(value).strip()).isoformat()
            except ValueError:
                raise ValueError("%s must be YYYY-MM-DD." % key)
    if clean.get("date_from") and clean.get("date_to") and clean["date_from"] > clean["date_to"]:
        raise ValueError("date_from must not be after date_to.")
    for key in ("categories", "accounts"):
        value = filters.get(key)
        if value:
            if not isinstance(value, list) or len(value) > MAX_FILTER_LIST:
                raise ValueError("%s must be a list of at most %d values." % (key, MAX_FILTER_LIST))
            clean[key] = [str(v)[:120] for v in value]
    direction = filters.get("direction", "all")
    if direction not in ("all", "debit", "credit"):
        raise ValueError("direction must be all, debit or credit.")
    if direction != "all":
        clean["direction"] = direction
    search = filters.get("search")
    if search:
        clean["search"] = str(search)[:80]
    return {"dimension": dimension, "measures": measures, "filters": clean}


def _where(filters: dict[str, Any], params: list[Any]) -> str:
    clauses = ["COALESCE(g.demo_hidden,0)=0"]
    if filters.get("date_from"):
        clauses.append("t.tx_date >= ?")
        params.append(filters["date_from"])
    if filters.get("date_to"):
        clauses.append("t.tx_date <= ?")
        params.append(filters["date_to"])
    if filters.get("categories"):
        clauses.append("t.category IN (%s)" % ",".join("?" * len(filters["categories"])))
        params.extend(filters["categories"])
    if filters.get("accounts"):
        clauses.append("g.name IN (%s)" % ",".join("?" * len(filters["accounts"])))
        params.extend(filters["accounts"])
    if filters.get("direction") == "debit":
        clauses.append("t.amount < 0")
    if filters.get("direction") == "credit":
        clauses.append("t.amount > 0")
    if filters.get("search"):
        clauses.append("LOWER(t.description) LIKE ?")
        params.append("%" + filters["search"].lower() + "%")
    return " AND ".join(clauses)


def run_custom_report(spec: dict[str, Any], record_receipt: bool = True) -> dict[str, Any]:
    clean = _validate_spec(spec)
    dim = DIMENSIONS[clean["dimension"]]
    params: list[Any] = []
    where = _where(clean["filters"], params)
    measure_cols = ", ".join("%s AS %s" % (MEASURES[m]["expr"], m) for m in clean["measures"])
    sql = (
        "SELECT %s AS bucket, %s FROM personal_transactions t"
        " JOIN personal_account_groups g ON g.id = t.account_group_id"
        " WHERE %s GROUP BY bucket ORDER BY bucket LIMIT %d"
    ) % (dim["column"], measure_cols, where, MAX_ROWS + 1)
    conn = _conn()
    try:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        total_params: list[Any] = []
        total_where = _where(clean["filters"], total_params)
        total_sql = "SELECT %s FROM personal_transactions t JOIN personal_account_groups g ON g.id = t.account_group_id WHERE %s" % (
            measure_cols, total_where)
        totals = dict(conn.execute(total_sql, total_params).fetchone())
        truncated = len(rows) > MAX_ROWS
        rows = rows[:MAX_ROWS]
        receipt_id = None
        if record_receipt:
            with conn:
                cur = conn.execute(
                    "INSERT INTO report_exports(profile_id, report_type, title, payload, source_refs, external_send_state)"
                    " VALUES (?,?,?,?,?,?)",
                    (_profile_id(conn), "custom",
                     "Custom report: %s by %s" % (", ".join(clean["measures"]), clean["dimension"]),
                     json.dumps({"spec": clean, "rows": len(rows), "truncated": truncated}),
                     json.dumps(["personal_transactions"]), "not_sent"))
                receipt_id = int(cur.lastrowid)
    finally:
        conn.close()
    return {
        "dimension": clean["dimension"],
        "dimension_label": dim["label"],
        "measures": [{"id": m, "label": MEASURES[m]["label"]} for m in clean["measures"]],
        "filters": clean["filters"],
        "rows": rows,
        "totals": totals,
        "row_count": len(rows),
        "truncated": truncated,
        "receipt_id": receipt_id,
        "external_send_state": "not_sent",
        "drilldown": "POST /api/personal-finance/reports/custom/drilldown with the same spec plus bucket value",
        "generated_at": _now(),
    }


def drilldown_custom_report(spec: dict[str, Any], bucket: str, limit: int = 200) -> dict[str, Any]:
    """The exact transactions behind one table row - a total can never hide
    a wrong number."""
    clean = _validate_spec(spec)
    dim = DIMENSIONS[clean["dimension"]]
    params: list[Any] = []
    where = _where(clean["filters"], params)
    where += " AND %s = ?" % dim["column"]
    params.append(str(bucket))
    sql = (
        "SELECT t.id, t.tx_date, t.description, t.amount, t.category, g.name AS account_name"
        " FROM personal_transactions t JOIN personal_account_groups g ON g.id = t.account_group_id"
        " WHERE %s ORDER BY t.tx_date DESC, t.id DESC LIMIT %d"
    ) % (where, min(limit, 500))
    conn = _conn()
    try:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()
    return {
        "dimension": clean["dimension"],
        "bucket": str(bucket),
        "transactions": rows,
        "count": len(rows),
        "note": "These exact rows add up to the report line you opened.",
    }


def custom_report_csv(spec: dict[str, Any]) -> str:
    result = run_custom_report(spec, record_receipt=False)
    buf = io.StringIO()
    writer = csv.writer(buf)
    header = [result["dimension_label"]] + [m["label"] for m in result["measures"]]
    writer.writerow(["CK Personal Finance custom report - local only, not sent"])
    writer.writerow(["Generated", result["generated_at"]])
    writer.writerow(["Filters", json.dumps(result["filters"])])
    writer.writerow([])
    writer.writerow(header)
    for row in result["rows"]:
        writer.writerow([row["bucket"]] + [row[m["id"]] for m in result["measures"]])
    writer.writerow([])
    writer.writerow(["Total"] + [result["totals"][m["id"]] for m in result["measures"]])
    if result["truncated"]:
        writer.writerow(["Note", "Row limit reached; narrow the date range or filters for the full table."])
    return buf.getvalue()


def custom_report_pdf(spec: dict[str, Any]) -> bytes:
    """PDF via reportlab (the existing export dependency), same table."""
    result = run_custom_report(spec, record_receipt=False)
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    except ImportError:
        raise RuntimeError("PDF export needs the reportlab package, which is not installed in this environment.")
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph("<b>CK Personal Finance</b>", styles["Title"]),
        Paragraph("Custom report - %s by %s" % (", ".join(m["label"] for m in result["measures"]), result["dimension_label"]), styles["Heading2"]),
        Paragraph("Local only. Not sent anywhere. Generated %s" % result["generated_at"], styles["Normal"]),
        Spacer(1, 12),
    ]
    header = [result["dimension_label"]] + [m["label"] for m in result["measures"]]
    data = [header]
    for row in result["rows"]:
        data.append([str(row["bucket"])] + [str(row[m["id"]]) for m in result["measures"]])
    data.append(["Total"] + [str(result["totals"][m["id"]]) for m in result["measures"]])
    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#ecf0f1")),
    ]))
    elements.append(table)
    if result["truncated"]:
        elements.append(Spacer(1, 8))
        elements.append(Paragraph("Row limit reached; narrow the date range or filters for the full table.", styles["Normal"]))
    doc.build(elements)
    return buffer.getvalue()
