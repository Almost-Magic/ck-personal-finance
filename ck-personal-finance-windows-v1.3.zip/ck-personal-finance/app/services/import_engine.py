# Author: Mani Padisetti
"""Import engine service — CSV/OFX parsing, dedup, categorisation."""

import csv
import hashlib
import io
import json
import re
from datetime import datetime

from app.database import get_db


def _parse_date(date_str: str) -> str | None:
    """Parse Australian date formats to YYYY-MM-DD."""
    date_str = date_str.strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%y", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _detect_columns(headers: list[str]) -> dict:
    """Auto-detect CSV column mapping."""
    mapping = {}
    lower_headers = [h.lower().strip() for h in headers]

    date_patterns = ["date", "transaction date", "trans date", "value date"]
    desc_patterns = ["description", "narrative", "details", "memo", "transaction description", "particulars"]
    amount_patterns = ["amount", "value", "total"]
    debit_patterns = ["debit", "withdrawal", "dr"]
    credit_patterns = ["credit", "deposit", "cr"]
    balance_patterns = ["balance", "running balance"]
    ref_patterns = ["reference", "ref", "cheque no", "check"]

    for i, h in enumerate(lower_headers):
        if not mapping.get("date") and any(p == h or p in h for p in date_patterns):
            mapping["date"] = i
        elif not mapping.get("description") and any(p == h or p in h for p in desc_patterns):
            mapping["description"] = i
        elif not mapping.get("debit") and any(p == h for p in debit_patterns):
            mapping["debit"] = i
        elif not mapping.get("credit") and any(p == h for p in credit_patterns):
            mapping["credit"] = i
        elif not mapping.get("amount") and any(p == h or p in h for p in amount_patterns):
            mapping["amount"] = i
        elif not mapping.get("balance") and any(p == h or p in h for p in balance_patterns):
            mapping["balance"] = i
        elif not mapping.get("reference") and any(p == h or p in h for p in ref_patterns):
            mapping["reference"] = i

    return mapping


def _dedup_hash(date: str, amount: float, description: str) -> str:
    """Generate duplicate detection hash."""
    raw = f"{date}|{amount}|{description}".lower()
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def parse_csv(content: str, filename: str) -> dict:
    """Parse CSV content and return preview data."""
    reader = csv.reader(io.StringIO(content))
    rows = list(reader)
    if not rows:
        return {"error": "Empty CSV file"}

    headers = rows[0]
    col_map = _detect_columns(headers)
    if "date" not in col_map or "description" not in col_map:
        return {"error": "Could not detect date and description columns",
                "headers": headers}

    has_split_amounts = "debit" in col_map and "credit" in col_map
    has_amount = "amount" in col_map

    if not has_split_amounts and not has_amount:
        return {"error": "Could not detect amount column", "headers": headers}

    preview = []
    duplicates = 0

    with get_db() as conn:
        for row in rows[1:]:
            if not row or all(c.strip() == "" for c in row):
                continue

            date_raw = row[col_map["date"]].strip()
            date = _parse_date(date_raw)
            if not date:
                continue

            description = row[col_map["description"]].strip()
            if not description:
                continue

            if has_split_amounts:
                debit = row[col_map["debit"]].strip().replace(",", "").replace("$", "")
                credit = row[col_map["credit"]].strip().replace(",", "").replace("$", "")
                debit_val = float(debit) if debit else 0
                credit_val = float(credit) if credit else 0
                amount = credit_val - debit_val if credit_val else -debit_val
            else:
                amount_str = row[col_map["amount"]].strip().replace(",", "").replace("$", "")
                amount = float(amount_str) if amount_str else 0

            balance = None
            if "balance" in col_map:
                bal_str = row[col_map["balance"]].strip().replace(",", "").replace("$", "")
                balance = float(bal_str) if bal_str else None

            reference = None
            if "reference" in col_map:
                reference = row[col_map["reference"]].strip() or None

            dup_hash = _dedup_hash(date, amount, description)
            is_duplicate = conn.execute(
                "SELECT COUNT(*) FROM transactions WHERE date = ? AND amount = ? AND description = ?",
                (date, amount, description),
            ).fetchone()[0] > 0

            if is_duplicate:
                duplicates += 1

            # Try rule-based categorisation
            category, account_id = _apply_rules(conn, description)

            preview.append({
                "date": date,
                "description": description,
                "amount": round(amount, 2),
                "balance": balance,
                "reference": reference,
                "hash": dup_hash,
                "is_duplicate": is_duplicate,
                "category": category,
                "account_id": account_id,
            })

    # Store preview in import batch
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO import_batches (filename, file_type, total_rows, duplicates, preview_data)
            VALUES (?, 'csv', ?, ?, ?)""",
            (filename, len(preview), duplicates, json.dumps(preview)),
        )
        batch_id = cursor.lastrowid

    return {
        "batch_id": batch_id,
        "filename": filename,
        "total_rows": len(preview),
        "duplicates": duplicates,
        "new_rows": len(preview) - duplicates,
        "columns_detected": {k: headers[v] for k, v in col_map.items()},
        "preview": preview[:20],
    }


def _apply_rules(conn, description: str) -> tuple[str | None, int | None]:
    """Apply mapping rules to categorise a transaction."""
    rules = conn.execute(
        "SELECT * FROM mapping_rules WHERE is_active = 1 ORDER BY priority DESC, id"
    ).fetchall()
    for rule in rules:
        if re.search(rule["pattern"], description, re.IGNORECASE):
            return rule["category"], rule["account_id"]
    return None, None


def confirm_import(batch_id: int) -> dict:
    """Confirm and create transactions from a preview batch."""
    with get_db() as conn:
        batch = conn.execute("SELECT * FROM import_batches WHERE id = ?", (batch_id,)).fetchone()
        if not batch:
            return {"error": "Import batch not found"}
        if batch["status"] != "preview":
            return {"error": f"Batch is already {batch['status']}"}

        preview = json.loads(batch["preview_data"])
        imported = 0
        skipped = 0

        for item in preview:
            if item["is_duplicate"]:
                skipped += 1
                continue

            conn.execute(
                """INSERT INTO transactions
                (date, description, amount, balance, reference, source, category, account_id)
                VALUES (?, ?, ?, ?, ?, 'import', ?, ?)""",
                (item["date"], item["description"], item["amount"],
                 item.get("balance"), item.get("reference"),
                 item.get("category"), item.get("account_id")),
            )
            imported += 1

        conn.execute(
            """UPDATE import_batches SET status = 'confirmed', imported = ?,
            skipped = ?, confirmed_at = datetime('now') WHERE id = ?""",
            (imported, skipped, batch_id),
        )

    return {
        "batch_id": batch_id,
        "imported": imported,
        "skipped": skipped,
        "total": len(preview),
    }


async def ai_categorise(descriptions: list[str]) -> dict:
    return {"categories": [{"description": desc, "category": _basic_categorise(desc)}
                           for desc in descriptions], "generated": False,
            "message": "AI feature not in this build"}


def _basic_categorise(description: str) -> str:
    """Simple rule-based categorisation fallback."""
    desc = description.lower()
    if any(w in desc for w in ["salary", "wages", "payroll"]):
        return "wages"
    if any(w in desc for w in ["rent", "lease"]):
        return "rent"
    if any(w in desc for w in ["electricity", "gas", "water", "utility"]):
        return "utilities"
    if any(w in desc for w in ["insurance"]):
        return "insurance"
    if any(w in desc for w in ["fuel", "petrol", "diesel"]):
        return "motor vehicle"
    if any(w in desc for w in ["interest", "bank fee", "monthly fee"]):
        return "bank charges"
    if any(w in desc for w in ["ato", "tax", "gst", "bas"]):
        return "tax"
    if any(w in desc for w in ["transfer", "tfr"]):
        return "transfer"
    return "uncategorised"
