"""Bills register for CK Personal Finance: vendor, amount, due date, status.

Local-only; no external sends, no advice. Feeds: manual entry, the existing
recurring-payment detection (adopted by the owner), and confirmed OCR
suggestions. Status (upcoming/due/overdue/paid) is derived from the calendar
at read time; "paid" is the only stored state. Ordering is pure organisation
(option A: due date, then overdue state, then amount) - no recommendation
wording anywhere.

Retention: bill_events rows are an append-only audit trail
(created/updated/paid/reopened/deleted). The app never updates or deletes
event rows; deleting a bill records a final "deleted" event. There is no hash
chaining - integrity is plain row retention, so these rows are never routine
cleanup.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import date, datetime, timezone
from typing import Any

from app.config import DATA_DIR

DB_PATH = DATA_DIR / "personal-finance.sqlite3"

_DDL = """
CREATE TABLE IF NOT EXISTS bills(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  vendor TEXT NOT NULL,
  amount REAL,
  due_date TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual',
  source_ref TEXT NOT NULL DEFAULT '',
  cadence TEXT,
  note TEXT NOT NULL DEFAULT '',
  paid_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bill_events(
  id INTEGER PRIMARY KEY,
  bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
"""

_SOURCES = {"manual", "recurring", "ocr"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_bills_store() -> None:
    conn = _conn()
    try:
        conn.executescript(_DDL)
        conn.commit()
    finally:
        conn.close()


def _profile_id(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    if row:
        return row["id"]
    cur = conn.execute("INSERT INTO personal_profiles(name) VALUES ('Local user')")
    return int(cur.lastrowid)


def _status(bill: sqlite3.Row | dict, today: date | None = None) -> str:
    if bill["paid_at"]:
        return "paid"
    today = today or date.today()
    due = date.fromisoformat(bill["due_date"])
    if due < today:
        return "overdue"
    if due == today:
        return "due"
    return "upcoming"


def _row_dict(row: sqlite3.Row, today: date | None = None) -> dict[str, Any]:
    d = dict(row)
    d["status"] = _status(row, today)
    d["amount"] = None if d["amount"] is None else round(float(d["amount"]), 2)
    return d


def _event(conn: sqlite3.Connection, bill_id: int, event_type: str, detail: dict[str, Any] | None = None) -> None:
    conn.execute(
        "INSERT INTO bill_events(bill_id, event_type, detail, created_at) VALUES (?,?,?,?)",
        (bill_id, event_type, json.dumps(detail or {}), _now()),
    )


def _validate(vendor: str, amount: float | None, due_date: str) -> tuple[str, float | None, str]:
    vendor = (vendor or "").strip()
    if not vendor:
        raise ValueError("Vendor name is required.")
    if len(vendor) > 120:
        raise ValueError("Vendor name is too long (120 characters max).")
    amt = None
    if amount is not None:
        try:
            amt = round(float(amount), 2)
        except (TypeError, ValueError):
            raise ValueError("Amount must be a number.")
        if amt < 0:
            raise ValueError("Amount must be zero or positive.")
        if amt > 10_000_000:
            raise ValueError("Amount looks wrong (over 10,000,000).")
    try:
        parsed = date.fromisoformat(str(due_date).strip())
    except ValueError:
        raise ValueError("Due date must be YYYY-MM-DD.")
    return vendor, amt, parsed.isoformat()


def _insert_bill(conn: sqlite3.Connection, vendor: str, amt: float | None, due: str,
                 source: str, source_ref: str = "", cadence: str | None = None,
                 note: str = "") -> int:
    """Insert one VALIDATED bill row plus its 'created' event on the caller's
    connection, inside the caller's transaction. Returns the new bill id."""
    if source not in _SOURCES:
        raise ValueError("Unknown bill source: %s" % source)
    now = _now()
    pid = _profile_id(conn)
    cur = conn.execute(
        "INSERT INTO bills(profile_id, vendor, amount, due_date, source, source_ref, cadence, note, created_at, updated_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?)",
        (pid, vendor, amt, due, source, (source_ref or "")[:200], cadence, (note or "")[:500], now, now),
    )
    bill_id = int(cur.lastrowid)
    _event(conn, bill_id, "created", {"source": source, "source_ref": source_ref})
    return bill_id


def add_bill(vendor: str, amount: float | None, due_date: str, source: str = "manual",
             source_ref: str = "", cadence: str | None = None, note: str = "") -> dict[str, Any]:
    vendor, amt, due = _validate(vendor, amount, due_date)
    conn = _conn()
    try:
        with conn:
            bill_id = _insert_bill(conn, vendor, amt, due, source, source_ref, cadence, note)
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        return {"bill": _row_dict(row), "event": "created"}
    finally:
        conn.close()


def list_bills(include_paid: bool = True) -> dict[str, Any]:
    """Option-A ordering: unpaid first by due date, then amount; paid last.

    Pure organisation - no recommendation wording, no prioritisation labels.
    """
    today = date.today()
    conn = _conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT * FROM bills").fetchall()]
    finally:
        conn.close()
    out = []
    for r in rows:
        d = _row_dict(r, today)
        out.append(d)
    unpaid = [b for b in out if b["status"] != "paid"]
    paid = [b for b in out if b["status"] == "paid"]
    # due date ascending, then overdue before same-date others is automatic
    # (overdue dates are earliest); amount descending as final tiebreak.
    unpaid.sort(key=lambda b: (b["due_date"], -(b["amount"] or 0)))
    paid.sort(key=lambda b: (b["paid_at"] or "", b["due_date"]), reverse=True)
    ordered = unpaid + (paid if include_paid else [])
    counts = {"overdue": 0, "due": 0, "upcoming": 0, "paid": 0}
    for b in out:
        counts[b["status"]] += 1
    return {
        "bills": ordered,
        "counts": counts,
        "as_of": today.isoformat(),
        "ordering": "due_date_then_amount_organisation_only",
        "boundary": "Organisation only. No payment, reminder send, or advice is attached to this list.",
    }


def get_bill(bill_id: int) -> dict[str, Any]:
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        if not row:
            raise LookupError("Bill %s not found." % bill_id)
        events = [dict(r) for r in conn.execute(
            "SELECT id, event_type, detail, created_at FROM bill_events WHERE bill_id = ? ORDER BY id", (bill_id,)).fetchall()]
        d = _row_dict(row)
        d["events"] = events
        return d
    finally:
        conn.close()


def update_bill(bill_id: int, vendor: str | None = None, amount: float | None = None,
                due_date: str | None = None, note: str | None = None,
                clear_amount: bool = False) -> dict[str, Any]:
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        if not row:
            raise LookupError("Bill %s not found." % bill_id)
        new_vendor, new_amount, new_due = _validate(
            vendor if vendor is not None else row["vendor"],
            (None if clear_amount else (amount if amount is not None else row["amount"])),
            due_date if due_date is not None else row["due_date"],
        )
        new_note = row["note"] if note is None else note[:500]
        changes = {}
        if new_vendor != row["vendor"]:
            changes["vendor"] = [row["vendor"], new_vendor]
        if new_amount != row["amount"] and not (new_amount is None and row["amount"] is None):
            changes["amount"] = [row["amount"], new_amount]
        if new_due != row["due_date"]:
            changes["due_date"] = [row["due_date"], new_due]
        if new_note != row["note"]:
            changes["note"] = [row["note"], new_note]
        with conn:
            conn.execute(
                "UPDATE bills SET vendor = ?, amount = ?, due_date = ?, note = ?, updated_at = ? WHERE id = ?",
                (new_vendor, new_amount, new_due, new_note, _now(), bill_id),
            )
            if changes:
                _event(conn, bill_id, "updated", changes)
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        return {"bill": _row_dict(row), "changes": changes}
    finally:
        conn.close()


def mark_paid(bill_id: int) -> dict[str, Any]:
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        if not row:
            raise LookupError("Bill %s not found." % bill_id)
        if row["paid_at"]:
            return {"bill": _row_dict(row), "event": "already_paid"}
        with conn:
            conn.execute("UPDATE bills SET paid_at = ?, updated_at = ? WHERE id = ?", (_now(), _now(), bill_id))
            _event(conn, bill_id, "paid", {})
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        return {"bill": _row_dict(row), "event": "paid"}
    finally:
        conn.close()


def mark_unpaid(bill_id: int) -> dict[str, Any]:
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        if not row:
            raise LookupError("Bill %s not found." % bill_id)
        if not row["paid_at"]:
            return {"bill": _row_dict(row), "event": "already_unpaid"}
        with conn:
            conn.execute("UPDATE bills SET paid_at = NULL, updated_at = ? WHERE id = ?", (_now(), bill_id))
            _event(conn, bill_id, "reopened", {})
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        return {"bill": _row_dict(row), "event": "reopened"}
    finally:
        conn.close()


def delete_bill(bill_id: int) -> dict[str, Any]:
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM bills WHERE id = ?", (bill_id,)).fetchone()
        if not row:
            raise LookupError("Bill %s not found." % bill_id)
        with conn:
            _event(conn, bill_id, "deleted", {"vendor": row["vendor"], "due_date": row["due_date"]})
            conn.execute("DELETE FROM bills WHERE id = ?", (bill_id,))
        return {"deleted": bill_id, "vendor": row["vendor"]}
    finally:
        conn.close()


def recurring_suggestions() -> dict[str, Any]:
    """Recurring-detection feed: detected bill-kind patterns not yet adopted."""
    from app.services.recurring import detect_recurring, _normalise

    detected = [item for item in detect_recurring() if item.get("kind") == "bill"]
    conn = _conn()
    try:
        adopted = {
            (r["source_ref"] or "").lower()
            for r in conn.execute("SELECT source_ref FROM bills WHERE source = 'recurring'").fetchall()
        }
        cover = conn.execute("SELECT MAX(tx_date) AS m FROM personal_transactions").fetchone()["m"]  # latest imported transaction date, not a completeness claim
    finally:
        conn.close()
    out = []
    for item in detected:
        key = _normalise(item["merchant"]).lower()
        if key in adopted:
            continue
        out.append({
            "merchant": item["merchant"],
            "suggested_amount": item["amount"],
            "variable_amount": item["variable_amount"],
            "cadence": item["cadence"],
            "next_expected": item["next_expected"],
            "last_date": item["last_date"],
            "status": item["status"],
            "overdue_days": item["overdue_days"],
            "times_seen": item["times_seen"],
            "category": item["category"],
            "source_ref": key,
            "state": "suggestion_needs_owner_confirm",
        })
    return {"suggestions": out, "latest_transaction_date": cover, "boundary": "Detected from your transactions. Nothing is added until you confirm."}


def adopt_recurring(source_ref: str, vendor: str | None = None, amount: float | None = None,
                    due_date: str | None = None) -> dict[str, Any]:
    """Owner confirms one detected recurring bill into the register."""
    from app.services.recurring import detect_recurring, _normalise

    key = (source_ref or "").strip().lower()
    if not key:
        raise ValueError("source_ref is required.")
    match = None
    for item in detect_recurring():
        if item.get("kind") == "bill" and _normalise(item["merchant"]).lower() == key:
            match = item
            break
    if match is None:
        raise LookupError("No unadopted detected bill matches that reference.")
    conn = _conn()
    try:
        existing = conn.execute(
            "SELECT id FROM bills WHERE source = 'recurring' AND lower(source_ref) = ?", (key,)).fetchone()
    finally:
        conn.close()
    if existing:
        raise ValueError("That detected bill is already in the register.")
    result = add_bill(
        vendor or match["merchant"],
        amount if amount is not None else match["amount"],
        due_date or match["next_expected"],
        source="recurring",
        source_ref=key,
        cadence=match["cadence"],
        note="Adopted from recurring detection (%s, seen %d times)." % (match["cadence"], match["times_seen"]),
    )
    conn = _conn()
    try:
        with conn:
            _event(conn, result["bill"]["id"], "adopted_from_recurring",
                   {"merchant": match["merchant"], "times_seen": match["times_seen"]})
    finally:
        conn.close()
    return result
