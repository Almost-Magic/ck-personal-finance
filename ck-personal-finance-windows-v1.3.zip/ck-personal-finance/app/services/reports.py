# Author: Mani Padisetti
"""Financial reporting service — Trial Balance, P&L, Balance Sheet, Cash Flow."""

from app.database import get_db
from datetime import datetime


def trial_balance(from_date: str | None = None, to_date: str | None = None) -> dict:
    """Generate trial balance from posted journal entries."""
    with get_db() as conn:
        query = """
            SELECT a.id, a.code, a.name, a.type, a.sub_type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM accounts a
            LEFT JOIN (
                journal_lines jl
                JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            ) ON jl.account_id = a.id
        """
        params = []
        conditions = []
        if from_date:
            conditions.append("(je.date >= ? OR je.id IS NULL)")
            params.append(from_date)
        if to_date:
            conditions.append("(je.date <= ? OR je.id IS NULL)")
            params.append(to_date)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " GROUP BY a.id ORDER BY a.code"

        rows = conn.execute(query, params).fetchall()
        accounts = []
        sum_debits = 0.0
        sum_credits = 0.0
        for row in rows:
            debit = round(row["total_debits"], 2)
            credit = round(row["total_credits"], 2)
            balance = round(debit - credit, 2)
            if debit == 0 and credit == 0:
                continue
            accounts.append({
                "account_id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "type": row["type"],
                "sub_type": row["sub_type"],
                "debit": debit,
                "credit": credit,
                "balance": balance,
            })
            sum_debits += debit
            sum_credits += credit

        return {
            "report": "trial_balance",
            "from_date": from_date,
            "to_date": to_date,
            "generated_at": datetime.utcnow().isoformat(),
            "accounts": accounts,
            "total_debits": round(sum_debits, 2),
            "total_credits": round(sum_credits, 2),
            "is_balanced": round(sum_debits, 2) == round(sum_credits, 2),
        }


def profit_and_loss(from_date: str, to_date: str) -> dict:
    """Generate Profit & Loss statement for a date range."""
    with get_db() as conn:
        query = """
            SELECT a.id, a.code, a.name, a.type, a.sub_type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM accounts a
            JOIN journal_lines jl ON jl.account_id = a.id
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE je.date >= ? AND je.date <= ?
            AND a.type IN ('revenue', 'other_income', 'cogs', 'expense', 'other_expense')
            GROUP BY a.id ORDER BY a.code
        """
        rows = conn.execute(query, (from_date, to_date)).fetchall()

        sections = {
            "revenue": [], "other_income": [], "cogs": [],
            "expense": [], "other_expense": [],
        }
        totals = {k: 0.0 for k in sections}

        for row in rows:
            acc_type = row["type"]
            debit = row["total_debits"]
            credit = row["total_credits"]

            # Revenue/other_income: normal credit balance (credit - debit)
            if acc_type in ("revenue", "other_income"):
                amount = round(credit - debit, 2)
            else:
                # Expenses/COGS: normal debit balance (debit - credit)
                amount = round(debit - credit, 2)

            sections[acc_type].append({
                "account_id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "sub_type": row["sub_type"],
                "amount": amount,
            })
            totals[acc_type] += amount

        for k in totals:
            totals[k] = round(totals[k], 2)

        gross_profit = round(totals["revenue"] - totals["cogs"], 2)
        total_income = round(totals["revenue"] + totals["other_income"], 2)
        total_expenses = round(totals["expense"] + totals["other_expense"], 2)
        net_profit = round(total_income - totals["cogs"] - total_expenses, 2)

        return {
            "report": "profit_and_loss",
            "from_date": from_date,
            "to_date": to_date,
            "generated_at": datetime.utcnow().isoformat(),
            "revenue": sections["revenue"],
            "total_revenue": totals["revenue"],
            "cogs": sections["cogs"],
            "total_cogs": totals["cogs"],
            "gross_profit": gross_profit,
            "other_income": sections["other_income"],
            "total_other_income": totals["other_income"],
            "expenses": sections["expense"],
            "total_expenses": totals["expense"],
            "other_expenses": sections["other_expense"],
            "total_other_expenses": totals["other_expense"],
            "net_profit": net_profit,
        }


def balance_sheet(as_at_date: str) -> dict:
    """Generate Balance Sheet as at a specific date."""
    with get_db() as conn:
        query = """
            SELECT a.id, a.code, a.name, a.type, a.sub_type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM accounts a
            JOIN journal_lines jl ON jl.account_id = a.id
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE je.date <= ?
            AND a.type IN ('asset', 'liability', 'equity')
            GROUP BY a.id ORDER BY a.code
        """
        rows = conn.execute(query, (as_at_date,)).fetchall()

        sections = {"asset": [], "liability": [], "equity": []}
        totals = {k: 0.0 for k in sections}

        for row in rows:
            acc_type = row["type"]
            debit = row["total_debits"]
            credit = row["total_credits"]

            # Assets: normal debit balance
            if acc_type == "asset":
                amount = round(debit - credit, 2)
            else:
                # Liabilities & Equity: normal credit balance
                amount = round(credit - debit, 2)

            sections[acc_type].append({
                "account_id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "sub_type": row["sub_type"],
                "amount": amount,
            })
            totals[acc_type] += amount

        for k in totals:
            totals[k] = round(totals[k], 2)

        # Current year earnings from P&L
        # Use FY start (July 1) to as_at_date
        fy_month = conn.execute(
            "SELECT value FROM settings WHERE key = 'financial_year_start'"
        ).fetchone()
        fy_start_month = int(fy_month["value"]) if fy_month else 7

        as_at = datetime.strptime(as_at_date, "%Y-%m-%d")
        if as_at.month >= fy_start_month:
            fy_start = datetime(as_at.year, fy_start_month, 1).strftime("%Y-%m-%d")
        else:
            fy_start = datetime(as_at.year - 1, fy_start_month, 1).strftime("%Y-%m-%d")

        pnl = profit_and_loss(fy_start, as_at_date)
        current_year_earnings = pnl["net_profit"]

        total_equity = round(totals["equity"] + current_year_earnings, 2)
        total_liabilities_equity = round(totals["liability"] + total_equity, 2)

        return {
            "report": "balance_sheet",
            "as_at_date": as_at_date,
            "generated_at": datetime.utcnow().isoformat(),
            "assets": sections["asset"],
            "total_assets": totals["asset"],
            "liabilities": sections["liability"],
            "total_liabilities": totals["liability"],
            "equity": sections["equity"],
            "total_equity_accounts": totals["equity"],
            "current_year_earnings": current_year_earnings,
            "total_equity": total_equity,
            "total_liabilities_and_equity": total_liabilities_equity,
            "is_balanced": totals["asset"] == total_liabilities_equity,
        }


def cash_flow(from_date: str, to_date: str) -> dict:
    """Generate Cash Flow Statement using indirect method."""
    with get_db() as conn:
        # Get net profit from P&L
        pnl = profit_and_loss(from_date, to_date)
        net_profit = pnl["net_profit"]

        # Get account movements for the period
        query = """
            SELECT a.id, a.code, a.name, a.type, a.sub_type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM accounts a
            JOIN journal_lines jl ON jl.account_id = a.id
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE je.date >= ? AND je.date <= ?
            AND a.type IN ('asset', 'liability')
            GROUP BY a.id ORDER BY a.code
        """
        rows = conn.execute(query, (from_date, to_date)).fetchall()

        operating = []
        investing = []
        financing = []

        # Classify based on sub_type
        operating_sub_types = {
            "current_asset", "current_liability", "depreciation",
        }
        investing_sub_types = {
            "fixed_asset",
        }
        financing_sub_types = {
            "non_current_liability", "owners_equity", "drawings",
            "retained_earnings", "current_earnings",
        }

        total_operating = net_profit
        total_investing = 0.0
        total_financing = 0.0

        for row in rows:
            sub = row["sub_type"] or ""
            debit = row["total_debits"]
            credit = row["total_credits"]
            net_movement = round(debit - credit, 2)

            # Skip cash accounts (they're the result, not a component)
            if row["code"] in ("1000", "1010"):
                continue

            item = {
                "account_id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "movement": net_movement,
            }

            if sub in investing_sub_types:
                investing.append(item)
                total_investing += net_movement
            elif sub in financing_sub_types:
                financing.append(item)
                total_financing += net_movement
            elif sub in operating_sub_types or row["type"] in ("asset", "liability"):
                # For operating: increase in current assets = cash outflow (negative)
                # increase in current liabilities = cash inflow (positive)
                if row["type"] == "asset":
                    cash_effect = -net_movement
                else:
                    cash_effect = net_movement
                item["cash_effect"] = round(cash_effect, 2)
                operating.append(item)
                total_operating += cash_effect

        total_operating = round(total_operating, 2)
        total_investing = round(-total_investing, 2)  # Cash paid for assets is negative
        total_financing = round(total_financing, 2)
        net_change = round(total_operating + total_investing + total_financing, 2)

        return {
            "report": "cash_flow",
            "from_date": from_date,
            "to_date": to_date,
            "generated_at": datetime.utcnow().isoformat(),
            "operating_activities": {
                "net_profit": net_profit,
                "adjustments": operating,
                "total": total_operating,
            },
            "investing_activities": {
                "items": investing,
                "total": total_investing,
            },
            "financing_activities": {
                "items": financing,
                "total": total_financing,
            },
            "net_change_in_cash": net_change,
        }


def generate_periods(financial_year: int) -> list[dict]:
    """Generate monthly periods for a financial year (July-June)."""
    with get_db() as conn:
        fy_month_row = conn.execute(
            "SELECT value FROM settings WHERE key = 'financial_year_start'"
        ).fetchone()
        fy_start_month = int(fy_month_row["value"]) if fy_month_row else 7

        periods = []
        for i in range(12):
            month = ((fy_start_month - 1 + i) % 12) + 1
            year = financial_year if month >= fy_start_month else financial_year + 1

            if month == 12:
                end_year = year + 1
                end_month = 1
            else:
                end_year = year
                end_month = month + 1

            import calendar
            last_day = calendar.monthrange(year, month)[1]

            start_date = f"{year}-{month:02d}-01"
            end_date = f"{year}-{month:02d}-{last_day:02d}"
            name = f"{calendar.month_abbr[month]} {year}"

            existing = conn.execute(
                "SELECT id FROM financial_periods WHERE start_date = ? AND end_date = ?",
                (start_date, end_date),
            ).fetchone()
            if existing:
                periods.append({"id": existing["id"], "name": name, "exists": True})
                continue

            cursor = conn.execute(
                """INSERT INTO financial_periods (name, start_date, end_date, period_type)
                VALUES (?, ?, ?, 'monthly')""",
                (name, start_date, end_date),
            )
            periods.append({
                "id": cursor.lastrowid,
                "name": name,
                "start_date": start_date,
                "end_date": end_date,
                "exists": False,
            })

        return periods
