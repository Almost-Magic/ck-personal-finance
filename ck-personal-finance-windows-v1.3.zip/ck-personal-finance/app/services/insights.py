"""W1 insight services: forecast, safe-to-spend, fees & duplicates, merchants, refunds.

Everything here reads only the local SQLite store (visible rows only). Outputs are
estimates computed from imported statements, with assumptions stated plainly. They
never send data anywhere and never give advice.
"""

from __future__ import annotations

import re
import sqlite3
from datetime import date, timedelta
from statistics import median
from typing import Any

from app.config import DATA_DIR
from app.services.recurring import _normalise
from app.services.recurring import detect_recurring as _detect_recurring_raw


def detect_recurring() -> list[dict[str, Any]]:
    try:
        return _detect_recurring_raw()
    except Exception:
        return []

_INSIGHT_SCHEMA = """
CREATE TABLE IF NOT EXISTS merchant_aliases(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL DEFAULT 1,
  merchant_key TEXT NOT NULL UNIQUE,
  alias TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS refund_trackers(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL DEFAULT 1,
  merchant TEXT NOT NULL,
  amount REAL NOT NULL,
  expected_date TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'expected',
  created_at TEXT NOT NULL,
  resolved_at TEXT
);
"""

_FEE_WORDS = re.compile(r"\b(fee|fees|charge|charges|charged|interest|overdrawn|overdraft|dishonour|penalty)\b", re.IGNORECASE)
CASH_GROUP_TYPES = {"transaction", "savings", "everyday", "checking", "bank", "cash"}


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DATA_DIR / "personal-finance.sqlite3", timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def init_insights_store() -> None:
    conn = _conn()
    try:
        with conn:
            conn.executescript(_INSIGHT_SCHEMA)
    finally:
        conn.close()


def _visible_transactions(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    try:
        rows = conn.execute(
            "SELECT t.id, t.tx_date, t.description, t.amount, t.category, g.name AS account_name "
            "FROM personal_transactions t "
            "JOIN personal_account_groups g ON g.id = t.account_group_id AND COALESCE(g.demo_hidden,0)=0 "
            "ORDER BY t.tx_date, t.id"
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def _cash_balance(conn: sqlite3.Connection) -> tuple[float, list[str]]:
    try:
        rows = conn.execute(
            "SELECT name, group_type, current_balance FROM personal_account_groups WHERE COALESCE(demo_hidden,0)=0"
        ).fetchall()
    except Exception:
        rows = []
    total = 0.0
    names: list[str] = []
    for r in rows:
        if str(r["group_type"]).lower() in CASH_GROUP_TYPES:
            total += float(r["current_balance"])
            names.append(r["name"])
    return round(total, 2), names


def _commitments_between(recurring_items: list[dict[str, Any]], start: date, end: date) -> tuple[float, list[dict[str, Any]]]:
    """Project each detected recurring item's occurrences into [start, end]."""
    cadence_days = {"weekly": 7, "fortnightly": 14, "monthly": 30, "quarterly": 91, "yearly": 365}
    total = 0.0
    due: list[dict[str, Any]] = []
    for item in recurring_items:
        step = cadence_days.get(item.get("cadence") or "")
        if not step:
            continue
        try:
            nxt = date.fromisoformat(item["next_expected"])
        except Exception:
            continue
        occurrences = 0
        first_due = None
        cursor = nxt
        guard = 0
        while cursor <= end and guard < 40:
            if cursor >= start:
                occurrences += 1
                if first_due is None:
                    first_due = cursor.isoformat()
            cursor += timedelta(days=step)
            guard += 1
        if occurrences:
            amount = round(float(item["amount"]) * occurrences, 2)
            total += amount
            due.append({
                "merchant": item["merchant"], "kind": item["kind"], "cadence": item["cadence"],
                "amount_each": item["amount"], "occurrences": occurrences, "total": amount,
                "first_due": first_due, "variable_amount": bool(item.get("variable_amount")),
            })
    due.sort(key=lambda r: r["first_due"] or "")
    return round(total, 2), due


def _detect_income(transactions: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Find a recurring credit pattern (salary-like). Most frequent monthly-ish credit group."""
    credits: dict[str, list[date]] = {}
    amounts: dict[str, list[float]] = {}
    for tx in transactions:
        if float(tx["amount"]) <= 0:
            continue
        key = _normalise(tx["description"])
        credits.setdefault(key, []).append(date.fromisoformat(tx["tx_date"]))
        amounts.setdefault(key, []).append(float(tx["amount"]))
    best: dict[str, Any] | None = None
    for key, dates in credits.items():
        if len(dates) < 2:
            continue
        dates.sort()
        gaps = [(b - a).days for a, b in zip(dates, dates[1:])]
        med_gap = median(gaps)
        if 25 <= med_gap <= 35:
            cadence, step = "monthly", 30
        elif 12 <= med_gap <= 16:
            cadence, step = "fortnightly", 14
        elif 5 <= med_gap <= 9:
            cadence, step = "weekly", 7
        else:
            continue
        med_amount = round(median(amounts[key]), 2)
        next_expected = (dates[-1] + timedelta(days=step)).isoformat()
        candidate = {
            "source": key.title(), "cadence": cadence, "amount": med_amount,
            "times_seen": len(dates), "last_date": dates[-1].isoformat(),
            "next_expected": next_expected, "step_days": step,
        }
        if best is None or med_amount > best["amount"]:
            best = candidate
    return best


def forecast() -> dict[str, Any]:
    init_insights_store()
    conn = _conn()
    try:
        transactions = _visible_transactions(conn)
        cash, cash_accounts = _cash_balance(conn)
    finally:
        conn.close()
    today = date.today()
    month_end = date(today.year + (1 if today.month == 12 else 0), 1 if today.month == 12 else today.month + 1, 1) - timedelta(days=1)
    recurring_items = detect_recurring()
    income = _detect_income(transactions)

    def horizon(days: int) -> dict[str, Any]:
        end = today + timedelta(days=days)
        committed, due = _commitments_between(recurring_items, today, end)
        income_expected = 0.0
        if income:
            step = income["step_days"]
            occurrences = 0
            try:
                cursor = date.fromisoformat(income["next_expected"])
                guard = 0
                while cursor <= end and guard < 40:
                    if cursor >= today:
                        occurrences += 1
                    cursor += timedelta(days=step)
                    guard += 1
            except Exception:
                occurrences = 0
            income_expected = round(income["amount"] * occurrences, 2)
        # Variable pace: non-recurring outflow over the observed window.
        recurring_keys = {_normalise(item["merchant"]) for item in recurring_items}
        observed_days = 0
        variable_total = 0.0
        if transactions:
            first = date.fromisoformat(transactions[0]["tx_date"])
            observed_days = max(1, (today - first).days)
            for tx in transactions:
                amount = float(tx["amount"])
                if amount >= 0:
                    continue
                if _normalise(tx["description"]) in recurring_keys:
                    continue
                variable_total += abs(amount)
        daily_variable = round(variable_total / observed_days, 2) if observed_days else 0.0
        variable_projection = round(daily_variable * days, 2)
        estimate = round(cash + income_expected - committed - variable_projection, 2)
        return {
            "days": days, "end_date": end.isoformat(),
            "cash_now": cash, "income_expected": income_expected,
            "committed": committed, "variable_projection": variable_projection,
            "daily_variable": daily_variable, "estimate": estimate, "due": due,
        }

    h_month = horizon((month_end - today).days)
    h_30 = horizon(30)

    coverage_days = 0
    if transactions:
        coverage_days = (today - date.fromisoformat(transactions[0]["tx_date"])).days
    assumptions = [
        "Cash means the current balances of %s." % (", ".join(cash_accounts) if cash_accounts else "no cash-type accounts yet"),
        "Committed means detected regular bills and subscriptions due inside the window (%d patterns)." % len(recurring_items),
        "Variable spend keeps the average pace of the last %d day(s) of imported history ($%.2f/day)." % (max(coverage_days, 0), h_30["daily_variable"]),
        "Income is only counted when a repeating credit pattern was detected%s." % (" (" + income["source"] + ", " + income["cadence"] + ")" if income else "; none detected yet"),
        "Future one-off purchases, cash spending, and un-imported accounts are not included.",
    ]
    return {
        "today": today.isoformat(),
        "month_end": h_month, "thirty_day": h_30,
        "recurring_count": len(recurring_items),
        "income": income,
        "transactions_seen": len(transactions),
        "coverage_days": coverage_days,
        "assumptions": assumptions,
        "honesty": ("No imported transactions yet, so this is frame-only: import a statement and these numbers become yours."
                    if not transactions else
                    "Estimates from your imported rows only; a comfort check, not advice."),
    }


def safe_to_spend(buffer_target: float = 1000.0) -> dict[str, Any]:
    init_insights_store()
    conn = _conn()
    try:
        transactions = _visible_transactions(conn)
        cash, cash_accounts = _cash_balance(conn)
    finally:
        conn.close()
    today = date.today()
    end = today + timedelta(days=30)
    recurring_items = detect_recurring()
    committed, due = _commitments_between(recurring_items, today, end)
    income = _detect_income(transactions)
    if income:
        try:
            days_to_income = max(1, (date.fromisoformat(income["next_expected"]) - today).days)
        except Exception:
            days_to_income = 30
    else:
        days_to_income = 30
    safe_total = round(cash - committed - buffer_target, 2)
    per_day = round(safe_total / days_to_income, 2) if days_to_income else safe_total
    return {
        "today": today.isoformat(),
        "cash_now": cash, "committed_30d": committed, "buffer_target": round(buffer_target, 2),
        "safe_total": safe_total, "days_to_income": days_to_income, "per_day": per_day,
        "due": due, "income": income,
        "transactions_seen": len(transactions),
        "cash_accounts": cash_accounts,
        "assumptions": [
            "Buffer target is a fixed $%.2f placeholder, not a recommendation; it will become adjustable in Settings." % buffer_target,
            "Committed covers detected regular bills and subscriptions due in the next 30 days (%d patterns)." % len(recurring_items),
            "Per-day spreads what is left over %d day(s) (%s)." % (days_to_income, "until the next detected income" if income else "30-day fallback; no income pattern detected"),
            "Cash spending, pending card transactions, and un-imported accounts are not included.",
        ],
        "honesty": ("No imported transactions yet, so this is frame-only: import a statement and this number becomes yours."
                    if not transactions else
                    "A private arithmetic check from your imported rows, not advice."),
    }


def fees_and_duplicates() -> dict[str, Any]:
    init_insights_store()
    conn = _conn()
    try:
        transactions = _visible_transactions(conn)
    finally:
        conn.close()
    fee_rows = []
    fee_total = 0.0
    for tx in transactions:
        amount = float(tx["amount"])
        if amount >= 0:
            continue
        if tx["category"] == "Fees & charges" or _FEE_WORDS.search(tx["description"]):
            fee_rows.append({"date": tx["tx_date"], "description": tx["description"], "amount": amount, "account_name": tx["account_name"]})
            fee_total += abs(amount)
    fee_rows = fee_rows[-25:][::-1]

    by_merchant: dict[str, list[dict[str, Any]]] = {}
    for tx in transactions:
        if float(tx["amount"]) < 0:
            by_merchant.setdefault(_normalise(tx["description"]), []).append(tx)

    duplicates = []
    for merchant, items in by_merchant.items():
        items.sort(key=lambda r: r["tx_date"])
        for prev, cur in zip(items, items[1:]):
            gap = (date.fromisoformat(cur["tx_date"]) - date.fromisoformat(prev["tx_date"])).days
            if gap <= 3 and abs(float(prev["amount"]) - float(cur["amount"])) < 0.005:
                duplicates.append({
                    "merchant": merchant.title(), "amount": float(cur["amount"]),
                    "first_date": prev["tx_date"], "second_date": cur["tx_date"], "gap_days": gap,
                })
    duplicates = duplicates[-15:][::-1]

    price_changes = []
    for merchant, items in by_merchant.items():
        if len(items) < 4:
            continue
        items.sort(key=lambda r: r["tx_date"])
        half = len(items) // 2
        early = median(abs(float(r["amount"])) for r in items[:half])
        late = median(abs(float(r["amount"])) for r in items[-half:])
        if early > 0 and abs(late - early) / early > 0.05 and abs(late - early) >= 1.0:
            price_changes.append({
                "merchant": merchant.title(), "was": round(early, 2), "now": round(late, 2),
                "change_pct": round((late - early) / early * 100, 1),
                "first_date": items[0]["tx_date"], "last_date": items[-1]["tx_date"],
            })
    price_changes.sort(key=lambda r: -abs(r["change_pct"]))

    unusual = []
    for merchant, items in by_merchant.items():
        if len(items) < 3:
            continue
        amounts = [abs(float(r["amount"])) for r in items]
        med = median(amounts)
        if med <= 0:
            continue
        for r in items:
            amount = abs(float(r["amount"]))
            if amount > max(2.0 * med, med + 50.0):
                unusual.append({
                    "merchant": merchant.title(), "date": r["tx_date"], "amount": -amount,
                    "usual": round(med, 2), "description": r["description"], "account_name": r["account_name"],
                })
    unusual.sort(key=lambda r: r["date"], reverse=True)
    unusual = unusual[:15]

    return {
        "fees": fee_rows, "fee_total": round(fee_total, 2),
        "duplicates": duplicates, "price_changes": price_changes, "unusual": unusual,
        "transactions_seen": len(transactions),
        "assumptions": [
            "Fees match the Fees & charges category or the words fee/charge/interest/overdrawn/dishonour/penalty.",
            "Possible duplicates are same merchant, same amount, within 3 days; check before treating either as wrong.",
            "Price changes compare the older half against the newer half of a merchant's charges.",
            "Unusual means more than twice that merchant's usual amount; large legitimate purchases will appear here too.",
        ],
        "honesty": ("No imported transactions yet, so there is nothing to scan: import a statement first."
                    if not transactions else
                    "Pattern matches from your imported rows; each row is a prompt to look, not a verdict."),
    }


def merchants() -> dict[str, Any]:
    init_insights_store()
    conn = _conn()
    try:
        transactions = _visible_transactions(conn)
        try:
            alias_rows = conn.execute("SELECT merchant_key, alias FROM merchant_aliases").fetchall()
            aliases = {r["merchant_key"]: r["alias"] for r in alias_rows}
        except Exception:
            aliases = {}
    finally:
        conn.close()
    grouped: dict[str, dict[str, Any]] = {}
    for tx in transactions:
        key = _normalise(tx["description"])
        entry = grouped.setdefault(key, {"merchant_key": key, "name": key.title(), "count": 0, "total": 0.0, "last_date": "", "category": tx["category"]})
        entry["count"] += 1
        entry["total"] += float(tx["amount"])
        entry["last_date"] = max(entry["last_date"], tx["tx_date"])
        entry["category"] = tx["category"]
    rows = []
    for key, entry in grouped.items():
        entry["total"] = round(entry["total"], 2)
        entry["alias"] = aliases.get(key)
        entry["display"] = aliases.get(key) or entry["name"]
        rows.append(entry)
    rows.sort(key=lambda r: (r["last_date"], r["merchant_key"]), reverse=True)
    return {
        "merchants": rows,
        "alias_count": len(aliases),
        "transactions_seen": len(transactions),
        "honesty": ("No imported transactions yet, so no merchants to list: import a statement first."
                    if not transactions else
                    "Names come from your imported descriptions, grouped by a normalised key; aliases are private labels you set."),
    }


def set_merchant_alias(merchant_key: str, alias: str) -> dict[str, Any]:
    init_insights_store()
    key = (merchant_key or "").strip().upper()
    label = (alias or "").strip()
    if not key:
        raise ValueError("merchant_key is required")
    conn = _conn()
    try:
        with conn:
            if label:
                existing = conn.execute("SELECT id FROM merchant_aliases WHERE merchant_key = ?", (key,)).fetchone()
                if existing:
                    conn.execute("UPDATE merchant_aliases SET alias = ?, updated_at = ? WHERE merchant_key = ?", (label, _now_iso(), key))
                else:
                    conn.execute("INSERT INTO merchant_aliases(merchant_key, alias, created_at, updated_at) VALUES (?,?,?,?)", (key, label, _now_iso(), _now_iso()))
            else:
                conn.execute("DELETE FROM merchant_aliases WHERE merchant_key = ?", (key,))
    finally:
        conn.close()
    return {"merchant_key": key, "alias": label or None, "removed": not bool(label)}


def refunds() -> dict[str, Any]:
    init_insights_store()
    conn = _conn()
    try:
        transactions = _visible_transactions(conn)
        try:
            expected = [dict(r) for r in conn.execute(
                "SELECT id, merchant, amount, expected_date, note, status, created_at, resolved_at FROM refund_trackers WHERE status = 'expected' ORDER BY expected_date"
            ).fetchall()]
            resolved = [dict(r) for r in conn.execute(
                "SELECT id, merchant, amount, expected_date, note, status, created_at, resolved_at FROM refund_trackers WHERE status != 'expected' ORDER BY resolved_at DESC LIMIT 10"
            ).fetchall()]
        except Exception:
            expected, resolved = [], []
    finally:
        conn.close()
    debits: dict[str, int] = {}
    for tx in transactions:
        if float(tx["amount"]) < 0:
            key = _normalise(tx["description"])
            debits[key] = debits.get(key, 0) + 1
    received = []
    for tx in transactions:
        if float(tx["amount"]) <= 0:
            continue
        key = _normalise(tx["description"])
        if debits.get(key, 0) >= 1 and tx["category"] != "Income":
            received.append({
                "date": tx["tx_date"], "description": tx["description"], "amount": float(tx["amount"]),
                "merchant": key.title(), "account_name": tx["account_name"],
            })
    received = received[-20:][::-1]
    return {
        "expected": expected, "received": received, "resolved": resolved,
        "transactions_seen": len(transactions),
        "assumptions": [
            "Received refunds are credits from a merchant you have also paid, excluding Income categorised rows.",
            "Expected refunds are ones you add yourself with a follow-up date; the app never assumes a refund is coming.",
        ],
        "honesty": ("No imported transactions yet, so nothing to match: import a statement first."
                    if not transactions else
                    "Matches from your imported rows; verify against the merchant before acting."),
    }


def add_refund_tracker(merchant: str, amount: float, expected_date: str, note: str = "") -> dict[str, Any]:
    init_insights_store()
    name = (merchant or "").strip()
    if not name:
        raise ValueError("merchant is required")
    try:
        parsed = date.fromisoformat(expected_date)
    except Exception:
        raise ValueError("expected_date must be YYYY-MM-DD")
    conn = _conn()
    try:
        with conn:
            cur = conn.execute(
                "INSERT INTO refund_trackers(merchant, amount, expected_date, note, status, created_at) VALUES (?,?,?,?,'expected',?)",
                (name, float(amount), parsed.isoformat(), (note or "").strip(), _now_iso()),
            )
            row_id = cur.lastrowid
    finally:
        conn.close()
    return {"id": row_id, "merchant": name, "amount": float(amount), "expected_date": parsed.isoformat(), "status": "expected"}


def resolve_refund_tracker(tracker_id: int, status: str = "received") -> dict[str, Any]:
    init_insights_store()
    if status not in {"received", "cancelled"}:
        raise ValueError("status must be received or cancelled")
    conn = _conn()
    try:
        with conn:
            cur = conn.execute(
                "UPDATE refund_trackers SET status = ?, resolved_at = ? WHERE id = ? AND status = 'expected'",
                (status, _now_iso(), tracker_id),
            )
            if cur.rowcount == 0:
                raise LookupError("No open refund tracker with that id.")
    finally:
        conn.close()
    return {"id": tracker_id, "status": status}


def list_merchant_aliases() -> list[str]:
    init_insights_store()
    conn = _conn()
    try:
        try:
            return [r["alias"] for r in conn.execute("SELECT alias FROM merchant_aliases").fetchall()]
        except Exception:
            return []
    finally:
        conn.close()
