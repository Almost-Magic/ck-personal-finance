"""Recurring payment detection over imported personal transactions.

Local-only: reads personal_transactions, finds repeated merchants with a
steady cadence and similar amounts, and classifies them as bills or
subscriptions. No external calls, no writes.

Every pattern carries an evidence status derived from the calendar as-of date:
"active" (next expected occurrence still ahead), "stale" (the expected date
passed within one cadence), "historical" (more than a full cadence past).
These are projections from imported records only: a missing newer match is not
evidence that an obligation stopped, and a future projection is an estimate,
not a confirmed bill. Projections are never rolled forward: a past expected
date stays visible as past, so no continued obligation is invented.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import date, timedelta
from statistics import median
from typing import Any

from app.config import DATA_DIR

BILL_CATEGORIES = {"Utilities", "Rent", "Insurance", "Health", "Fees & charges"}

_CADENCES = [
    ("weekly", 6, 9, 7),
    ("fortnightly", 12, 16, 14),
    ("monthly", 27, 34, 30),
    ("quarterly", 85, 95, 91),
    ("annual", 360, 370, 365),
]


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DATA_DIR / "personal-finance.sqlite3", timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


_NOISE = {"DD", "REF", "COM", "PTY", "LTD", "CO", "INC", "AU", "AUS", "WWW", "NET",
          "PAY", "PYMT", "DEBIT", "DIRECT", "VISA", "MASTERCARD", "CARD", "PURCHASE", "ONLINE"}


def _normalise(description: str) -> str:
    tokens = re.sub(r"[^A-Za-z0-9 ]", " ", description.upper()).split()
    kept = [t for t in tokens if not any(ch.isdigit() for ch in t) and t not in _NOISE]
    return " ".join(kept[:4]) or description.upper()[:24]


def _cadence(days: float) -> tuple[str | None, int | None]:
    for name, lo, hi, approx in _CADENCES:
        if lo <= days <= hi:
            return name, approx
    return None, None


def detect_recurring(as_of: date | None = None) -> list[dict[str, Any]]:
    today = as_of or date.today()
    conn = _conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT tx_date, description, amount, category FROM personal_transactions WHERE amount < 0 ORDER BY description, tx_date"
        )]
    finally:
        conn.close()
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(_normalise(row["description"]), []).append(row)
    out: list[dict[str, Any]] = []
    for merchant, items in groups.items():
        if len(items) < 2:
            continue
        items.sort(key=lambda r: r["tx_date"])
        dates = [date.fromisoformat(r["tx_date"]) for r in items]
        gaps = [(b - a).days for a, b in zip(dates, dates[1:])]
        cadence, approx = _cadence(median(gaps))
        if not cadence or approx is None:
            continue
        amounts = [abs(float(r["amount"])) for r in items]
        med_amount = median(amounts)
        variable = any(abs(a - med_amount) > max(2.0, med_amount * 0.10) for a in amounts)
        next_date = dates[-1] + timedelta(days=approx)
        overdue_days = (today - next_date).days
        if overdue_days <= 0:
            status = "active"
        elif overdue_days <= approx:
            status = "stale"
        else:
            status = "historical"
        next_expected = next_date.isoformat()
        categories = {r["category"] for r in items}
        kind = "bill" if categories & BILL_CATEGORIES else "subscription"
        out.append({
            "merchant": merchant.title(),
            "kind": kind,
            "cadence": cadence,
            "amount": round(med_amount, 2),
            "variable_amount": variable,
            "times_seen": len(items),
            "last_date": items[-1]["tx_date"],
            "next_expected": next_expected,
            "status": status,
            "overdue_days": max(0, overdue_days),
            "annual_cost": round(med_amount * (365.0 / approx), 2),
            "category": items[-1]["category"],
        })
    out.sort(key=lambda r: r["next_expected"])
    return out
