"""Bounded subprocess PDF rasterizer for local bill OCR. No network access."""
import sys
from pathlib import Path

MAX_PIXELS = 25_000_000


def render(source, prefix, max_pages):
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(source)
    try:
        count = min(len(doc), max_pages)
        if not count:
            raise ValueError("The PDF has no pages.")
        for i in range(count):
            page = doc[i]
            try:
                width, height = page.get_size()
                scale = 200 / 72
                if width <= 0 or height <= 0 or width * height * scale * scale > MAX_PIXELS:
                    raise ValueError("PDF page is too large for safe local OCR.")
                bitmap = page.render(scale=scale)
                try:
                    image = bitmap.to_pil()
                    try:
                        image.save(str(prefix) + "-%d.png" % (i + 1))
                    finally:
                        image.close()
                finally:
                    bitmap.close()
            finally:
                page.close()
    finally:
        doc.close()


if __name__ == "__main__":
    render(Path(sys.argv[1]), Path(sys.argv[2]), min(3, max(1, int(sys.argv[3]))))
