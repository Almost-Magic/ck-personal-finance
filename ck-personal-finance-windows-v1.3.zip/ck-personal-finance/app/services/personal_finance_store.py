"""Local SQLite persistence and text search for CK Personal Finance."""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from typing import Any, Iterable

import sqlite3
from app.config import DATA_DIR, init_data_dir

APP_MODE = "sqlite"
DEMO_MODE = False
_INIT_LOCK = threading.Lock()
_INITIALISED = False
STORE_PATH = DATA_DIR / "personal-finance.sqlite3"
VECTOR_DIMS = 1536
USER_UPLOAD_ROOT = DATA_DIR / "uploads"
MAX_USER_UPLOAD_BYTES = 25 * 1024 * 1024


SQLITE_SCHEMA_SQL = """

CREATE TABLE IF NOT EXISTS personal_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    currency TEXT NOT NULL DEFAULT 'AUD',
    timezone TEXT NOT NULL DEFAULT 'Australia/Sydney',
    demo_data BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS personal_account_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    group_type TEXT NOT NULL,
    current_balance NUMERIC(14, 2) NOT NULL DEFAULT 0,
    source_state TEXT NOT NULL DEFAULT 'local_manual',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS savings_goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    target_amount NUMERIC(14, 2) NOT NULL,
    saved_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
    target_date DATE,
    status TEXT NOT NULL DEFAULT 'tracking',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS debt_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    current_balance NUMERIC(14, 2) NOT NULL,
    repayment_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
    repayment_frequency TEXT NOT NULL DEFAULT 'monthly',
    interest_rate NUMERIC(8, 4),
    status TEXT NOT NULL DEFAULT 'tracking',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS finance_decision_receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    decision_type TEXT NOT NULL,
    context TEXT NOT NULL,
    boundary TEXT NOT NULL,
    source_refs TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS import_rollback_receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    import_source TEXT NOT NULL,
    rows_previewed INTEGER NOT NULL DEFAULT 0,
    rows_committed INTEGER NOT NULL DEFAULT 0,
    rollback_state TEXT NOT NULL DEFAULT 'preview_only',
    source_confidence TEXT NOT NULL DEFAULT 'needs_human_review',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS finance_document_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    document_type TEXT NOT NULL,
    source_path TEXT,
    evidence_text TEXT NOT NULL,
    embedding TEXT,
    freshness_state TEXT NOT NULL DEFAULT 'local_demo',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nas_source_index_receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at TEXT,
    roots TEXT NOT NULL DEFAULT '[]',
    excluded_prefixes TEXT NOT NULL DEFAULT '[]',
    scanned_files INTEGER NOT NULL DEFAULT 0,
    indexed_chunks INTEGER NOT NULL DEFAULT 0,
    skipped_files INTEGER NOT NULL DEFAULT 0,
    blocked_files INTEGER NOT NULL DEFAULT 0,
    limit_reached BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS user_upload_receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    original_filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size_bytes INTEGER NOT NULL,
    indexed_chunks INTEGER NOT NULL DEFAULT 0,
    external_send BOOLEAN NOT NULL DEFAULT FALSE,
    boundary TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS finance_reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    due_date DATE NOT NULL,
    cadence TEXT NOT NULL DEFAULT 'once',
    lead_days INTEGER NOT NULL DEFAULT 14,
    status TEXT NOT NULL DEFAULT 'scheduled',
    source_ref TEXT NOT NULL DEFAULT 'local',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS scenario_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    scenario_type TEXT NOT NULL,
    inputs TEXT NOT NULL,
    outputs TEXT NOT NULL,
    boundary TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS report_exports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES personal_profiles(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL,
    title TEXT NOT NULL,
    payload TEXT NOT NULL,
    source_refs TEXT NOT NULL DEFAULT '[]',
    external_send_state TEXT NOT NULL DEFAULT 'not_sent',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS field_helpers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    surface TEXT NOT NULL,
    field_name TEXT NOT NULL,
    helper_type TEXT NOT NULL,
    helper_text TEXT NOT NULL,
    micro_action TEXT NOT NULL,
    admin_only BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cross_app_handoffs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_app TEXT NOT NULL,
    intent TEXT NOT NULL,
    payload TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'draft_local_only',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_iterations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    iteration INTEGER NOT NULL,
    done_count INTEGER NOT NULL,
    partial_count INTEGER NOT NULL,
    blocked_count INTEGER NOT NULL,
    missing_count INTEGER NOT NULL,
    notes TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


TABLES = [
    "personal_profiles",
    "personal_account_groups",
    "savings_goals",
    "debt_plans",
    "finance_decision_receipts",
    "import_rollback_receipts",
    "finance_document_evidence",
    "nas_source_index_receipts",
    "user_upload_receipts",
    "finance_reminders",
    "scenario_plans",
    "report_exports",
    "field_helpers",
    "cross_app_handoffs",
    "audit_iterations",
]


WORKFLOW_IDS = [
    "dashboard",
    "accounts",
    "transactions",
    "income",
    "expenses",
    "cashflow",
    "budget",
    "savings-goals",
    "debt-loans",
    "net-worth",
    "tax-evidence",
    "receipts-files",
    "alerts-reminders",
    "reports",
    "scenario-planner",
    "privacy-risk",
    "import-reconcile",
    "local-notes",
    "cross-app",
    "admin-settings",
    "nas-source-indexing",
    "external-action-gates",
    "user-csv-pdf-upload",
]


USER_UPLOAD_EXTENSIONS = {".csv", ".pdf"}


@contextmanager
def _sqlite_conn():
    conn = _connect_sqlite()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _connect_sqlite():
    init_data_dir()
    conn = sqlite3.connect(STORE_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def using_sqlite() -> bool:
    return True


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def _profile_id(conn: Any) -> int:
    row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    if isinstance(row, dict):
        return int(row["id"])
    return int(row[0])


def _executemany(conn: Any, query: str, rows: Iterable[tuple[Any, ...]]) -> None:
    if hasattr(conn, "executemany"):
        conn.executemany(query, rows)
        return
    with conn.cursor() as cursor:
        cursor.executemany(query, rows)


def _safe_source(path: Path) -> bool:
    resolved = path.resolve()
    return resolved.is_relative_to(USER_UPLOAD_ROOT.resolve()) and not path.is_symlink()


def _read_source_chunks(path: Path, max_chunks: int = 12) -> list[dict[str, str]]:
    if not _safe_source(path):
        raise ValueError("Evidence must be inside the local upload folder.")
    if not path.exists():
        return []
    if path.suffix.lower() == ".pdf":
        import subprocess
        import sys
        try:
            completed = subprocess.run([sys.executable, str(Path(__file__).with_name("pdf_text_worker.py")),
                                        str(path), str(min(max_chunks * 3500, 84000))],
                                       capture_output=True, text=True, timeout=12,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            result = json.loads(completed.stdout)
        except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as exc:
            raise ValueError("PDF could not be read within the local processing limits.") from exc
        if completed.returncode or "error" in result:
            raise ValueError(result.get("error", "PDF processing failed."))
        text = result["text"]
    else:
        text = path.read_text(encoding="utf-8", errors="replace")
    if not text.strip():
        raise ValueError("File contains no readable evidence text.")
    # Split by length so long CSVs do not silently lose everything after one paragraph.
    return [{"title": f"{path.name} chunk {i // 3300 + 1}",
             "source_path": str(path), "text": text[i:i + 3500]}
            for i in range(0, min(len(text), max_chunks * 3300), 3300)]


def _insert_evidence_chunks(conn: Any, profile_id: int, chunks: list[dict[str, str]], document_type: str) -> int:
    inserted = 0
    for chunk in chunks:
        exists = conn.execute(
            "SELECT id FROM finance_document_evidence WHERE source_path = ? AND title = ? LIMIT 1",
            (chunk["source_path"], chunk["title"]),
        ).fetchone()
        if exists:
            continue
        conn.execute(
            """
            INSERT INTO finance_document_evidence
                (profile_id, title, document_type, source_path, evidence_text, embedding, freshness_state)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                profile_id,
                chunk["title"],
                document_type,
                chunk["source_path"],
                chunk["text"],
                None,
                "source_indexed",
            ),
        )
        inserted += 1
    return inserted


def _safe_upload_name(filename: str) -> str:
    raw = Path(filename or "upload").name
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", Path(raw).stem).strip(".-_") or "upload"
    suffix = Path(raw).suffix.lower()
    return f"{stem[:80]}{suffix}"


def init_personal_finance_store() -> None:
    """Create the schema and an empty local profile, without synthetic balances."""
    global _INITIALISED
    if _INITIALISED:
        return
    with _INIT_LOCK:
        if _INITIALISED:
            return
        with _sqlite_conn() as conn:
            conn.executescript(SQLITE_SCHEMA_SQL)
            for _t in ("personal_account_groups", "savings_goals", "debt_plans", "finance_reminders"):
                try:
                    conn.execute("ALTER TABLE " + _t + " ADD COLUMN demo_hidden INTEGER NOT NULL DEFAULT 0")
                except Exception:
                    pass
            existing = conn.execute("SELECT COUNT(*) FROM personal_profiles").fetchone()[0]
            if not existing:
                conn.execute("INSERT INTO personal_profiles (name, demo_data) VALUES (?, ?)",
                             ("Local user", False))
        _INITIALISED = True


def _scenario_outputs(inputs: dict[str, float]) -> dict[str, Any]:
    saved = inputs.get("monthly_saving", 0) * 12
    debt_saved = inputs.get("extra_debt_payment", 0) * 12
    subscription_redirect = inputs.get("cancelled_subscriptions", 0) * 12
    return {
        "annual_savings_contributions": round(saved, 2),
        "annual_extra_debt_payments": round(debt_saved, 2),
        "annual_subscription_savings": round(subscription_redirect, 2),
        "annual_cash_improvement": round(subscription_redirect - saved - debt_saved, 2),
        "calm_summary": "Small repeated choices move the year more than a dramatic one-off cut.",
        "boundary": "Scenario only; not financial advice.",
    }


def _review_pack_payload() -> dict[str, Any]:
    return {
        "sections": ["accounts", "budget", "goals", "debt", "tax evidence", "scenarios", "reminders"],
        "source_links": ["/api/personal-finance/drilldown/budget", "/api/personal-finance/rag/search?q=tax"],
        "boundary": "Generated locally; not sent anywhere.",
    }


def _field_helpers() -> list[tuple[str, str, str, str, str, bool]]:
    return [
        ("accounts", "balance", "source_freshness", "Shows whether this figure is synthetic, manual, imported, or source-backed.", "Open source rows", False),
        ("budget", "variance", "calm_explain", "Explains variance as pace and context, not failure.", "Show why", False),
        ("goals", "target_date", "future_self", "Turns a distant date into a daily or weekly number.", "Calculate pace", False),
        ("debt", "interest_rate", "cost_reduction", "Shows monthly interest pressure and a low-risk extra-payment option.", "Compare avalanche", False),
        ("tax", "evidence_strength", "proof", "Links claims back to receipts or marks them as missing evidence.", "Open evidence", False),
        ("admin", "database", "proof", "Shows SQLite and text search, and route proof for the operator.", "Open proof", True),
    ]


def index_approved_rag_sources(conn: Any | None = None, profile_id: int | None = None) -> dict[str, Any]:
    return {"message": "Feature not in this build. Upload a CSV or PDF for local text search.",
            "sources": 0, "chunks_seen": 0, "inserted": 0}


def index_nas_sources(max_files: int = 120, max_chunks_per_file: int = 3) -> dict[str, Any]:
    return {"message": "Feature not in this build", "external_send": False}


def index_user_upload(source_path: Path, original_filename: str, file_size_bytes: int) -> dict[str, Any]:
    init_personal_finance_store()
    suffix = source_path.suffix.lower()
    if suffix not in USER_UPLOAD_EXTENSIONS:
        raise ValueError("Only CSV and PDF uploads are accepted for CK Personal Finance local evidence.")
    document_type = "user_uploaded_pdf" if suffix == ".pdf" else "user_uploaded_csv"
    boundary = "User-provided local evidence only; no bank connection, provider send, external write, payment action, cancellation action, or regulated advice."
    with _sqlite_conn() as conn:
        profile_id = _profile_id(conn)
        chunks = _read_source_chunks(source_path, max_chunks=24)
        inserted = _insert_evidence_chunks(conn, profile_id, chunks, document_type)
        receipt_id = conn.execute(
            """
            INSERT INTO user_upload_receipts
                (profile_id, original_filename, stored_path, file_type, file_size_bytes, indexed_chunks, external_send, boundary)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id
            """,
            (profile_id, original_filename, str(source_path), document_type, file_size_bytes, inserted, False, boundary),
        ).fetchone()["id"]
    return {
        "receipt_id": receipt_id,
        "original_filename": original_filename,
        "stored_path": str(source_path),
        "file_type": document_type,
        "file_size_bytes": file_size_bytes,
        "indexed_chunks": inserted,
        "external_send": False,
        "boundary": boundary,
        "mode": "sqlite_text_user_upload",
    }


def save_user_upload(file_obj: Any, filename: str, content_type: str | None = None) -> dict[str, Any]:
    safe_name = _safe_upload_name(filename)
    suffix = Path(safe_name).suffix.lower()
    if suffix not in USER_UPLOAD_EXTENSIONS:
        raise ValueError("Only CSV and PDF uploads are accepted for CK Personal Finance local evidence.")
    USER_UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    digest = uuid4().hex
    destination = USER_UPLOAD_ROOT / f"{stamp}-{digest}-{safe_name}"
    size = 0
    with destination.open("xb") as out:
        while True:
            chunk = file_obj.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_USER_UPLOAD_BYTES:
                out.close()
                destination.unlink(missing_ok=True)
                raise ValueError("CSV/PDF upload is too large for the local evidence intake limit.")
            out.write(chunk)
    if size == 0:
        destination.unlink(missing_ok=True)
        raise ValueError("Uploaded file was empty.")
    try:
        result = index_user_upload(destination, filename, size)
    except ValueError:
        destination.unlink(missing_ok=True)
        raise
    result["content_type"] = content_type or "unknown"
    result["max_bytes"] = MAX_USER_UPLOAD_BYTES
    return result


def search_rag(query: str, limit: int = 5) -> dict[str, Any]:
    init_personal_finance_store()
    query = query.strip()
    if not query:
        return {"mode": "sqlite_text", "query": query, "results": []}
    limit = max(1, min(int(limit), 50))
    with _sqlite_conn() as conn:
        rows = conn.execute(
            """SELECT title, document_type, source_path, evidence_text, 1.0 AS score
               FROM finance_document_evidence
               WHERE instr(lower(evidence_text), ?) > 0 OR instr(lower(title), ?) > 0
               ORDER BY id DESC LIMIT ?""",
            (query.lower(), query.lower(), limit),
        ).fetchall()
    return {"mode": "sqlite_text", "query": query, "results": [dict(row) for row in rows]}


def get_persistence_snapshot() -> dict[str, Any]:
    init_personal_finance_store()
    with _sqlite_conn() as conn:
        counts = {}
        for table in TABLES:
            if table in ("personal_account_groups", "savings_goals", "debt_plans", "finance_reminders"):
                counts[table] = conn.execute(f"SELECT COUNT(*) AS count FROM {table} WHERE COALESCE(demo_hidden,0)=0").fetchone()["count"]
            else:
                counts[table] = conn.execute(f"SELECT COUNT(*) AS count FROM {table}").fetchone()["count"]
        profile = dict(conn.execute("SELECT id, name, currency, timezone, demo_data FROM personal_profiles ORDER BY id LIMIT 1").fetchone())
        has_batches = conn.execute("SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table' AND name='import_batches'").fetchone()["c"]
        real_import = bool(has_batches) and bool(conn.execute("SELECT COUNT(*) AS c FROM import_batches WHERE status='committed' AND rows_committed>0").fetchone()["c"])
        goals = [dict(row) for row in conn.execute("SELECT name, target_amount, saved_amount, target_date, status FROM savings_goals WHERE COALESCE(demo_hidden,0)=0 ORDER BY id").fetchall()]
        debts = [dict(row) for row in conn.execute("SELECT name, current_balance, repayment_amount, repayment_frequency, interest_rate, status FROM debt_plans WHERE COALESCE(demo_hidden,0)=0 ORDER BY id").fetchall()]
        latest_receipts = [dict(row) for row in conn.execute("SELECT id, decision_type AS type, context, boundary, created_at FROM finance_decision_receipts ORDER BY id DESC LIMIT 5").fetchall()]
    return {
        "store": APP_MODE,
        "runtime_state": "active_sqlite_runtime",
        "search_contract": {
            "method": "text",
            "rag_status": "indexed_and_searchable" if counts["finance_document_evidence"] else "empty",
        },
        "profile": profile,
        "table_counts": counts,
        "savings_goals": goals,
        "debt_plans": debts,
        "latest_receipts": latest_receipts,
        "demo_data": {
            "present": bool(profile.get("demo_data")),
            "real_import_present": real_import,
            "classification": ("mixed" if real_import else "demo_only") if profile.get("demo_data") else ("real_only" if real_import else "empty"),
            "boundary": "The first-start profile is empty; only user-provided evidence is indexed.",
            "removal_path": "DELETE FROM personal_profiles WHERE demo_data = true; cascades through local finance tables.",
        },
        "blocked_external_actions": [
            "live_bank_connection",
            "provider_or_model_send",
            "regulated_financial_advice",
            "external_write",
        ],
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def create_local_receipt(decision_type: str, context: str) -> dict[str, Any]:
    init_personal_finance_store()
    boundary = "Local planning receipt only; no regulated financial advice, bank action, provider send, or external write."
    with _sqlite_conn() as conn:
        receipt_id = conn.execute(
            """
            INSERT INTO finance_decision_receipts
                (profile_id, decision_type, context, boundary, source_refs)
            VALUES (?, ?, ?, ?, ?) RETURNING id
            """,
            (_profile_id(conn), decision_type, context, boundary, json.dumps(["local_user_action", "ck_personal_finance"])),
        ).fetchone()["id"]
    return {
        "receipt_id": receipt_id,
        "decision_type": decision_type,
        "context": context,
        "boundary": boundary,
        "external_write": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def get_drilldown(surface: str) -> dict[str, Any]:
    init_personal_finance_store()
    snapshot = get_persistence_snapshot()
    with _sqlite_conn() as conn:
        accounts = [dict(row) for row in conn.execute("SELECT name, group_type, current_balance, source_state FROM personal_account_groups WHERE COALESCE(demo_hidden,0)=0 ORDER BY id").fetchall()]
        reminders = [dict(row) for row in conn.execute("SELECT title, due_date, status, source_ref FROM finance_reminders WHERE COALESCE(demo_hidden,0)=0 ORDER BY due_date LIMIT 10").fetchall()]
        scenarios = [dict(row) for row in conn.execute("SELECT name, scenario_type, inputs, outputs, boundary FROM scenario_plans ORDER BY id").fetchall()]
        reports = [dict(row) for row in conn.execute("SELECT id, report_type, title, payload, source_refs, external_send_state FROM report_exports ORDER BY id DESC LIMIT 5").fetchall()]
        uploads = [dict(row) for row in conn.execute("SELECT id, original_filename, indexed_chunks, created_at FROM user_upload_receipts ORDER BY id DESC LIMIT 20").fetchall()]
        helpers = [dict(row) for row in conn.execute("SELECT surface, field_name, helper_type, helper_text, micro_action, admin_only FROM field_helpers WHERE surface = ? OR surface = 'admin' ORDER BY admin_only, field_name", (surface,)).fetchall()]
        try:
            transactions = [dict(row) for row in conn.execute("SELECT t.id, t.tx_date AS date, t.description, t.amount, t.category, g.name AS account_name, g.source_state FROM personal_transactions t JOIN personal_account_groups g ON g.id = t.account_group_id AND COALESCE(g.demo_hidden,0)=0 ORDER BY t.tx_date DESC, t.id DESC LIMIT 50").fetchall()]
        except Exception:
            transactions = []
        try:
            import_batches = [dict(row) for row in conn.execute("SELECT b.id, b.original_filename, b.rows_committed, b.amount_total, b.status, b.created_at, b.undone_at, g.name AS account_name FROM import_batches b JOIN personal_account_groups g ON g.id = b.account_group_id AND COALESCE(g.demo_hidden,0)=0 ORDER BY b.id DESC LIMIT 10").fetchall()]
        except Exception:
            import_batches = []
    for row in scenarios:
        row["inputs"] = json.loads(row["inputs"])
        row["outputs"] = json.loads(row["outputs"])
    for row in reports:
        row["payload"] = json.loads(row["payload"])
        row["source_refs"] = json.loads(row["source_refs"])
    try:
        from app.services.recurring import detect_recurring
        recurring_items = detect_recurring()
    except Exception:
        recurring_items = []
    bills_detected = [r for r in recurring_items if r["kind"] == "bill"]
    subscriptions_detected = [r for r in recurring_items if r["kind"] == "subscription"]
    def _insight(fn_name, fallback):
        try:
            from app.services import insights as _insights
            return getattr(_insights, fn_name)()
        except Exception:
            return {"honesty": fallback, "unavailable": True}
    groups = {"transactions": transactions, "receipts": snapshot["latest_receipts"], "accounts": accounts, "savings_goals": snapshot["savings_goals"],
              "debt_plans": snapshot["debt_plans"], "reminders": reminders,
              "scenarios": scenarios, "reports": reports, "helpers": helpers, "uploads": uploads,
              "bills_detected": bills_detected, "subscriptions_detected": subscriptions_detected,
              "import_batches": import_batches,
              "forecast": _insight("forecast", "Forecast could not be computed right now."),
              "safe_to_spend": _insight("safe_to_spend", "Safe-to-spend could not be computed right now."),
              "fees_report": _insight("fees_and_duplicates", "Fee and duplicate scan could not run right now."),
              "merchants": _insight("merchants", "Merchant list could not be built right now."),
              "refunds": _insight("refunds", "Refund view could not be built right now.")}
    surface_groups = {"cashflow": ["transactions"], "accounts": ["accounts"], "goals": ["savings_goals"], "debt": ["debt_plans"],
                      "reminders": ["reminders"], "scenarios": ["scenarios"], "tax": ["uploads", "helpers"], "reports": list(groups),
                      "bills": ["reminders", "bills_detected"], "subscriptions": ["subscriptions_detected"],
                      "import-reconcile": ["import_batches", "helpers"],
                      "forecast": ["forecast"], "safe-to-spend": ["safe_to_spend"], "fees": ["fees_report"],
                      "merchants": ["merchants"], "refunds": ["refunds"]}
    named = {key: groups[key] for key in surface_groups.get(surface, list(groups))}
    return {
        "surface": surface,
        "rows": {
            "accounts": snapshot["table_counts"]["personal_account_groups"],
            "goals": snapshot["table_counts"]["savings_goals"],
            "debts": snapshot["table_counts"]["debt_plans"],
            "reminders": len(reminders),
            "scenarios": len(scenarios),
            "reports": len(reports),
        },
        "named_rows": named,
        "six_w": {
            "what": f"{surface} local/internal detail",
            "who": "Operator only; no external party receives this data.",
            "why": "Shows the exact rows behind the count so the user stays in control.",
            "when": "Use during local review, EOFY prep, or quiet weekly money check.",
            "where": "Stored in the local SQLite file under CKPF_DATA_DIR.",
            "how": "Rows are source-linked, receipt-backed, and bounded by no-advice/no-external-send rules.",
            "eli10": "This opens the drawer behind the number so you can see what it is made of.",
        },
    }


def create_report_export(report_type: str = "local_review_pack") -> dict[str, Any]:
    init_personal_finance_store()
    payload = {**_review_pack_payload(), "data": get_drilldown("reports")["named_rows"], "synthetic": get_persistence_snapshot()["demo_data"]["present"]}
    payload["data"].pop("reports", None)
    with _sqlite_conn() as conn:
        export_id = conn.execute(
            "INSERT INTO report_exports (profile_id, report_type, title, payload, source_refs, external_send_state) VALUES (?, ?, ?, ?, ?, ?) RETURNING id",
            (_profile_id(conn), report_type, "CK Personal Finance local review pack", json.dumps(payload, default=str), json.dumps(["local_runtime", "rag_sources", "receipts"]), "not_sent"),
        ).fetchone()["id"]
    return {"export_id": export_id, "report_type": report_type, "payload": payload, "external_send_state": "not_sent"}


def audit_delivery(iteration: int) -> dict[str, Any]:
    snapshot = get_persistence_snapshot()
    done = 0
    partial = len(WORKFLOW_IDS)
    blocked = 0
    missing = 0
    notes = "Record inventory only. End-to-end workflow completion requires independent test evidence."
    with _sqlite_conn() as conn:
        conn.execute(
            "INSERT INTO audit_iterations (iteration, done_count, partial_count, blocked_count, missing_count, notes) VALUES (?, ?, ?, ?, ?, ?)",
            (iteration, done, partial, blocked, missing, notes),
        )
    return {"iteration": iteration, "done": done, "partial": partial, "blocked": blocked, "missing": missing, "notes": notes}