"""Bank statement import for CK Personal Finance: parse, preview, confirm, undo. Local-only; no external sends."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import sqlite3
from uuid import uuid4
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from app.config import DATA_DIR

DB_PATH = DATA_DIR / "personal-finance.sqlite3"
PENDING_DIR = DATA_DIR / "pending-imports"

_DDL = """
CREATE TABLE IF NOT EXISTS personal_transactions(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  account_group_id INTEGER NOT NULL,
  tx_date TEXT NOT NULL,
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  category TEXT NOT NULL DEFAULT 'Uncategorised',
  source_ref TEXT NOT NULL DEFAULT 'statement_import',
  import_batch_id INTEGER,
  dedupe_hash TEXT UNIQUE,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS import_batches(
  id INTEGER PRIMARY KEY,
  profile_id INTEGER NOT NULL,
  account_group_id INTEGER NOT NULL,
  original_filename TEXT NOT NULL,
  rows_committed INTEGER NOT NULL,
  amount_total REAL NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  undone_at TEXT
);
"""

_DATE_FORMATS = ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d %b %Y", "%d %B %Y", "%d/%m/%y"]

_HEADER_KEYS = {
    "date": ["date", "transaction date", "posted date", "posting date", "effective date", "processed date"],
    "description": ["description", "narrative", "text", "details", "transaction details", "transaction description", "payee", "merchant", "transaction", "particulars", "reference"],
    "amount": ["amount", "transaction amount", "value", "amt", "amount (aud)", "amount aud", "amount ($)"],
    "debit": ["debit", "debit amount", "withdrawal", "withdrawals", "money out", "paid out", "dr", "dr amount", "debit ($)"],
    "credit": ["credit", "credit amount", "deposit", "deposits", "money in", "paid in", "cr", "cr amount", "credit ($)"],
    "balance": ["balance", "running balance", "closing balance", "available balance", "balance ($)"],
}

CATEGORIES = ["Income", "Groceries", "Dining", "Transport", "Fuel", "Utilities", "Rent", "Insurance", "Health", "Entertainment", "Shopping", "Fees & charges", "Transfer", "Cash", "Uncategorised"]

_CATEGORY_RULES = [
    (r"salary|wage|payroll|interest paid|refund|reimburs", "Income"),
    (r"woolworths|coles|aldi|iga|grocer|supermarket", "Groceries"),
    (r"coffee|cafe|restaurant|mcdonald|kfc|subway|pizza|uber ?eats|deliveroo|menulog|dining", "Dining"),
    (r"opal|transport|uber(?! ?eats)|taxi|cabcharge|trainline|sydney trains|bus", "Transport"),
    (r"bp |shell|caltex|ampol|petrol|fuel|7-eleven", "Fuel"),
    (r"agl|origin energy|energyaustralia|telstra|optus|vodafone|tpg|iiNet|sydney water|electricity|gas bill|internet", "Utilities"),
    (r"rent|landlord|real estate", "Rent"),
    (r"insurance|nrma|allianz|aami|bupa|medibank", "Insurance"),
    (r"pharmacy|chemist|doctor|dentist|medical|hospital", "Health"),
    (r"netflix|spotify|stan|disney|cinema|event cinemas|ticketek", "Entertainment"),
    (r"amazon|ebay|kmart|target|big w|jb hi|bunnings|officeworks", "Shopping"),
    (r"fee|charge|honour|dishonour|overdrawn", "Fees & charges"),
    (r"transfer|tfr|payid|osko", "Transfer"),
    (r"atm|cash", "Cash"),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_import_store() -> None:
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    conn = _conn()
    try:
        for _t in ("personal_account_groups", "savings_goals", "debt_plans", "finance_reminders"):
            try:
                conn.execute("ALTER TABLE " + _t + " ADD COLUMN demo_hidden INTEGER NOT NULL DEFAULT 0")
            except Exception:
                pass
        with conn:
            for stmt in _DDL.split(";"):
                if stmt.strip():
                    conn.execute(stmt)
    finally:
        conn.close()


def _profile_id(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    if not row:
        with conn:
            conn.execute("INSERT INTO personal_profiles(name, currency, timezone, demo_data) VALUES ('Local user', 'AUD', 'Australia/Sydney', 0)")
        row = conn.execute("SELECT id FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
    return int(row["id"])


def _parse_date(raw: str) -> str | None:
    raw = raw.strip().strip('"')
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def _parse_amount(raw: str) -> float | None:
    s = (raw or "").strip().replace("$", "").replace(",", "").replace(" ", "")
    if not s:
        return None
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    try:
        v = float(s)
    except ValueError:
        return None
    return -v if neg else v


def _map_headers(header: list[str]) -> dict[str, int]:
    norm = [h.strip().lower().strip('"') for h in header]
    found: dict[str, int] = {}
    for key, names in _HEADER_KEYS.items():
        for i, h in enumerate(norm):
            if h in names:
                found[key] = i
                break
    # second pass: substring matching, specific keys before the generic "amount",
    # and never reuse a column already claimed (so "Debit Amount" stays debit).
    used = set(found.values())
    for key in ["date", "description", "debit", "credit", "balance", "amount"]:
        if key in found:
            continue
        names = _HEADER_KEYS[key]
        for i, h in enumerate(norm):
            if i in used:
                continue
            if any(len(n) > 4 and n in h for n in names):
                found[key] = i
                used.add(i)
                break
    return found


def suggest_category(description: str) -> str:
    d = description.lower()
    for pattern, cat in _CATEGORY_RULES:
        if re.search(pattern, d):
            return cat
    return "Uncategorised"


def _dedupe_hash(account_key: str, tx_date: str, amount: float, description: str) -> str:
    norm = re.sub(r"\s+", " ", description.strip().lower())
    base = f"{account_key}|{tx_date}|{int(round(amount * 100))}|{norm}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()


def parse_csv_text(text: str) -> tuple[list[dict[str, Any]], str]:
    sample = text.lstrip("\ufeff")
    lines = [ln for ln in sample.splitlines() if ln.strip()]
    if not lines:
        raise ValueError("The CSV file was empty.")
    reader = csv.reader(io.StringIO("\n".join(lines)))
    rows_raw = list(reader)
    mapping = _map_headers(rows_raw[0])
    if "date" not in mapping or "description" not in mapping or ("amount" not in mapping and "debit" not in mapping and "credit" not in mapping):
        raise ValueError("Could not recognise the CSV columns. Need a date, a description, and an amount (or debit/credit) column. Found: " + ", ".join(rows_raw[0]))
    out: list[dict[str, Any]] = []
    skipped = 0
    for raw in rows_raw[1:]:
        if len(raw) <= max(mapping.values()):
            skipped += 1
            continue
        tx_date = _parse_date(raw[mapping["date"]])
        desc = raw[mapping["description"]].strip().strip('"')
        if not tx_date or not desc:
            skipped += 1
            continue
        if "amount" in mapping:
            amount = _parse_amount(raw[mapping["amount"]])
        else:
            debit = _parse_amount(raw[mapping["debit"]]) if "debit" in mapping else None
            credit = _parse_amount(raw[mapping["credit"]]) if "credit" in mapping else None
            if debit is None and credit is None:
                amount = None
            else:
                amount = (credit or 0.0) - (debit or 0.0)
        if amount is None:
            skipped += 1
            continue
        balance = _parse_amount(raw[mapping["balance"]]) if "balance" in mapping else None
        out.append({"date": tx_date, "description": desc, "amount": round(amount, 2), "balance": balance})
    info = f"parsed {len(out)} rows, skipped {skipped}"
    return out, info


_PDF_LINE = re.compile(r"^\s*(\d{2}/\d{2}/\d{4})\s+(.+?)\s+(-?\(?\$?[\d,]+\.\d{2}\)?)\s*(-?\(?\$?[\d,]+\.\d{2}\)?)?\s*$")


_MONTHS = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6, "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}
_MQ_HEADER = re.compile(r"^([A-Z][a-z]{2})\s+(\d{4})$")
_MQ_ROW_START = re.compile(r"^([A-Z][a-z]{2})\s+(\d{1,2})\s+(.+)$")
_MQ_AMOUNTS_TAIL = re.compile(r"([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+(CR|DR)\s*$")
_MQ_OPENING = re.compile(r"^Opening balance\s+([\d,]+\.\d{2})\s+(CR|DR)\s*$")
_MQ_SKIP = re.compile(r"^(Account Name|Date Transaction|Continue >|Your transactions|Please check|BSB|From \d|Overview|Opening balance -|\$|Transaction Listing Report|Macquarie )")
_MQ_FUSED_ROW = re.compile(r"^(.+?)\s+([A-Z][a-z]{2})\s+(\d{1,2})\s+(?:[A-Za-z]+\s+)?([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+(CR|DR)\s*$")


def _mq_number(raw: str) -> float:
    return float(raw.replace(",", ""))


def _parse_macquarie_lines(lines: list[str]) -> list[dict[str, Any]]:
    """Macquarie 'Transaction Listing Report': month-year headers, 'Nov 10' dates,
    wrapped descriptions, amounts flattened as '<amount> <balance> CR|DR'.
    Debit vs credit is inferred from the running balance movement."""
    out: list[dict[str, Any]] = []
    year: int | None = None
    prev_balance: float | None = None
    pending: dict[str, Any] | None = None

    def flush() -> None:
        nonlocal pending
        if pending is None:
            return
        desc = " ".join(pending["parts"]).strip()
        desc = re.sub(r"\s+", " ", desc)
        if desc and pending["amount"] is not None:
            out.append({"date": pending["date"], "description": desc, "amount": round(pending["amount"], 2), "balance": pending["balance"]})
        pending = None

    for raw in lines:
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped:
            continue
        header = _MQ_HEADER.match(stripped)
        if header and header.group(1) in _MONTHS:
            flush()
            year = int(header.group(2))
            continue
        opening = _MQ_OPENING.match(stripped)
        if opening:
            flush()
            bal = _mq_number(opening.group(1))
            prev_balance = bal if opening.group(2) == "CR" else -bal
            continue
        if _MQ_SKIP.match(stripped):
            continue
        fused = _MQ_FUSED_ROW.match(stripped)
        if fused and fused.group(2) in _MONTHS and year is not None and not _MQ_ROW_START.match(stripped):
            flush()
            try:
                tx_date = date(year, _MONTHS[fused.group(2)], int(fused.group(3))).isoformat()
            except ValueError:
                continue
            amount = _mq_number(fused.group(4))
            bal = _mq_number(fused.group(5))
            balance = bal if fused.group(6) == "CR" else -bal
            if prev_balance is not None:
                signed = amount if balance > prev_balance else -amount
            else:
                signed = -amount
            desc = re.sub(r"\s+", " ", fused.group(1).strip())
            if desc:
                out.append({"date": tx_date, "description": desc, "amount": round(signed, 2), "balance": balance})
            prev_balance = balance
            continue
        start = _MQ_ROW_START.match(stripped)
        rest = stripped
        if start and start.group(1) in _MONTHS and year is not None:
            flush()
            month = _MONTHS[start.group(1)]
            day = int(start.group(2))
            try:
                tx_date = date(year, month, day).isoformat()
            except ValueError:
                continue
            pending = {"date": tx_date, "parts": [], "amount": None, "balance": None}
            rest = start.group(3)
        if pending is None:
            continue
        tail = _MQ_AMOUNTS_TAIL.search(rest)
        if tail:
            desc_part = rest[: tail.start()].strip()
            if desc_part:
                pending["parts"].append(desc_part)
            amount = _mq_number(tail.group(1))
            bal = _mq_number(tail.group(2))
            balance = bal if tail.group(3) == "CR" else -bal
            if prev_balance is not None:
                signed = amount if balance > prev_balance else -amount
            else:
                signed = -amount
            pending["amount"] = signed
            pending["balance"] = balance
            prev_balance = balance
            flush()
        elif rest.strip():
            pending["parts"].append(rest.strip())
    flush()
    return out


def parse_pdf_bytes(data: bytes) -> tuple[list[dict[str, Any]], str]:
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    text = "\n".join((page.extract_text() or "") for page in reader.pages)
    lines = text.splitlines()
    out: list[dict[str, Any]] = []
    for line in lines:
        m = _PDF_LINE.match(line)
        if not m:
            continue
        tx_date = _parse_date(m.group(1))
        amount = _parse_amount(m.group(3))
        balance = _parse_amount(m.group(4)) if m.group(4) else None
        if tx_date and amount is not None:
            out.append({"date": tx_date, "description": m.group(2).strip(), "amount": round(amount, 2), "balance": balance})
    if not out:
        out = _parse_macquarie_lines(lines)
    if not out:
        raise ValueError("No statement rows could be read from that PDF text. Try the bank's CSV export instead.")
    return out, f"parsed {len(out)} rows from PDF text"


def _resolve_account_for_preview(conn: sqlite3.Connection, account_id: int | None, new_account_name: str | None) -> dict[str, Any]:
    if account_id:
        row = conn.execute("SELECT id, name, current_balance, source_state FROM personal_account_groups WHERE id = ?", (account_id,)).fetchone()
        if not row:
            raise ValueError("That account no longer exists.")
        if row["source_state"] == "synthetic_demo" or row["name"].upper().startswith("SAMPLE"):
            raise ValueError("That is a SAMPLE demo account. Type a new account name for your real statement instead - demo accounts cannot take imports.")
        return {"mode": "existing", "id": int(row["id"]), "name": row["name"], "current_balance": row["current_balance"]}
    name = (new_account_name or "").strip()
    if not name:
        raise ValueError("Choose an existing account or name a new one.")
    existing = conn.execute("SELECT id, name, current_balance FROM personal_account_groups WHERE name = ?", (name,)).fetchone()
    if existing:
        return {"mode": "existing", "id": int(existing["id"]), "name": existing["name"], "current_balance": existing["current_balance"]}
    return {"mode": "new", "name": name, "current_balance": 0.0}


def build_preview(data: bytes, filename: str, account_id: int | None, new_account_name: str | None) -> dict[str, Any]:
    init_import_store()
    suffix = (filename or "").lower().rsplit(".", 1)[-1]
    if suffix == "csv":
        rows, info = parse_csv_text(data.decode("utf-8-sig", errors="replace"))
    elif suffix == "pdf":
        rows, info = parse_pdf_bytes(data)
    else:
        raise ValueError("Only CSV and PDF statements are supported.")
    if not rows:
        raise ValueError("No transaction rows found. " + info)
    conn = _conn()
    try:
        account = _resolve_account_for_preview(conn, account_id, new_account_name)
        # Stable hash basis: the normalised account NAME. IDs do not exist for
        # not-yet-created accounts, so hashing by id after the first import would
        # break duplicate detection across the new->existing boundary.
        account_key = " ".join(account["name"].split()).lower()
        existing = set()
        if account.get("id"):
            for r in conn.execute("SELECT dedupe_hash FROM personal_transactions WHERE account_group_id = ?", (account["id"],)).fetchall():
                existing.add(r["dedupe_hash"])
        seen: set[str] = set()
        out_rows = []
        n_new = 0
        for i, row in enumerate(rows):
            h = _dedupe_hash(account_key, row["date"], row["amount"], row["description"])
            dupe = h in existing
            if not dupe and h in seen:
                # Same date, amount and description appears again inside one statement:
                # a legitimate repeat purchase, not a re-import. Keep the row and
                # disambiguate its hash so both import (and a later re-import of the
                # same file still dedupes correctly against the database).
                n = 2
                while _dedupe_hash(account_key, row["date"], row["amount"], row["description"] + f" (repeat {n})") in seen:
                    n += 1
                h = _dedupe_hash(account_key, row["date"], row["amount"], row["description"] + f" (repeat {n})")
                row["repeat_in_file"] = True
            seen.add(h)
            if not dupe:
                n_new += 1
            out_rows.append({
                "i": i, "date": row["date"], "description": row["description"], "amount": row["amount"],
                "balance": row["balance"], "duplicate": dupe, "category": suggest_category(row["description"]), "hash": h,
            })
        net = round(sum(r["amount"] for r in out_rows if not r["duplicate"]), 2)
        current = account.get("current_balance") or 0.0
        opening = 0.0
        if account["mode"] == "new":
            with_balance = [r for r in out_rows if not r["duplicate"] and r.get("balance") is not None]
            if with_balance:
                opening = round(with_balance[0]["balance"] - with_balance[0]["amount"], 2)
        token = uuid4().hex
        (PENDING_DIR / f"{token}.json").write_text(json.dumps({"filename": filename, "account": account, "rows": out_rows, "opening_balance": opening, "created_at": _now()}))
        return {
            "token": token, "filename": filename, "parse_info": info, "account": account,
            "rows_total": len(out_rows), "rows_new": n_new, "rows_duplicate": len(out_rows) - n_new,
            "net_amount": net, "opening_balance": opening, "balance_after": round(current + opening + net, 2),
            "rows": out_rows, "categories": CATEGORIES,
        }
    finally:
        conn.close()


def confirm_import(token: str, category_overrides: dict[int, str] | None = None) -> dict[str, Any]:
    init_import_store()
    path = PENDING_DIR / f"{token}.json"
    if not path.exists():
        raise ValueError("That preview has expired or was already imported. Run the preview again.")
    pending = json.loads(path.read_text())
    account = pending["account"]
    rows = pending["rows"]
    overrides = category_overrides or {}
    conn = _conn()
    try:
        pid = _profile_id(conn)
        with conn:
            if account["mode"] == "new":
                opening = float(pending.get("opening_balance") or 0.0)
                cur = conn.execute(
                    "INSERT INTO personal_account_groups(profile_id, name, group_type, current_balance, source_state) VALUES (?,?,?,?,?)",
                    (pid, account["name"], "transaction", opening, "user_import"),
                )
                account_id = int(cur.lastrowid)
            else:
                account_id = int(account["id"])
            cur = conn.execute(
                "INSERT INTO import_batches(profile_id, account_group_id, original_filename, rows_committed, amount_total, status, created_at) VALUES (?,?,?,?,?,?,?)",
                (pid, account_id, pending["filename"], 0, 0.0, "committed", _now()),
            )
            batch_id = int(cur.lastrowid)
            committed = 0
            total = 0.0
            for row in rows:
                if row["duplicate"]:
                    continue
                cat = overrides.get(row["i"]) or overrides.get(str(row["i"])) or row["category"]
                if cat not in CATEGORIES:
                    cat = "Uncategorised"
                cur = conn.execute(
                    "INSERT OR IGNORE INTO personal_transactions(profile_id, account_group_id, tx_date, description, amount, category, source_ref, import_batch_id, dedupe_hash, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (pid, account_id, row["date"], row["description"], row["amount"], cat, "statement_import", batch_id, row["hash"], _now()),
                )
                if cur.rowcount == 1:
                    committed += 1
                    total = round(total + row["amount"], 2)
            conn.execute("UPDATE import_batches SET rows_committed = ?, amount_total = ? WHERE id = ?", (committed, total, batch_id))
            conn.execute("UPDATE personal_account_groups SET current_balance = round(current_balance + ?, 2) WHERE id = ?", (total, account_id))
            conn.execute(
                "INSERT INTO import_rollback_receipts(profile_id, import_source, rows_previewed, rows_committed, rollback_state, source_confidence, created_at) VALUES (?,?,?,?,?,?,?)",
                (pid, pending["filename"], len(rows), committed, "committed", "parsed_local_statement", _now()),
            )
            # A real committed import relabels the first-run synthetic profile name.
            # Synthetic rows themselves are untouched and stay governed by demo/show|hide.
            conn.execute("UPDATE personal_profiles SET name = 'Local user' WHERE name = 'SAMPLE Household (synthetic)'")
        path.unlink(missing_ok=True)
        bal = conn.execute("SELECT current_balance FROM personal_account_groups WHERE id = ?", (account_id,)).fetchone()["current_balance"]
        return {"batch_id": batch_id, "account_id": account_id, "rows_committed": committed, "amount_total": total, "new_balance": bal, "filename": pending["filename"]}
    finally:
        conn.close()


def undo_last_import() -> dict[str, Any]:
    init_import_store()
    conn = _conn()
    try:
        batch = conn.execute("SELECT * FROM import_batches WHERE status = 'committed' ORDER BY id DESC LIMIT 1").fetchone()
        if not batch:
            raise ValueError("No import to undo.")
        batch_id = int(batch["id"])
        with conn:
            rows = conn.execute("SELECT amount FROM personal_transactions WHERE import_batch_id = ?", (batch_id,)).fetchall()
            total = round(sum(r["amount"] for r in rows), 2)
            n = conn.execute("DELETE FROM personal_transactions WHERE import_batch_id = ?", (batch_id,)).rowcount
            conn.execute("UPDATE personal_account_groups SET current_balance = round(current_balance - ?, 2) WHERE id = ?", (total, batch["account_group_id"]))
            remaining = conn.execute("SELECT COUNT(*) AS c FROM personal_transactions WHERE account_group_id = ?", (batch["account_group_id"],)).fetchone()["c"]
            if remaining == 0:
                # an import-created account that is empty again returns to a zero
                # balance, including any opening balance the import seeded
                conn.execute("UPDATE personal_account_groups SET current_balance = 0.0 WHERE id = ? AND source_state = 'user_import'", (batch["account_group_id"],))
            conn.execute("UPDATE import_batches SET status = 'undone', undone_at = ? WHERE id = ?", (_now(), batch_id))
            conn.execute(
                "INSERT INTO import_rollback_receipts(profile_id, import_source, rows_previewed, rows_committed, rollback_state, source_confidence, created_at) VALUES (?,?,?,?,?,?,?)",
                (batch["profile_id"], batch["original_filename"], n, 0, "rolled_back", "undo_last_import", _now()),
            )
        bal = conn.execute("SELECT current_balance FROM personal_account_groups WHERE id = ?", (batch["account_group_id"],)).fetchone()["current_balance"]
        return {"undone_batch_id": batch_id, "rows_removed": n, "amount_reversed": total, "new_balance": bal, "filename": batch["original_filename"]}
    finally:
        conn.close()


def list_transactions(account_id: int | None = None, limit: int = 100) -> dict[str, Any]:
    init_import_store()
    conn = _conn()
    try:
        q = "SELECT t.id, t.tx_date, t.description, t.amount, t.category, t.import_batch_id, g.name AS account_name FROM personal_transactions t JOIN personal_account_groups g ON g.id = t.account_group_id AND COALESCE(g.demo_hidden,0)=0"
        args: list[Any] = []
        if account_id:
            q += " WHERE t.account_group_id = ?"
            args.append(account_id)
        q += " ORDER BY t.tx_date DESC, t.id DESC LIMIT ?"
        args.append(limit)
        rows = [dict(r) for r in conn.execute(q, args).fetchall()]
        accounts = [dict(r) for r in conn.execute("SELECT id, name, group_type, current_balance FROM personal_account_groups WHERE COALESCE(demo_hidden,0)=0 ORDER BY id").fetchall()]
        return {"transactions": rows, "accounts": accounts, "categories": CATEGORIES}
    finally:
        conn.close()


def delete_empty_account(account_id: int) -> dict[str, Any]:
    """Delete a user-created account only when it is empty: no imported rows, zero balance."""
    init_import_store()
    conn = _conn()
    try:
        row = conn.execute(
            "SELECT id, name, current_balance, source_state FROM personal_account_groups WHERE id = ?", (account_id,)
        ).fetchone()
        if not row:
            raise ValueError("Account not found.")
        if row["source_state"] == "synthetic_demo":
            raise ValueError("SAMPLE demo accounts are removed with Hide demo data, not deleted.")
        n_tx = conn.execute(
            "SELECT COUNT(*) c FROM personal_transactions WHERE account_group_id = ?", (account_id,)
        ).fetchone()["c"]
        if n_tx:
            raise ValueError(f"Account has {n_tx} imported transaction(s); undo those imports first.")
        if abs(float(row["current_balance"])) > 0.004:
            raise ValueError("Account balance is not zero; only empty accounts can be deleted.")
        with conn:
            conn.execute("DELETE FROM personal_account_groups WHERE id = ?", (account_id,))
        return {"deleted": account_id, "name": row["name"]}
    finally:
        conn.close()


def update_category(tx_id: int, category: str) -> dict[str, Any]:
    if category not in CATEGORIES:
        raise ValueError("Unknown category.")
    conn = _conn()
    try:
        with conn:
            cur = conn.execute("UPDATE personal_transactions SET category = ? WHERE id = ?", (category, tx_id))
        if cur.rowcount != 1:
            raise ValueError("Transaction not found.")
        return {"id": tx_id, "category": category}
    finally:
        conn.close()
