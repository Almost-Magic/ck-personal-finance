"""Normalise supported bill images to PNG for the controlled PNG-only OCR engine."""
from pathlib import Path
import sys
import warnings
from PIL import Image, ImageOps
MAX_PIXELS = 25_000_000
Image.MAX_IMAGE_PIXELS = MAX_PIXELS
warnings.simplefilter('error', Image.DecompressionBombWarning)

def render(source, target):
    with Image.open(source) as image:
        frames = getattr(image, 'n_frames', 1)
        count = min(frames, 3)
        for i in range(count):
            image.seek(i)
            if image.width <= 0 or image.height <= 0 or image.width * image.height > MAX_PIXELS:
                raise ValueError('Image is too large for safe local OCR.')
            normal = ImageOps.exif_transpose(image)
            try:
                rgb = normal.convert('RGB')
                try:
                    rgb.save(str(target) + '-%d.png' % (i+1), format='PNG')
                finally:
                    rgb.close()
            finally:
                if normal is not image:
                    normal.close()
        import json
        print(json.dumps({'frames_total': frames, 'frames_processed': count}))

if __name__ == '__main__':
    render(Path(sys.argv[1]), Path(sys.argv[2]))
