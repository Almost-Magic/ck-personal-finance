# Author: Mani Padisetti
"""Narrative intelligence service — AI commentary, variance, anomalies."""

from app.services.reports import trial_balance, profit_and_loss, balance_sheet, cash_flow
from app.database import get_db


async def generate_commentary(report_type: str, from_date: str | None = None,
                                to_date: str | None = None, as_at_date: str | None = None) -> dict:
    """Generate AI commentary for a financial report."""
    # Get the report data
    if report_type == "trial_balance":
        data = trial_balance(from_date=from_date, to_date=to_date)
    elif report_type == "profit_and_loss":
        if not from_date or not to_date:
            return {"error": "from_date and to_date required for P&L"}
        data = profit_and_loss(from_date, to_date)
    elif report_type == "balance_sheet":
        if not as_at_date:
            return {"error": "as_at_date required for Balance Sheet"}
        data = balance_sheet(as_at_date)
    elif report_type == "cash_flow":
        if not from_date or not to_date:
            return {"error": "from_date and to_date required for Cash Flow"}
        data = cash_flow(from_date, to_date)
    else:
        return {"error": f"Unknown report type: {report_type}"}

    # Graceful degradation — return numeric summary
    return {
        "report_type": report_type,
        "commentary": _numeric_summary(report_type, data),
        "generated": False,
        "data": data,
    }


def _numeric_summary(report_type: str, data: dict) -> str:
    """Fallback numeric summary when AI is unavailable."""
    if report_type == "profit_and_loss":
        return (
            f"P&L Summary ({data.get('from_date')} to {data.get('to_date')}): "
            f"Revenue ${data.get('total_revenue', 0):,.2f}, "
            f"Expenses ${data.get('total_expenses', 0):,.2f}, "
            f"Net Profit ${data.get('net_profit', 0):,.2f}."
        )
    elif report_type == "balance_sheet":
        return (
            f"Balance Sheet as at {data.get('as_at_date')}: "
            f"Assets ${data.get('total_assets', 0):,.2f}, "
            f"Liabilities ${data.get('total_liabilities', 0):,.2f}, "
            f"Equity ${data.get('total_equity', 0):,.2f}."
        )
    elif report_type == "cash_flow":
        return (
            f"Cash Flow ({data.get('from_date')} to {data.get('to_date')}): "
            f"Operating ${data.get('operating_activities', {}).get('total', 0):,.2f}, "
            f"Net Change ${data.get('net_change_in_cash', 0):,.2f}."
        )
    return (
        f"Trial Balance: Debits ${data.get('total_debits', 0):,.2f}, "
        f"Credits ${data.get('total_credits', 0):,.2f}, "
        f"Balanced: {data.get('is_balanced')}."
    )


async def variance_analysis(from_date_1: str, to_date_1: str,
                             from_date_2: str, to_date_2: str) -> dict:
    """Period-over-period variance analysis."""
    pnl_1 = profit_and_loss(from_date_1, to_date_1)
    pnl_2 = profit_and_loss(from_date_2, to_date_2)

    variances = []
    # Compare revenue accounts
    accounts_1 = {a["account_id"]: a for items in [pnl_1["revenue"], pnl_1["expenses"], pnl_1["cogs"]]
                  for a in items}
    accounts_2 = {a["account_id"]: a for items in [pnl_2["revenue"], pnl_2["expenses"], pnl_2["cogs"]]
                  for a in items}

    all_ids = set(accounts_1.keys()) | set(accounts_2.keys())
    for aid in sorted(all_ids):
        a1 = accounts_1.get(aid, {})
        a2 = accounts_2.get(aid, {})
        amount_1 = a1.get("amount", 0)
        amount_2 = a2.get("amount", 0)
        change = round(amount_2 - amount_1, 2)
        pct = round((change / amount_1) * 100, 1) if amount_1 != 0 else None

        variances.append({
            "account_id": aid,
            "code": a1.get("code") or a2.get("code"),
            "name": a1.get("name") or a2.get("name"),
            "period_1": round(amount_1, 2),
            "period_2": round(amount_2, 2),
            "change": change,
            "change_pct": pct,
        })

    generated = False
    commentary = (
        f"Variance Summary: Net Profit moved from ${pnl_1['net_profit']:,.2f} "
        f"to ${pnl_2['net_profit']:,.2f} "
        f"(${round(pnl_2['net_profit'] - pnl_1['net_profit'], 2):,.2f} change)."
    )

    return {
        "period_1": {"from": from_date_1, "to": to_date_1, "net_profit": pnl_1["net_profit"]},
        "period_2": {"from": from_date_2, "to": to_date_2, "net_profit": pnl_2["net_profit"]},
        "variances": variances,
        "commentary": commentary,
        "generated": generated,
    }


def detect_anomalies(from_date: str, to_date: str, threshold: float = 2.0) -> dict:
    """Flag unusual items in the ledger."""
    with get_db() as conn:
        # Get account balances for the period
        rows = conn.execute("""
            SELECT a.id, a.code, a.name, a.type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM accounts a
            JOIN journal_lines jl ON jl.account_id = a.id
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE je.date >= ? AND je.date <= ?
            GROUP BY a.id ORDER BY a.code
        """, (from_date, to_date)).fetchall()

        anomalies = []

        for row in rows:
            debit = row["total_debits"]
            credit = row["total_credits"]
            balance = debit - credit

            # Sign reversal: assets with credit balance, liabilities with debit balance
            if row["type"] in ("asset",) and balance < 0:
                anomalies.append({
                    "account_id": row["id"],
                    "code": row["code"],
                    "name": row["name"],
                    "type": "sign_reversal",
                    "detail": f"Asset account has credit balance of ${abs(balance):,.2f}",
                    "severity": "high",
                })
            elif row["type"] in ("liability", "equity") and balance > 0:
                anomalies.append({
                    "account_id": row["id"],
                    "code": row["code"],
                    "name": row["name"],
                    "type": "sign_reversal",
                    "detail": f"Liability/equity account has debit balance of ${balance:,.2f}",
                    "severity": "high",
                })

        # Check for large individual journal entries (> threshold * average)
        avg_row = conn.execute("""
            SELECT AVG(jl.debit + jl.credit) as avg_amount
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE je.date >= ? AND je.date <= ?
        """, (from_date, to_date)).fetchone()
        avg_amount = avg_row["avg_amount"] or 0

        if avg_amount > 0:
            large = conn.execute("""
                SELECT je.id, je.entry_number, je.date, je.description,
                    jl.debit + jl.credit as amount, a.code, a.name
                FROM journal_lines jl
                JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
                JOIN accounts a ON a.id = jl.account_id
                WHERE je.date >= ? AND je.date <= ?
                AND (jl.debit + jl.credit) > ? * ?
                ORDER BY (jl.debit + jl.credit) DESC
                LIMIT 10
            """, (from_date, to_date, threshold, avg_amount)).fetchall()

            for entry in large:
                anomalies.append({
                    "journal_id": entry["id"],
                    "entry_number": entry["entry_number"],
                    "date": entry["date"],
                    "description": entry["description"],
                    "type": "large_amount",
                    "detail": f"${entry['amount']:,.2f} is >{threshold}x the average (${avg_amount:,.2f})",
                    "severity": "medium",
                    "account": f"{entry['code']} {entry['name']}",
                })

        return {
            "from_date": from_date,
            "to_date": to_date,
            "anomalies": anomalies,
            "total_anomalies": len(anomalies),
            "threshold": threshold,
        }


async def financial_summary() -> dict:
    """Quick financial position summary."""
    with get_db() as conn:
        # Get current FY dates
        fy_month_row = conn.execute(
            "SELECT value FROM settings WHERE key = 'financial_year_start'"
        ).fetchone()
        fy_start_month = int(fy_month_row["value"]) if fy_month_row else 7

        from datetime import datetime
        now = datetime.utcnow()
        if now.month >= fy_start_month:
            fy_start = f"{now.year}-{fy_start_month:02d}-01"
            fy_end = f"{now.year + 1}-{fy_start_month:02d}-01"
        else:
            fy_start = f"{now.year - 1}-{fy_start_month:02d}-01"
            fy_end = f"{now.year}-{fy_start_month:02d}-01"

        today = now.strftime("%Y-%m-%d")

        # Get P&L
        pnl = profit_and_loss(fy_start, today)

        # Get cash position
        cash = conn.execute("""
            SELECT COALESCE(SUM(jl.debit) - SUM(jl.credit), 0) as balance
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code IN ('1000', '1010')
        """).fetchone()["balance"]

        # Get receivables and payables
        receivables = conn.execute("""
            SELECT COALESCE(SUM(jl.debit) - SUM(jl.credit), 0) as balance
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '1100'
        """).fetchone()["balance"]

        payables = conn.execute("""
            SELECT COALESCE(SUM(jl.credit) - SUM(jl.debit), 0) as balance
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '2000'
        """).fetchone()["balance"]

        journal_count = conn.execute(
            "SELECT COUNT(*) FROM journal_entries WHERE is_posted = 1"
        ).fetchone()[0]

        summary = {
            "financial_year": f"{fy_start[:4]}/{int(fy_start[:4])+1}",
            "as_at": today,
            "cash_position": round(cash, 2),
            "accounts_receivable": round(receivables, 2),
            "accounts_payable": round(payables, 2),
            "ytd_revenue": pnl["total_revenue"],
            "ytd_expenses": round(pnl["total_expenses"] + pnl["total_cogs"], 2),
            "ytd_net_profit": pnl["net_profit"],
            "posted_journals": journal_count,
        }

        summary["ai_summary"] = (
            f"Cash at bank: ${summary['cash_position']:,.2f}. "
            f"YTD net profit: ${summary['ytd_net_profit']:,.2f}."
        )
        summary["generated"] = False

        return summary
