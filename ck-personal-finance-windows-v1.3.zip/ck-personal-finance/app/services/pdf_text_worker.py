"""Extract PDF text in a short-lived process with an enforced memory limit."""
import json
import os
import sys


def restrict_memory():
    limit = 384 * 1024 * 1024
    if os.name != "nt":
        import resource
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
        resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
        return None
    import ctypes
    from ctypes import wintypes
    class Basic(ctypes.Structure):
        _fields_ = [("per_process", ctypes.c_int64), ("per_job", ctypes.c_int64),
                    ("flags", wintypes.DWORD), ("min_ws", ctypes.c_size_t),
                    ("max_ws", ctypes.c_size_t), ("active", wintypes.DWORD),
                    ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD),
                    ("scheduling", wintypes.DWORD)]
    class IO(ctypes.Structure):
        _fields_ = [(name, ctypes.c_uint64) for name in ("read_ops", "write_ops", "other_ops", "read_bytes", "write_bytes", "other_bytes")]
    class Extended(ctypes.Structure):
        _fields_ = [("basic", Basic), ("io", IO), ("process_memory", ctypes.c_size_t),
                    ("job_memory", ctypes.c_size_t), ("peak_process", ctypes.c_size_t), ("peak_job", ctypes.c_size_t)]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    job = kernel.CreateJobObjectW(None, None)
    info = Extended(); info.basic.flags = 0x100; info.process_memory = limit
    if not job or not kernel.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)) or not kernel.AssignProcessToJobObject(job, kernel.GetCurrentProcess()):
        raise RuntimeError("PDF process limits could not be applied")
    return job  # Keep the handle alive for the lifetime of this process.


def main():
    job = restrict_memory()
    from pypdf import PdfReader
    reader = PdfReader(sys.argv[1])
    if reader.is_encrypted:
        raise ValueError("Encrypted PDFs are not supported. Upload an unencrypted synthetic PDF.")
    if len(reader.pages) > 100:
        raise ValueError("PDF exceeds the 100-page local intake limit.")
    remaining = min(int(sys.argv[2]), 84000)
    parts = []
    for page in reader.pages:
        part = (page.extract_text() or "")[:remaining]
        parts.append(part); remaining -= len(part) + 2
        if remaining <= 0:
            break
    text = "\n\n".join(parts)
    if not text.strip():
        raise ValueError("PDF contains no extractable text. Scanned PDFs require OCR, which is unavailable.")
    print(json.dumps({"text": text[:84000]}))


if __name__ == "__main__":
    try:
        main()
    except ValueError as exc:
        print(json.dumps({"error": str(exc)})); sys.exit(2)
    except Exception:
        print(json.dumps({"error": "PDF could not be read within the local processing limits."})); sys.exit(2)
