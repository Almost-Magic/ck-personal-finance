"""Local-only AI via Ollama on this machine. No external provider is ever called.

Ruling: Mani chose a local model on the VPS (23 Oct 2026); "we don't want open router".
Every completion is answered by Ollama at 127.0.0.1:11434 and recorded as a local
receipt. The loopback invariant is enforced in code and covered by the suite.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import urlsplit

_DEFAULT_URL = "http://127.0.0.1:11434"
_LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
_MODELS = {"low": "llama3.2:3b", "medium": "llama3.1:8b"}


def _base_url() -> str:
    url = os.environ.get("CKPF_OLLAMA_URL", _DEFAULT_URL)
    host = urlsplit(url).hostname or ""
    if host not in _LOOPBACK_HOSTS:
        raise RuntimeError("AI is local-only: CKPF_OLLAMA_URL must point at this machine (loopback). Refusing to call out.")
    return url.rstrip("/")


def _post(path: str, payload: dict[str, Any], timeout: int) -> dict[str, Any]:
    req = urllib.request.Request(
        _base_url() + path,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def available_models() -> list[str]:
    try:
        with urllib.request.urlopen(_base_url() + "/api/tags", timeout=5) as r:
            return [m["name"] for m in json.loads(r.read()).get("models", [])]
    except Exception:
        return []


def model_policy() -> dict[str, Any]:
    models = available_models()
    return {
        "provider": "ollama-local",
        "endpoint": _base_url(),
        "external_calls": False,
        "provider_called": False,
        "models": models,
        "tiers": _MODELS,
        "ollama_running": bool(models),
        "data_rule": "Prompts are built on this machine from your local rows only. Nothing is sent to any external provider, and no answer is advice - it is a local read of your own data.",
    }


def route(task_kind: str, reasoning_level: str = "low") -> dict[str, Any]:
    level = reasoning_level if reasoning_level in _MODELS else "low"
    model = _MODELS[level]
    installed = model in available_models()
    return {
        "task_kind": task_kind,
        "reasoning_level": level,
        "model": model,
        "model_installed": installed,
        "provider": "ollama-local",
        "provider_called": False,
        "reason": ("Heavier local model for scenario and forecast questions." if level == "medium"
                   else "Small local model for everyday questions; faster and enough."),
        "external_calls": False,
    }


def complete(prompt: str, task_kind: str = "ask_money", reasoning_level: str = "low") -> dict[str, Any]:
    routed = route(task_kind, reasoning_level)
    if not routed["model_installed"]:
        raise RuntimeError("The local model %s is not installed on this machine yet." % routed["model"])
    bounded = prompt[:12000]
    result = _post("/api/generate", {
        "model": routed["model"],
        "prompt": bounded,
        "stream": False,
        "options": {"temperature": 0.2, "num_predict": 600},
    }, timeout=180)
    text = (result.get("response") or "").strip()
    receipt = None
    try:
        from app.services.personal_finance_store import create_local_receipt
        receipt = create_local_receipt(
            "ai_local_answer",
            "Local AI (%s) answered a %s question on this machine; prompt %d chars, answer %d chars; no external call."
            % (routed["model"], task_kind, len(bounded), len(text)),
        )
    except Exception:
        receipt = None
    return {
        "text": text,
        "model": routed["model"],
        "reasoning_level": routed["reasoning_level"],
        "provider": "ollama-local",
        "provider_called": True,
        "external_calls": False,
        "receipt_id": (receipt or {}).get("receipt_id"),
    }
