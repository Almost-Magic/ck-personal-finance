# Author: Mani Padisetti
"""Export service — PDF, CSV, Excel, accountant pack, audit trail, compliance."""

import csv
import io
import zipfile
from datetime import datetime

from app.database import get_db
from app.services.reports import trial_balance, profit_and_loss, balance_sheet, cash_flow


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

def _report_to_csv(report_data: dict, report_type: str) -> str:
    """Convert a report dict to CSV string."""
    output = io.StringIO()
    writer = csv.writer(output)

    if report_type == "trial_balance":
        writer.writerow(["Code", "Account", "Type", "Debit", "Credit", "Balance"])
        for acc in report_data.get("accounts", []):
            writer.writerow([acc["code"], acc["name"], acc["type"],
                             acc["debit"], acc["credit"], acc["balance"]])
        writer.writerow([])
        writer.writerow(["", "TOTALS", "", report_data["total_debits"],
                         report_data["total_credits"], ""])

    elif report_type == "profit_and_loss":
        writer.writerow(["Section", "Code", "Account", "Amount"])
        for acc in report_data.get("revenue", []):
            writer.writerow(["Revenue", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Total Revenue", report_data["total_revenue"]])
        for acc in report_data.get("cogs", []):
            writer.writerow(["COGS", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Gross Profit", report_data["gross_profit"]])
        for acc in report_data.get("expenses", []):
            writer.writerow(["Expenses", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Total Expenses", report_data["total_expenses"]])
        writer.writerow(["", "", "Net Profit", report_data["net_profit"]])

    elif report_type == "balance_sheet":
        writer.writerow(["Section", "Code", "Account", "Amount"])
        for acc in report_data.get("assets", []):
            writer.writerow(["Assets", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Total Assets", report_data["total_assets"]])
        for acc in report_data.get("liabilities", []):
            writer.writerow(["Liabilities", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Total Liabilities", report_data["total_liabilities"]])
        for acc in report_data.get("equity", []):
            writer.writerow(["Equity", acc["code"], acc["name"], acc["amount"]])
        writer.writerow(["", "", "Current Year Earnings", report_data["current_year_earnings"]])
        writer.writerow(["", "", "Total Equity", report_data["total_equity"]])

    elif report_type == "cash_flow":
        writer.writerow(["Section", "Item", "Amount"])
        op = report_data.get("operating_activities", {})
        writer.writerow(["Operating", "Net Profit", op.get("net_profit", 0)])
        for adj in op.get("adjustments", []):
            writer.writerow(["Operating", adj["name"], adj.get("cash_effect", adj.get("movement", 0))])
        writer.writerow(["Operating", "Total", op.get("total", 0)])
        inv = report_data.get("investing_activities", {})
        for item in inv.get("items", []):
            writer.writerow(["Investing", item["name"], item["movement"]])
        writer.writerow(["Investing", "Total", inv.get("total", 0)])
        fin = report_data.get("financing_activities", {})
        for item in fin.get("items", []):
            writer.writerow(["Financing", item["name"], item["movement"]])
        writer.writerow(["Financing", "Total", fin.get("total", 0)])
        writer.writerow(["", "Net Change in Cash", report_data.get("net_change_in_cash", 0)])

    elif report_type == "chart_of_accounts":
        writer.writerow(["Code", "Account", "Type", "Sub Type", "Active"])
        for acc in report_data.get("accounts", []):
            writer.writerow([acc["code"], acc["name"], acc["type"],
                             acc.get("sub_type", ""), acc.get("is_active", 1)])

    elif report_type == "general_ledger":
        writer.writerow(["Date", "Entry #", "Description", "Account", "Debit", "Credit"])
        for entry in report_data.get("entries", []):
            writer.writerow([entry["date"], entry["entry_number"], entry["description"],
                             entry.get("account_name", ""), entry["debit"], entry["credit"]])

    elif report_type == "audit_trail":
        writer.writerow(["ID", "Action", "Entity Type", "Entity ID", "Detail", "User", "Timestamp"])
        for entry in report_data.get("entries", []):
            writer.writerow([entry["id"], entry["action"], entry["entity_type"],
                             entry.get("entity_id", ""), entry.get("detail", ""),
                             entry["user"], entry["created_at"]])

    return output.getvalue()


# ---------------------------------------------------------------------------
# PDF export
# ---------------------------------------------------------------------------

def _report_to_pdf(report_data: dict, report_type: str) -> bytes:
    """Convert a report dict to PDF bytes."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    title_map = {
        "trial_balance": "Trial Balance",
        "profit_and_loss": "Profit & Loss Statement",
        "balance_sheet": "Balance Sheet",
        "cash_flow": "Cash Flow Statement",
    }
    title = title_map.get(report_type, report_type.replace("_", " ").title())
    elements.append(Paragraph(f"<b>Almost Magic Tech Lab</b>", styles["Title"]))
    elements.append(Paragraph(title, styles["Heading2"]))

    # Date range
    if "from_date" in report_data and report_data.get("from_date"):
        elements.append(Paragraph(
            f"Period: {report_data['from_date']} to {report_data.get('to_date', '')}",
            styles["Normal"]
        ))
    elif "as_at_date" in report_data:
        elements.append(Paragraph(f"As at: {report_data['as_at_date']}", styles["Normal"]))

    elements.append(Spacer(1, 12))

    # Build table
    table_style = TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("FONTSIZE", (0, 1), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#ecf0f1")]),
        ("ALIGN", (-3, 1), (-1, -1), "RIGHT"),
    ])

    if report_type == "trial_balance":
        data = [["Code", "Account", "Type", "Debit", "Credit", "Balance"]]
        for acc in report_data.get("accounts", []):
            data.append([acc["code"], acc["name"], acc["type"],
                         f"{acc['debit']:,.2f}", f"{acc['credit']:,.2f}", f"{acc['balance']:,.2f}"])
        data.append(["", "TOTALS", "", f"{report_data['total_debits']:,.2f}",
                      f"{report_data['total_credits']:,.2f}", ""])

    elif report_type == "profit_and_loss":
        data = [["Code", "Account", "Amount"]]
        data.append(["", "REVENUE", ""])
        for acc in report_data.get("revenue", []):
            data.append([acc["code"], acc["name"], f"{acc['amount']:,.2f}"])
        data.append(["", "Total Revenue", f"{report_data['total_revenue']:,.2f}"])
        data.append(["", "EXPENSES", ""])
        for acc in report_data.get("expenses", []):
            data.append([acc["code"], acc["name"], f"{acc['amount']:,.2f}"])
        data.append(["", "Total Expenses", f"{report_data['total_expenses']:,.2f}"])
        data.append(["", "NET PROFIT", f"{report_data['net_profit']:,.2f}"])

    elif report_type == "balance_sheet":
        data = [["Code", "Account", "Amount"]]
        data.append(["", "ASSETS", ""])
        for acc in report_data.get("assets", []):
            data.append([acc["code"], acc["name"], f"{acc['amount']:,.2f}"])
        data.append(["", "Total Assets", f"{report_data['total_assets']:,.2f}"])
        data.append(["", "LIABILITIES", ""])
        for acc in report_data.get("liabilities", []):
            data.append([acc["code"], acc["name"], f"{acc['amount']:,.2f}"])
        data.append(["", "Total Liabilities", f"{report_data['total_liabilities']:,.2f}"])
        data.append(["", "EQUITY", ""])
        for acc in report_data.get("equity", []):
            data.append([acc["code"], acc["name"], f"{acc['amount']:,.2f}"])
        data.append(["", "Current Year Earnings", f"{report_data['current_year_earnings']:,.2f}"])
        data.append(["", "Total Equity", f"{report_data['total_equity']:,.2f}"])

    elif report_type == "cash_flow":
        data = [["Section", "Item", "Amount"]]
        op = report_data.get("operating_activities", {})
        data.append(["Operating", "Net Profit", f"{op.get('net_profit', 0):,.2f}"])
        data.append(["Operating", "Total", f"{op.get('total', 0):,.2f}"])
        data.append(["Investing", "Total", f"{report_data.get('investing_activities', {}).get('total', 0):,.2f}"])
        data.append(["Financing", "Total", f"{report_data.get('financing_activities', {}).get('total', 0):,.2f}"])
        data.append(["", "Net Change in Cash", f"{report_data.get('net_change_in_cash', 0):,.2f}"])

    else:
        data = [["Report"]]
        data.append([str(report_data)])

    table = Table(data)
    table.setStyle(table_style)
    elements.append(table)
    elements.append(Spacer(1, 12))
    elements.append(Paragraph(
        f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}",
        styles["Italic"]
    ))

    doc.build(elements)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Excel export
# ---------------------------------------------------------------------------

def _report_to_excel(report_data: dict, report_type: str) -> bytes:
    """Convert a report dict to Excel bytes."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = report_type.replace("_", " ").title()

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="2C3E50", end_color="2C3E50", fill_type="solid")

    if report_type == "trial_balance":
        headers = ["Code", "Account", "Type", "Debit", "Credit", "Balance"]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
        for acc in report_data.get("accounts", []):
            ws.append([acc["code"], acc["name"], acc["type"],
                       acc["debit"], acc["credit"], acc["balance"]])
        ws.append(["", "TOTALS", "", report_data["total_debits"],
                   report_data["total_credits"], ""])

    elif report_type == "profit_and_loss":
        headers = ["Section", "Code", "Account", "Amount"]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
        for acc in report_data.get("revenue", []):
            ws.append(["Revenue", acc["code"], acc["name"], acc["amount"]])
        ws.append(["", "", "Total Revenue", report_data["total_revenue"]])
        for acc in report_data.get("expenses", []):
            ws.append(["Expenses", acc["code"], acc["name"], acc["amount"]])
        ws.append(["", "", "Total Expenses", report_data["total_expenses"]])
        ws.append(["", "", "Net Profit", report_data["net_profit"]])

    elif report_type == "balance_sheet":
        headers = ["Section", "Code", "Account", "Amount"]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
        for acc in report_data.get("assets", []):
            ws.append(["Assets", acc["code"], acc["name"], acc["amount"]])
        ws.append(["", "", "Total Assets", report_data["total_assets"]])
        for acc in report_data.get("liabilities", []):
            ws.append(["Liabilities", acc["code"], acc["name"], acc["amount"]])
        ws.append(["", "", "Total Liabilities", report_data["total_liabilities"]])
        for acc in report_data.get("equity", []):
            ws.append(["Equity", acc["code"], acc["name"], acc["amount"]])
        ws.append(["", "", "Current Year Earnings", report_data["current_year_earnings"]])
        ws.append(["", "", "Total Equity", report_data["total_equity"]])

    elif report_type == "cash_flow":
        headers = ["Section", "Item", "Amount"]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
        op = report_data.get("operating_activities", {})
        ws.append(["Operating", "Net Profit", op.get("net_profit", 0)])
        ws.append(["Operating", "Total", op.get("total", 0)])
        ws.append(["Investing", "Total", report_data.get("investing_activities", {}).get("total", 0)])
        ws.append(["Financing", "Total", report_data.get("financing_activities", {}).get("total", 0)])
        ws.append(["", "Net Change in Cash", report_data.get("net_change_in_cash", 0)])

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------

def generate_report(report_type: str, fmt: str,
                    from_date: str | None = None, to_date: str | None = None,
                    as_at_date: str | None = None) -> dict:
    """Generate a report in the requested format."""
    # Get report data
    if report_type == "trial_balance":
        data = trial_balance(from_date, to_date)
    elif report_type == "profit_and_loss":
        if not from_date or not to_date:
            return {"error": "from_date and to_date are required for profit_and_loss"}
        data = profit_and_loss(from_date, to_date)
    elif report_type == "balance_sheet":
        if not as_at_date:
            return {"error": "as_at_date is required for balance_sheet"}
        data = balance_sheet(as_at_date)
    elif report_type == "cash_flow":
        if not from_date or not to_date:
            return {"error": "from_date and to_date are required for cash_flow"}
        data = cash_flow(from_date, to_date)
    else:
        return {"error": f"Unknown report type: {report_type}"}

    # Convert to format
    if fmt == "json":
        return {"report": data, "format": "json", "content_type": "application/json"}
    elif fmt == "csv":
        content = _report_to_csv(data, report_type)
        return {"content": content, "format": "csv",
                "content_type": "text/csv",
                "filename": f"{report_type}.csv"}
    elif fmt == "pdf":
        content = _report_to_pdf(data, report_type)
        return {"content": content, "format": "pdf",
                "content_type": "application/pdf",
                "filename": f"{report_type}.pdf",
                "size": len(content)}
    elif fmt == "excel":
        content = _report_to_excel(data, report_type)
        return {"content": content, "format": "excel",
                "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "filename": f"{report_type}.xlsx",
                "size": len(content)}
    else:
        return {"error": f"Unsupported format: {fmt}"}


# ---------------------------------------------------------------------------
# Accountant pack
# ---------------------------------------------------------------------------

def accountant_pack(financial_year: int, formats: list[str] | None = None) -> dict:
    """Generate a ZIP bundle of all reports for a financial year."""
    if formats is None:
        formats = ["csv"]

    fy_start = f"{financial_year}-07-01"
    fy_end = f"{financial_year + 1}-06-30"

    reports = {
        "trial_balance": trial_balance(fy_start, fy_end),
        "profit_and_loss": profit_and_loss(fy_start, fy_end),
        "balance_sheet": balance_sheet(fy_end),
        "cash_flow": cash_flow(fy_start, fy_end),
    }

    # Add chart of accounts
    with get_db() as conn:
        accounts = conn.execute(
            "SELECT code, name, type, sub_type, is_active FROM accounts ORDER BY code"
        ).fetchall()
        reports["chart_of_accounts"] = {
            "accounts": [dict(a) for a in accounts],
        }

        # Add general ledger
        entries = conn.execute("""
            SELECT je.date, je.entry_number, je.description, a.name as account_name,
                   jl.debit, jl.credit
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE je.date >= ? AND je.date <= ?
            ORDER BY je.date, je.id, jl.id
        """, (fy_start, fy_end)).fetchall()
        reports["general_ledger"] = {"entries": [dict(e) for e in entries]}

        # Add audit trail
        audit_entries = conn.execute(
            "SELECT * FROM audit_log ORDER BY created_at"
        ).fetchall()
        reports["audit_trail"] = {"entries": [dict(e) for e in audit_entries]}

        # Add BAS summary
        bas_rows = conn.execute(
            "SELECT * FROM bas_lodgements WHERE financial_year = ? ORDER BY quarter",
            (financial_year,)
        ).fetchall()

    # Build ZIP
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for report_name, report_data in reports.items():
            for fmt in formats:
                if fmt == "csv":
                    content = _report_to_csv(report_data, report_name)
                    zf.writestr(f"{report_name}.csv", content)
                elif fmt == "pdf":
                    if report_name in ("trial_balance", "profit_and_loss", "balance_sheet", "cash_flow"):
                        content = _report_to_pdf(report_data, report_name)
                        zf.writestr(f"{report_name}.pdf", content)
                elif fmt == "excel":
                    if report_name in ("trial_balance", "profit_and_loss", "balance_sheet", "cash_flow"):
                        content = _report_to_excel(report_data, report_name)
                        zf.writestr(f"{report_name}.xlsx", content)

        # BAS summary as CSV
        if bas_rows:
            bas_output = io.StringIO()
            writer = csv.writer(bas_output)
            writer.writerow(["Period", "Quarter", "1A (GST Sales)", "1B (GST Purchases)",
                             "W1 (Wages)", "W2 (Withheld)", "GST Payable", "PAYG", "Total", "Status"])
            for row in bas_rows:
                writer.writerow([row["period"], row["quarter"], row["label_1a"], row["label_1b"],
                                 row["label_w1"], row["label_w2"], row["gst_payable"],
                                 row["payg_withheld"], row["total_payable"], row["status"]])
            zf.writestr("bas_summary.csv", bas_output.getvalue())

    zip_bytes = zip_buffer.getvalue()
    return {
        "filename": f"accountant_pack_FY{financial_year}_{financial_year + 1}.zip",
        "content": zip_bytes,
        "size": len(zip_bytes),
        "reports_included": list(reports.keys()),
        "formats": formats,
        "financial_year": f"{financial_year}/{financial_year + 1}",
    }


# ---------------------------------------------------------------------------
# Audit trail
# ---------------------------------------------------------------------------

def get_audit_trail(entity_type: str | None = None, entity_id: int | None = None,
                    action: str | None = None, from_date: str | None = None,
                    to_date: str | None = None, limit: int = 100) -> dict:
    """Query audit trail entries."""
    with get_db() as conn:
        query = "SELECT * FROM audit_log WHERE 1=1"
        params = []

        if entity_type:
            query += " AND entity_type = ?"
            params.append(entity_type)
        if entity_id is not None:
            query += " AND entity_id = ?"
            params.append(entity_id)
        if action:
            query += " AND action = ?"
            params.append(action)
        if from_date:
            query += " AND created_at >= ?"
            params.append(from_date)
        if to_date:
            query += " AND created_at <= ?"
            params.append(to_date)

        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        total = conn.execute(
            "SELECT COUNT(*) FROM audit_log" +
            (" WHERE entity_type = ?" if entity_type else ""),
            ([entity_type] if entity_type else []),
        ).fetchone()[0]

        return {
            "entries": [dict(r) for r in rows],
            "count": len(rows),
            "total": total,
        }


# ---------------------------------------------------------------------------
# Compliance checklist
# ---------------------------------------------------------------------------

def compliance_checklist(financial_year: int) -> dict:
    """Check FY compliance status."""
    fy_start = f"{financial_year}-07-01"
    fy_end = f"{financial_year + 1}-06-30"

    with get_db() as conn:
        # Check if periods exist
        periods = conn.execute(
            "SELECT COUNT(*) FROM financial_periods WHERE start_date >= ? AND end_date <= ?",
            (fy_start, fy_end),
        ).fetchone()[0]
        periods_closed = conn.execute(
            "SELECT COUNT(*) FROM financial_periods WHERE start_date >= ? AND end_date <= ? AND is_closed = 1",
            (fy_start, fy_end),
        ).fetchone()[0]

        # Check BAS lodgements
        bas_count = conn.execute(
            "SELECT COUNT(*) FROM bas_lodgements WHERE financial_year = ?",
            (financial_year,),
        ).fetchone()[0]
        bas_lodged = conn.execute(
            "SELECT COUNT(*) FROM bas_lodgements WHERE financial_year = ? AND status IN ('lodged', 'paid')",
            (financial_year,),
        ).fetchone()[0]

        # Check super obligations
        super_count = conn.execute(
            "SELECT COUNT(*) FROM super_obligations WHERE quarter LIKE ?",
            (f"Q%-{financial_year}%",),
        ).fetchone()[0]
        super_paid = conn.execute(
            "SELECT COUNT(*) FROM super_obligations WHERE quarter LIKE ? AND status = 'paid'",
            (f"Q%-{financial_year}%",),
        ).fetchone()[0]

        # Check journal integrity
        journal_count = conn.execute(
            "SELECT COUNT(*) FROM journal_entries WHERE date >= ? AND date <= ? AND is_posted = 1",
            (fy_start, fy_end),
        ).fetchone()[0]

        # Unbalanced entries check
        unbalanced = conn.execute("""
            SELECT COUNT(*) FROM journal_entries je
            WHERE je.is_posted = 1 AND je.date >= ? AND je.date <= ?
            AND (SELECT ROUND(SUM(jl.debit) - SUM(jl.credit), 2) FROM journal_lines jl WHERE jl.journal_entry_id = je.id) != 0
        """, (fy_start, fy_end)).fetchone()[0]

        # Trial balance
        tb = trial_balance(fy_start, fy_end)

        checklist = [
            {
                "item": "Financial periods created",
                "status": "complete" if periods >= 12 else "incomplete",
                "detail": f"{periods}/12 periods created",
            },
            {
                "item": "Financial periods closed",
                "status": "complete" if periods_closed >= 12 else "incomplete",
                "detail": f"{periods_closed}/12 periods closed",
            },
            {
                "item": "BAS lodgements",
                "status": "complete" if bas_lodged >= 4 else "incomplete",
                "detail": f"{bas_lodged}/{bas_count} quarters lodged (4 required)",
            },
            {
                "item": "Superannuation obligations",
                "status": "complete" if super_paid > 0 and super_paid == super_count else ("incomplete" if super_count > 0 else "not_applicable"),
                "detail": f"{super_paid}/{super_count} quarters paid" if super_count > 0 else "No super obligations recorded",
            },
            {
                "item": "Journal entries posted",
                "status": "complete" if journal_count > 0 else "incomplete",
                "detail": f"{journal_count} posted entries for FY",
            },
            {
                "item": "Journal entries balanced",
                "status": "complete" if unbalanced == 0 else "error",
                "detail": f"{unbalanced} unbalanced entries" if unbalanced > 0 else "All entries balanced",
            },
            {
                "item": "Trial balance balanced",
                "status": "complete" if tb["is_balanced"] else "error",
                "detail": "Trial balance is balanced" if tb["is_balanced"] else "Trial balance is NOT balanced",
            },
        ]

        complete_count = sum(1 for c in checklist if c["status"] == "complete")
        total_applicable = sum(1 for c in checklist if c["status"] != "not_applicable")

        return {
            "financial_year": f"{financial_year}/{financial_year + 1}",
            "checklist": checklist,
            "complete": complete_count,
            "total": total_applicable,
            "compliance_pct": round((complete_count / total_applicable) * 100, 1) if total_applicable > 0 else 0,
        }
