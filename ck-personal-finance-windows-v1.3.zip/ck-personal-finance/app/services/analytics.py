# Author: Mani Padisetti
"""Analytics service — trends, ledger, ageing, budgets, NL queries."""

from app.database import get_db


def monthly_trends(from_date: str, to_date: str) -> dict:
    """Monthly time-series of revenue, expenses, and net profit."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT strftime('%%Y-%%m', je.date) as month,
                a.type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE je.date >= ? AND je.date <= ?
            AND a.type IN ('revenue', 'other_income', 'cogs', 'expense', 'other_expense')
            GROUP BY month, a.type
            ORDER BY month
        """, (from_date, to_date)).fetchall()

        months = {}
        for row in rows:
            m = row["month"]
            if m not in months:
                months[m] = {"month": m, "revenue": 0, "expenses": 0, "net_profit": 0}
            if row["type"] in ("revenue", "other_income"):
                months[m]["revenue"] += round(row["total_credits"] - row["total_debits"], 2)
            else:
                months[m]["expenses"] += round(row["total_debits"] - row["total_credits"], 2)

        for m in months.values():
            m["revenue"] = round(m["revenue"], 2)
            m["expenses"] = round(m["expenses"], 2)
            m["net_profit"] = round(m["revenue"] - m["expenses"], 2)

        return {
            "from_date": from_date,
            "to_date": to_date,
            "trends": sorted(months.values(), key=lambda x: x["month"]),
        }


def quarterly_trends(from_date: str, to_date: str) -> dict:
    """Quarterly time-series."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT
                CASE
                    WHEN CAST(strftime('%%m', je.date) AS INTEGER) BETWEEN 7 AND 9 THEN 'Q1'
                    WHEN CAST(strftime('%%m', je.date) AS INTEGER) BETWEEN 10 AND 12 THEN 'Q2'
                    WHEN CAST(strftime('%%m', je.date) AS INTEGER) BETWEEN 1 AND 3 THEN 'Q3'
                    ELSE 'Q4'
                END as quarter,
                strftime('%%Y', je.date) as year,
                a.type,
                COALESCE(SUM(jl.debit), 0) as total_debits,
                COALESCE(SUM(jl.credit), 0) as total_credits
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE je.date >= ? AND je.date <= ?
            AND a.type IN ('revenue', 'other_income', 'cogs', 'expense', 'other_expense')
            GROUP BY quarter, year, a.type
            ORDER BY year, quarter
        """, (from_date, to_date)).fetchall()

        quarters = {}
        for row in rows:
            key = f"{row['year']}-{row['quarter']}"
            if key not in quarters:
                quarters[key] = {"quarter": row["quarter"], "year": row["year"],
                                 "revenue": 0, "expenses": 0, "net_profit": 0}
            if row["type"] in ("revenue", "other_income"):
                quarters[key]["revenue"] += round(row["total_credits"] - row["total_debits"], 2)
            else:
                quarters[key]["expenses"] += round(row["total_debits"] - row["total_credits"], 2)

        for q in quarters.values():
            q["revenue"] = round(q["revenue"], 2)
            q["expenses"] = round(q["expenses"], 2)
            q["net_profit"] = round(q["revenue"] - q["expenses"], 2)

        return {
            "from_date": from_date,
            "to_date": to_date,
            "trends": sorted(quarters.values(), key=lambda x: f"{x['year']}-{x['quarter']}"),
        }


def account_ledger(account_id: int, from_date: str | None = None,
                    to_date: str | None = None) -> dict:
    """Detailed account ledger with running balance."""
    with get_db() as conn:
        account = conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()
        if not account:
            return {"error": "Account not found"}

        query = """
            SELECT je.date, je.entry_number, je.description, jl.debit, jl.credit, jl.description as line_desc
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE jl.account_id = ?
        """
        params = [account_id]
        if from_date:
            query += " AND je.date >= ?"
            params.append(from_date)
        if to_date:
            query += " AND je.date <= ?"
            params.append(to_date)
        query += " ORDER BY je.date, je.id"

        rows = conn.execute(query, params).fetchall()
        running_balance = 0
        entries = []
        for row in rows:
            # Assets/Expenses: debit increases balance
            # Liabilities/Equity/Revenue: credit increases balance
            if account["type"] in ("asset", "expense", "cogs", "other_expense"):
                running_balance += row["debit"] - row["credit"]
            else:
                running_balance += row["credit"] - row["debit"]

            entries.append({
                "date": row["date"],
                "entry_number": row["entry_number"],
                "description": row["description"],
                "line_description": row["line_desc"],
                "debit": round(row["debit"], 2),
                "credit": round(row["credit"], 2),
                "balance": round(running_balance, 2),
            })

        return {
            "account": dict(account),
            "from_date": from_date,
            "to_date": to_date,
            "entries": entries,
            "closing_balance": round(running_balance, 2),
            "total_debits": round(sum(e["debit"] for e in entries), 2),
            "total_credits": round(sum(e["credit"] for e in entries), 2),
        }


def aged_receivables(as_at_date: str) -> dict:
    """Aged receivables report — Current/30/60/90+ days."""
    return _aged_report("1100", as_at_date, "debit")


def aged_payables(as_at_date: str) -> dict:
    """Aged payables report — Current/30/60/90+ days."""
    return _aged_report("2000", as_at_date, "credit")


def _aged_report(account_code: str, as_at_date: str, normal_side: str) -> dict:
    """Generic ageing report for receivables or payables."""
    with get_db() as conn:
        account = conn.execute("SELECT * FROM accounts WHERE code = ?", (account_code,)).fetchone()
        if not account:
            return {"error": f"Account {account_code} not found"}

        from datetime import datetime, timedelta
        as_at = datetime.strptime(as_at_date, "%Y-%m-%d")

        buckets = {"current": 0, "30_days": 0, "60_days": 0, "90_plus": 0}
        items = []

        rows = conn.execute("""
            SELECT je.date, je.entry_number, je.description,
                jl.debit, jl.credit
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            WHERE jl.account_id = ? AND je.date <= ?
            ORDER BY je.date
        """, (account["id"], as_at_date)).fetchall()

        for row in rows:
            entry_date = datetime.strptime(row["date"], "%Y-%m-%d")
            days = (as_at - entry_date).days
            amount = row[normal_side]
            if amount == 0:
                continue

            if days <= 30:
                bucket = "current"
            elif days <= 60:
                bucket = "30_days"
            elif days <= 90:
                bucket = "60_days"
            else:
                bucket = "90_plus"

            buckets[bucket] += amount
            items.append({
                "date": row["date"],
                "entry_number": row["entry_number"],
                "description": row["description"],
                "amount": round(amount, 2),
                "days": days,
                "bucket": bucket,
            })

        for k in buckets:
            buckets[k] = round(buckets[k], 2)

        return {
            "account": dict(account),
            "as_at_date": as_at_date,
            "buckets": buckets,
            "total": round(sum(buckets.values()), 2),
            "items": items,
        }


def budget_vs_actual(budget_id: int) -> dict:
    """Compare budget to actual figures."""
    with get_db() as conn:
        budget = conn.execute("SELECT * FROM budgets WHERE id = ?", (budget_id,)).fetchone()
        if not budget:
            return {"error": "Budget not found"}

        lines = conn.execute("""
            SELECT bl.*, a.code, a.name, a.type
            FROM budget_lines bl
            JOIN accounts a ON a.id = bl.account_id
            WHERE bl.budget_id = ?
            ORDER BY bl.month, a.code
        """, (budget_id,)).fetchall()

        results = []
        for line in lines:
            # Get actual for this account/month
            month_start = f"{line['month']}-01"
            # Get last day of month
            year, mon = line["month"].split("-")
            import calendar
            last_day = calendar.monthrange(int(year), int(mon))[1]
            month_end = f"{line['month']}-{last_day}"

            actual_row = conn.execute("""
                SELECT COALESCE(SUM(jl.debit), 0) as debits,
                       COALESCE(SUM(jl.credit), 0) as credits
                FROM journal_lines jl
                JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
                WHERE jl.account_id = ? AND je.date >= ? AND je.date <= ?
            """, (line["account_id"], month_start, month_end)).fetchone()

            if line["type"] in ("expense", "cogs", "other_expense"):
                actual = round(actual_row["debits"] - actual_row["credits"], 2)
            else:
                actual = round(actual_row["credits"] - actual_row["debits"], 2)

            variance = round(line["amount"] - actual, 2)

            results.append({
                "month": line["month"],
                "account_id": line["account_id"],
                "code": line["code"],
                "name": line["name"],
                "budget": round(line["amount"], 2),
                "actual": actual,
                "variance": variance,
                "variance_pct": round((variance / line["amount"]) * 100, 1) if line["amount"] != 0 else None,
            })

        return {
            "budget": dict(budget),
            "comparisons": results,
        }


async def nl_query(query_text: str) -> dict:
    return {"query": query_text, "response": "Feature not in this build", "generated": False}
