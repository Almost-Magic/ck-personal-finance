# Author: Mani Padisetti
"""Tax engine service — GST, BAS, income tax, FBT, super, PAYG."""

from app.database import get_db
from datetime import datetime


# Australian BAS quarters (financial year: July-June)
BAS_QUARTERS = {
    "Q1": {"start": "07-01", "end": "09-30", "label": "Jul-Sep"},
    "Q2": {"start": "10-01", "end": "12-31", "label": "Oct-Dec"},
    "Q3": {"start": "01-01", "end": "03-31", "label": "Jan-Mar"},
    "Q4": {"start": "04-01", "end": "06-30", "label": "Apr-Jun"},
}

COMPANY_TAX_RATE = 0.25
SUPER_RATE = 0.115
GST_RATE = 0.10


def calculate_gst(amount: float, inclusive: bool = True) -> dict:
    """Calculate GST component from an amount."""
    if inclusive:
        gst = round(amount / 11, 2)
        net = round(amount - gst, 2)
    else:
        gst = round(amount * GST_RATE, 2)
        net = amount
    return {"gross": round(amount if inclusive else amount + gst, 2),
            "gst": gst, "net": net}


def gst_position(from_date: str | None = None, to_date: str | None = None) -> dict:
    """Calculate GST position: collected vs paid."""
    with get_db() as conn:
        query_collected = "SELECT COALESCE(SUM(gst_amount), 0) FROM gst_entries WHERE gst_type = 'collected'"
        query_paid = "SELECT COALESCE(SUM(gst_amount), 0) FROM gst_entries WHERE gst_type = 'paid'"
        params = []

        if from_date:
            query_collected += " AND created_at >= ?"
            query_paid += " AND created_at >= ?"
            params.append(from_date)
        if to_date:
            query_collected += " AND created_at <= ?"
            query_paid += " AND created_at <= ?"
            params.append(to_date)

        collected = conn.execute(query_collected, params).fetchone()[0]
        paid = conn.execute(query_paid, params).fetchone()[0]

        # Also calculate from journal lines on GST accounts
        gst_payable = conn.execute("""
            SELECT COALESCE(SUM(jl.credit) - SUM(jl.debit), 0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '2100'
        """).fetchone()[0]

        gst_receivable = conn.execute("""
            SELECT COALESCE(SUM(jl.debit) - SUM(jl.credit), 0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '1400'
        """).fetchone()[0]

        net_gst = round(gst_payable - gst_receivable + collected - paid, 2)

        return {
            "gst_collected": round(collected, 2),
            "gst_paid": round(paid, 2),
            "gst_payable_ledger": round(gst_payable, 2),
            "gst_receivable_ledger": round(gst_receivable, 2),
            "net_gst_position": net_gst,
            "from_date": from_date,
            "to_date": to_date,
        }


def _quarter_dates(quarter: str, financial_year: int) -> tuple[str, str]:
    """Return (start_date, end_date) for a BAS quarter."""
    q = BAS_QUARTERS[quarter]
    if quarter in ("Q1", "Q2"):
        year = financial_year
    else:
        year = financial_year + 1
    return f"{year}-{q['start']}", f"{year}-{q['end']}"


def prepare_bas(quarter: str, financial_year: int) -> dict:
    """Prepare quarterly BAS."""
    start_date, end_date = _quarter_dates(quarter, financial_year)

    with get_db() as conn:
        # 1A — GST on sales (collected)
        gst_collected = conn.execute(
            "SELECT COALESCE(SUM(gst_amount), 0) FROM gst_entries WHERE gst_type = 'collected' AND bas_period = ?",
            (f"{quarter}-{financial_year}",),
        ).fetchone()[0]

        # Also from GST Payable ledger
        label_1a = conn.execute("""
            SELECT COALESCE(SUM(jl.credit) - SUM(jl.debit), 0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '2100' AND je.date >= ? AND je.date <= ?
        """, (start_date, end_date)).fetchone()[0]
        label_1a = round(max(label_1a, gst_collected), 2)

        # 1B — GST on purchases (paid)
        gst_paid = conn.execute(
            "SELECT COALESCE(SUM(gst_amount), 0) FROM gst_entries WHERE gst_type = 'paid' AND bas_period = ?",
            (f"{quarter}-{financial_year}",),
        ).fetchone()[0]

        label_1b = conn.execute("""
            SELECT COALESCE(SUM(jl.debit) - SUM(jl.credit), 0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_entry_id AND je.is_posted = 1
            JOIN accounts a ON a.id = jl.account_id
            WHERE a.code = '1400' AND je.date >= ? AND je.date <= ?
        """, (start_date, end_date)).fetchone()[0]
        label_1b = round(max(label_1b, gst_paid), 2)

        # W1 — Total salary/wages
        label_w1 = conn.execute(
            "SELECT COALESCE(SUM(gross_pay), 0) FROM payg_entries WHERE period >= ? AND period <= ?",
            (start_date, end_date),
        ).fetchone()[0]

        # W2 — Amount withheld
        label_w2 = conn.execute(
            "SELECT COALESCE(SUM(tax_withheld), 0) FROM payg_entries WHERE period >= ? AND period <= ?",
            (start_date, end_date),
        ).fetchone()[0]

        gst_payable = round(label_1a - label_1b, 2)
        payg_withheld = round(label_w2, 2)
        total_payable = round(gst_payable + payg_withheld, 2)

        # Check if BAS already exists
        existing = conn.execute(
            "SELECT id FROM bas_lodgements WHERE quarter = ? AND financial_year = ?",
            (quarter, financial_year),
        ).fetchone()

        if existing:
            conn.execute(
                """UPDATE bas_lodgements SET label_1a = ?, label_1b = ?, label_w1 = ?,
                label_w2 = ?, gst_payable = ?, payg_withheld = ?, total_payable = ?
                WHERE id = ?""",
                (label_1a, label_1b, round(label_w1, 2), round(label_w2, 2),
                 gst_payable, payg_withheld, total_payable, existing["id"]),
            )
            bas_id = existing["id"]
        else:
            period_label = BAS_QUARTERS[quarter]["label"]
            cursor = conn.execute(
                """INSERT INTO bas_lodgements
                (period, quarter, financial_year, label_1a, label_1b, label_w1, label_w2,
                 gst_payable, payg_withheld, total_payable)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (f"{period_label} {financial_year}/{financial_year+1}", quarter, financial_year,
                 label_1a, label_1b, round(label_w1, 2), round(label_w2, 2),
                 gst_payable, payg_withheld, total_payable),
            )
            bas_id = cursor.lastrowid

        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        return dict(row)


def income_tax_provision(financial_year: int) -> dict:
    """Calculate income tax provision for a financial year."""
    from app.services.reports import profit_and_loss

    fy_start = f"{financial_year}-07-01"
    fy_end = f"{financial_year + 1}-06-30"

    pnl = profit_and_loss(fy_start, fy_end)
    taxable_income = max(pnl["net_profit"], 0)
    tax_amount = round(taxable_income * COMPANY_TAX_RATE, 2)

    return {
        "financial_year": f"{financial_year}/{financial_year + 1}",
        "taxable_income": round(taxable_income, 2),
        "tax_rate": COMPANY_TAX_RATE,
        "tax_amount": tax_amount,
        "net_profit": pnl["net_profit"],
    }
