"""Local/internal AMTL Finance Suite wrapper state.

This layer deliberately stays local: fixtures, receipts, report packs and
scenario outputs only. Live bank, accounting, tax lodgement and provider
mutations are represented as blocked approval-gated actions.
"""

from __future__ import annotations

import csv
import io
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4



from app.config import DATA_DIR
STATE_PATH = DATA_DIR / "finance-suite-state.json"
APPROVED_RISK_SOURCE_FILES = [
    Path("C:/Users/Mani/Downloads/AMTL-FINANCE-SUITE-SPEC-260326.md"),
    Path("C:/Users/Mani/AMTL-docs/GENIE-PRODUCT-SPEC-v3.md"),
    Path("C:/Users/Mani/AMTL-docs/THE-LEDGER-PRODUCT-SPEC-v2-280326.md"),
    Path("C:/Users/Mani/AMTL-docs/FIN-STRATEGIST-SPEC.md"),
    Path("C:/Users/Mani/Documents/New project/AMTL-FINANCE-SUITE-STATUS-20260628.md"),
]
RISK_SOURCE_ROOTS = [
    Path("\\\\NAS2\\amtl-documents"),
    Path("\\\\NAS1\\Nas"),
]
RISK_EXCLUDED_SOURCE_PREFIXES = [
    "\\\\NAS2\\amtl-documents\\escalation-logs\\linux logs\\wazuz\\prefe".lower(),
    "\\\\Nas1\\Nas\\Programs\\Spiritual\\Dr Joe Dispenza\\Generous moment\\mani".lower(),
]
RISK_INDEXABLE_EXTENSIONS = {".md", ".txt", ".csv", ".json", ".log", ".html", ".htm"}
RISK_SOURCE_INDEX_MAX_BYTES = 120_000

COMPLIANCE_BOUNDARY = (
    "Private decision support only. Not financial, tax, legal, "
    "accounting, investment or lodgement advice."
)


MODULES = [
    {
        "id": "genie",
        "name": "Genie",
        "role": "Bookkeeper intelligence",
        "route": "/finance/genie",
        "status": "local_wrapper_ready",
        "surfaces": [
            "contacts finance lens",
            "payables and receivables intelligence",
            "vendor/client signal cards",
            "CRM sync stubs",
            "blocked bank/provider sync",
        ],
    },
    {
        "id": "ledger",
        "name": "The Ledger",
        "role": "Accountant intelligence",
        "route": "/finance/ledger",
        "status": "existing_app_preserved",
        "surfaces": [
            "accounts",
            "transactions",
            "journals",
            "imports",
            "adjustments",
            "tax support without lodgement",
            "reports and narrative",
            "forensic accounting review",
        ],
    },
    {
        "id": "strategist",
        "name": "Fin Strategist",
        "role": "CFO intelligence",
        "route": "/finance/strategist",
        "status": "local_scenario_engine_ready",
        "surfaces": [
            "cashflow scenarios",
            "runway",
            "margin and pricing",
            "forecasting",
            "risk and investment support",
            "decision receipts",
        ],
    },
    {
        "id": "runway",
        "name": "Chief Financial / Runway Officer",
        "role": "Runway, spend and savings control",
        "route": "/finance/runway",
        "status": "local_runway_control_ready",
        "surfaces": [
            "runway command",
            "subscription intelligence",
            "vendor cost control",
            "AI model cost review",
            "ROI tracker",
            "waste reduction",
            "quality-safe savings",
            "approval and evidence receipts",
        ],
    },
    {
        "id": "personal",
        "name": "SAK Personal Finance adjacency",
        "role": "Read-only adjacent reference",
        "route": "/finance/admin",
        "status": "local_reference_only",
        "surfaces": ["read-only reference", "no full integration claim"],
    },
]

BLOCKED_ACTIONS = {
    "bank_sync": "No bank/CDR credential, consent artefact, target account, or approval.",
    "accounting_write": "No accounting platform write target, rollback plan, or approval.",
    "bas_lodgement": "Tax lodgement is out of scope and requires qualified human/legal workflow.",
    "payroll_mutation": "Payroll/payment mutations are forbidden in this local/internal wrapper.",
    "pay_stub_finalise": "Pay-stub/pay-slip drafts can be prepared for human review, but final save/post/file/send remains human-owned.",
    "provider_send": "External model/provider sends require explicit approval and configured secrets.",
    "gateway_registration": "Gateway/Beast mutation requires Mani approval.",
    "investment_advice": "Investment recommendations are out of scope for this local/internal support surface.",
    "tax_advice": "Tax advice and lodgement require a qualified human workflow and explicit approval.",
    "legal_advice": "Legal advice is out of scope for this local/internal support surface.",
    "browser_final_submit": "Browser assist may draft and guide, but final submit/post/pay/reconcile clicks remain human-owned.",
}

CROSS_APP_DESTINATIONS = {
    "elaine": {
        "name": "Elaine",
        "role": "Operator briefing and personal intelligence",
        "route": "local_stub",
        "safe_mode": "read_only_briefing_packet",
        "why": "Elaine should know what Mani may need attention on, without taking finance action.",
        "receives": ["runway_watch", "cashflow_watch", "browser_assist_review", "risk_owner_missing"],
    },
    "baldrick": {
        "name": "Baldrick",
        "role": "Runtime/orchestration health",
        "route": "runtime_registry",
        "safe_mode": "runtime_status_packet",
        "why": "Baldrick should know route health, fallback state and evidence freshness.",
        "receives": ["runtime_health", "dependency_fallback", "route_proof", "evidence_updated"],
    },
    "costanza": {
        "name": "Costanza",
        "role": "Customer/account relationship context",
        "route": "local_stub",
        "safe_mode": "customer_finance_signal_draft",
        "why": "Costanza can prepare careful customer-facing follow-up drafts from local finance signals.",
        "receives": ["payment_risk", "customer_margin_watch", "client_followup_draft"],
    },
    "ripple": {
        "name": "Ripple",
        "role": "Revenue truth and pipeline context",
        "route": "local_stub",
        "safe_mode": "revenue_signal_packet",
        "why": "Ripple can use finance signals to review revenue concentration, pricing and pipeline timing.",
        "receives": ["revenue_concentration", "pricing_margin_signal", "cash_timing"],
    },
    "spark": {
        "name": "Spark",
        "role": "Campaign, offer and ROI intelligence",
        "route": "local_stub",
        "safe_mode": "roi_and_offer_signal_packet",
        "why": "Spark can use finance evidence to assess ROI, offer quality and marketing spend waste.",
        "receives": ["roi_watch", "campaign_cost_signal", "pricing_experiment"],
    },
    "workshop": {
        "name": "Workshop",
        "role": "Launcher and app control surface",
        "route": "registry_only",
        "safe_mode": "launcher_status_packet",
        "why": "Workshop should know Finance Suite routes, modules and health state.",
        "receives": ["route_health", "module_list", "evidence_file"],
    },
    "beast": {
        "name": "Beast",
        "role": "Port sentinel and runtime truth",
        "route": "runtime_registry_only",
        "safe_mode": "port_health_packet",
        "why": "Beast should know port, PID, health and proof state without public route mutation.",
        "receives": ["port_truth", "pid", "health_route", "fallback_state"],
    },
    "chronicle": {
        "name": "Chronicle",
        "role": "Evidence and memory",
        "route": "local_stub",
        "safe_mode": "memory_adapter_packet",
        "why": "Chronicle can remember source-backed finance decisions and evidence events.",
        "receives": ["evidence_memory", "report_ready", "risk_review", "rag_index_update"],
    },
    "ck_writer": {
        "name": "CK Writer / Author Studio",
        "role": "Report and explanation drafting",
        "route": "local_stub",
        "safe_mode": "writing_brief_packet",
        "why": "CK Writer can draft internal explanations from finance evidence without publishing.",
        "receives": ["report_brief", "risk_summary", "runway_summary", "customer_safe_wording"],
    },
    "digital_sentinel": {
        "name": "Digital Sentinel",
        "role": "Vendor/security/compliance risk review",
        "route": "local_stub",
        "safe_mode": "vendor_risk_packet",
        "why": "Digital Sentinel can review vendor dependency and compliance risk signals.",
        "receives": ["vendor_dependency", "data_quality", "compliance_boundary", "forensic_review_signal"],
    },
    "concierge": {
        "name": "Concierge",
        "role": "Human handoff and task intake",
        "route": "local_stub",
        "safe_mode": "handoff_task_draft",
        "why": "Concierge can turn finance signals into human-review tasks when a receipt is missing.",
        "receives": ["human_review_task", "destination_receipt_missing", "manual_followup"],
    },
    "pre_sales": {
        "name": "Pre-Sales Command Centre",
        "role": "Commercial proposal context",
        "route": "local_stub",
        "safe_mode": "commercial_assumption_packet",
        "why": "Pre-Sales can use pricing, margin and cash timing assumptions in proposal work.",
        "receives": ["pricing_assumption", "vendor_cost_assumption", "payment_terms_risk"],
    },
}

PRODUCTS = {
    "genie": {
        "name": "Genie",
        "claim": "DONE_LOCAL_INTERNAL_GENIE_ONLY",
        "route": "/finance/genie",
        "health": "/finance/api/genie/health",
        "tabs": [
            "Ask Genie",
            "Context Sources",
            "Answer Draft",
            "Caveats",
            "Follow-Up Questions",
            "Receipts",
            "Admin / Proof",
        ],
    },
    "ledger": {
        "name": "The Ledger",
        "claim": "DONE_LOCAL_INTERNAL_LEDGER_ONLY",
        "route": "/finance/ledger",
        "health": "/finance/api/ledger/health",
        "tabs": [
            "Imports",
            "Ledger Entries",
            "Reconciliation",
            "Categories",
            "Exceptions",
            "Forensic Accounting",
            "Reports",
            "Receipts",
            "Admin / Proof",
        ],
    },
    "strategist": {
        "name": "Fin Strategist",
        "claim": "DONE_LOCAL_INTERNAL_FIN_STRATEGIST_ONLY",
        "route": "/finance/strategist",
        "health": "/finance/api/strategist/health",
        "tabs": [
            "Scenario Inputs",
            "Cashflow View",
            "What-If Scenarios",
            "Risks",
            "Assumptions",
            "Actions Draft",
            "Reports",
            "Receipts",
            "Admin / Proof",
        ],
    },
    "runway": {
        "name": "Chief Financial / Runway Officer",
        "claim": "DONE_LOCAL_INTERNAL_RUNWAY_OFFICER_ONLY",
        "route": "/finance/runway",
        "health": "/finance/api/runway/health",
        "tabs": [
            "Command",
            "Runway",
            "Subscriptions",
            "Vendors",
            "AI Costs",
            "ROI",
            "Waste",
            "Savings",
            "Approvals",
            "Evidence",
        ],
    },
}

DEMO_ORGANISATION = {
    "name": "Fat Lady Sang",
    "business_type": "services company",
    "service_line": "training services",
    "services": [
        "leadership workshops",
        "staff enablement sessions",
        "facilitated training days",
        "training-retainer support",
    ],
    "source": "synthetic_fixture",
}

FIXTURE_CSV = """date,description,amount,kind,source
2026-06-03,Fat Lady Sang leadership workshop invoice,8800.00,receivable,synthetic_fixture
2026-06-06,Fat Lady Sang facilitator contractor,-2400.00,payable,synthetic_fixture
2026-06-12,Fat Lady Sang learning platform subscription,-420.00,payable,synthetic_fixture
2026-06-20,Fat Lady Sang training retainer receipt,6200.00,receivable,synthetic_fixture
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ai_provider_readiness() -> dict[str, Any]:
    return {"state": "unavailable", "configured": False, "key_configured": False,
            "message": "Feature not in this build", "provider_call_performed": False}


def _default_state() -> dict[str, Any]:
    return {
        "product": "AMTL Finance Suite",
        "mode": "local_internal_only",
        "synthetic_data_present": True,
        "synthetic_removed_at": None,
        "created_at": _now(),
        "updated_at": _now(),
        "imports": [],
        "receipts": [],
        "reports": [],
        "scenarios": [],
        "browser_assist": [],
        "browser_assist_artifacts": [],
        "cross_app_outbox": [],
        "cross_app_destination_receipts": [],
        "products": _default_products_state(),
    }


def _fixture_rows() -> list[dict[str, Any]]:
    return list(csv.DictReader(io.StringIO(FIXTURE_CSV)))


def _ledger_entry_from_row(row: dict[str, Any], index: int, source_id: str = "fixture") -> dict[str, Any]:
    amount = float(row.get("amount") or 0)
    category = "Revenue" if amount >= 0 else "Operating expense"
    confidence = 0.92 if row.get("source") == "synthetic_fixture" else 0.78
    return {
        "id": f"ledger-entry-{source_id}-{index}",
        "date": row.get("date", ""),
        "description": row.get("description", ""),
        "amount": round(amount, 2),
        "kind": row.get("kind") or ("receivable" if amount >= 0 else "payable"),
        "category": category,
        "source": row.get("source") or "manual_upload",
        "source_row": index,
        "confidence": confidence,
        "synthetic": row.get("source") == "synthetic_fixture",
        "receipt_id": None,
    }


def _default_products_state() -> dict[str, Any]:
    fixture = _fixture_rows()
    entries = [_ledger_entry_from_row(row, idx + 1) for idx, row in enumerate(fixture)]
    return {
        "genie": {
            "synthetic_data_present": True,
            "synthetic_removed_at": None,
            "answers": [],
            "context_sources": fixture,
            "receipts": [],
            "last_blocked": [],
        },
        "ledger": {
            "synthetic_data_present": True,
            "synthetic_removed_at": None,
            "imports": [],
            "entries": entries,
            "reconciliations": [],
            "reports": [],
            "forensic_cases": [],
            "receipts": [],
            "last_blocked": [],
        },
        "strategist": {
            "synthetic_data_present": True,
            "synthetic_removed_at": None,
            "scenarios": [],
            "receipts": [],
            "last_blocked": [],
            "fixture_rows": fixture,
        },
        "runway": {
            "synthetic_data_present": True,
            "synthetic_removed_at": None,
            "subscriptions": [
                {"name": "Training platform subscription", "vendor": "LearningCloud LMS", "monthly_cost": 420.0, "renewal": "2026-07-12", "usage": "high", "recommendation": "confirm active learner seats before renewal", "quality_risk": "low", "synthetic": True},
                {"name": "Course authoring allowance", "vendor": "CourseDraft Studio", "monthly_cost": 260.0, "renewal": "monthly", "usage": "medium", "recommendation": "batch course rewrites before model-heavy drafting", "quality_risk": "medium", "synthetic": True},
            ],
            "vendors": [
                {"vendor": "Senior Facilitator Pool", "monthly_spend": 2400.0, "dependency": "high", "renewal": "workshop based", "recommendation": "keep backup facilitator for booked training days", "synthetic": True},
                {"vendor": "LearningCloud LMS", "monthly_spend": 420.0, "dependency": "medium", "renewal": "2026-07-12", "recommendation": "seat and learner-usage review", "synthetic": True},
            ],
            "ai_costs": [
                {"provider": "local/manual usage export", "workflow": "training outline drafting", "monthly_cost": 260.0, "quality": "watch", "recommendation": "reuse approved modules before drafting fresh material", "synthetic": True},
            ],
            "roi_cases": [],
            "waste_candidates": [],
            "savings_recommendations": [],
            "approvals": [],
            "receipts": [],
            "last_blocked": [],
            "fixture_rows": fixture,
        },
    }


def load_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        state = _default_state()
        save_state(state)
        return state
    raw = STATE_PATH.read_text(encoding="utf-8")
    try:
        state = json.loads(raw)
    except json.JSONDecodeError:
        backup = STATE_PATH.with_suffix(f".corrupt-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}.json")
        backup.write_text(raw, encoding="utf-8")
        try:
            state, _ = json.JSONDecoder().raw_decode(raw)
        except json.JSONDecodeError:
            state = _default_state()
        if not isinstance(state, dict):
            state = _default_state()
        save_state(state)
    migrated = _migrate_state(state)
    if migrated:
        save_state(state)
    return state


def _migrate_state(state: dict[str, Any]) -> bool:
    changed = False
    if "products" not in state:
        state["products"] = _default_products_state()
        changed = True
    if "browser_assist" not in state:
        state["browser_assist"] = []
        changed = True
    if "browser_assist_artifacts" not in state:
        state["browser_assist_artifacts"] = []
        changed = True
    if "destination_receipts" not in state:
        state["destination_receipts"] = []
        changed = True
    if "cross_app_outbox" not in state:
        state["cross_app_outbox"] = []
        changed = True
    if "cross_app_destination_receipts" not in state:
        state["cross_app_destination_receipts"] = []
        changed = True
    if "ai_tasks" not in state:
        state["ai_tasks"] = []
        changed = True
    if "risk_intelligence" not in state:
        state["risk_intelligence"] = _default_risk_state()
        changed = True
    else:
        default_risk = _default_risk_state()
        for key, value in default_risk.items():
            if key not in state["risk_intelligence"]:
                state["risk_intelligence"][key] = value
                changed = True
    defaults = _default_products_state()
    for product, default in defaults.items():
        if product not in state["products"]:
            state["products"][product] = default
            changed = True
            continue
        for key, value in default.items():
            if key not in state["products"][product]:
                state["products"][product][key] = value
                changed = True
    return changed


def save_state(state: dict[str, Any]) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    state["updated_at"] = _now()
    if STATE_PATH.exists():
        try:
            current = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            if isinstance(current, dict):
                by_id = {receipt.get("id"): receipt for receipt in current.get("receipts", []) if receipt.get("id")}
                for receipt in state.get("receipts", []):
                    if receipt.get("id"):
                        by_id[receipt["id"]] = receipt
                state["receipts"] = sorted(by_id.values(), key=lambda row: row.get("created_at", ""), reverse=True)
        except json.JSONDecodeError:
            pass
    tmp_path = STATE_PATH.with_suffix(f".{os.getpid()}.tmp")
    tmp_path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(tmp_path, STATE_PATH)
            break
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.05 * (attempt + 1))


def create_receipt(kind: str, summary: str, source_refs: list[str] | None = None, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    state = load_state()
    receipt = {
        "id": f"finance-suite-{uuid4().hex[:12]}",
        "kind": kind,
        "summary": summary,
        "source_refs": source_refs or [],
        "payload": payload or {},
        "boundary": COMPLIANCE_BOUNDARY,
        "external_write": False,
        "provider_called": False,
        "created_at": _now(),
    }
    state["receipts"].insert(0, receipt)
    save_state(state)
    return receipt


def create_product_receipt(
    product: str,
    kind: str,
    summary: str,
    source_refs: list[str] | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    state = load_state()
    _assert_product(product)
    receipt = {
        "id": f"finance-{product}-{uuid4().hex[:12]}",
        "product": product,
        "kind": kind,
        "summary": summary,
        "source_refs": source_refs or [],
        "payload": payload or {},
        "boundary": COMPLIANCE_BOUNDARY,
        "external_write": False,
        "provider_called": False,
        "created_at": _now(),
    }
    state["products"][product]["receipts"].insert(0, receipt)
    state["receipts"].insert(0, receipt)
    save_state(state)
    return receipt


def _create_ai_receipt(receipt: dict[str, Any]) -> dict[str, Any]:
    state = load_state()
    state.setdefault("ai_tasks", []).insert(0, receipt)
    state["receipts"].insert(0, receipt)
    save_state(state)
    return receipt


def _assert_product(product: str) -> None:
    if product not in PRODUCTS:
        raise ValueError(f"Unknown Finance Suite product: {product}")


def suite_summary() -> dict[str, Any]:
    state = load_state()
    return {
        "product": "AMTL Finance Suite",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_SUITE_ONLY",
        "mode": "local_internal_only",
        "boundary": COMPLIANCE_BOUNDARY,
        "modules": MODULES,
        "blocked_actions": blocked_actions(),
        "local_paths": {
            "state": str(STATE_PATH),
            "legacy_ledger_routes": ["/api/accounts", "/api/transactions", "/api/imports/upload-text", "/api/reports/trial-balance"],
            "suite_routes": [
                "/finance/",
                "/finance/genie",
               "/finance/ledger",
               "/finance/strategist",
               "/finance/strategist/risk",
               "/finance/rag",
               "/finance/runway",
               "/finance/ledger/forensics",
               "/finance/reports",
               "/finance/imports",
               "/finance/evidence",
               "/finance/browser-assist",
               "/finance/admin",
           ],
       },
        "counts": {
            "receipts": len(state.get("receipts", [])),
            "imports": len(state.get("imports", [])),
            "reports": len(state.get("reports", [])),
            "scenarios": len(state.get("scenarios", [])),
            "genie_answers": len(state["products"]["genie"].get("answers", [])),
           "ledger_entries": len(state["products"]["ledger"].get("entries", [])),
           "ledger_forensic_cases": len(state["products"]["ledger"].get("forensic_cases", [])),
           "strategist_scenarios": len(state["products"]["strategist"].get("scenarios", [])),
           "risk_candidates": len(_risk_state(state).get("candidates", [])),
           "risk_register": len(_risk_state(state).get("risks", [])),
           "rag_sources": len(_risk_source_records(state)),
           "runway_subscriptions": len(state["products"]["runway"].get("subscriptions", [])),
           "runway_savings_recommendations": len(state["products"]["runway"].get("savings_recommendations", [])),
           "browser_assist_sessions": len(state.get("browser_assist", [])),
           "browser_assist_artifacts": len(state.get("browser_assist_artifacts", [])),
           "destination_owned_receipts": len(state.get("destination_receipts", [])),
           "cross_app_outbox_packets": len(state.get("cross_app_outbox", [])),
           "cross_app_destination_receipts": len(state.get("cross_app_destination_receipts", [])),
       },
       "product_claims": {
           key: product_health(key)["status"]
           for key in ("genie", "ledger", "strategist")
       }
       | {
           "risk_intelligence": risk_health()["status"],
           "rag_source_intelligence": rag_health()["status"],
           "runway_officer": runway_health()["status"],
           "cross_app_communications": cross_app_health()["status"],
           "browser_assist": browser_assist_health()["status"],
       },
        "demo_organisation": DEMO_ORGANISATION,
        "synthetic_data_present": demo_data_status()["synthetic_data_present"],
        "generated_at": _now(),
    }


def _product_counts(product: str, state: dict[str, Any]) -> dict[str, Any]:
    product_state = state["products"][product]
    if product == "genie":
        return {
            "answers": len(product_state.get("answers", [])),
            "context_sources": len(product_state.get("context_sources", [])),
            "receipts": len(product_state.get("receipts", [])),
            "blocked_actions": len(product_state.get("last_blocked", [])),
        }
    if product == "ledger":
        exceptions = ledger_exceptions(product_state.get("entries", []))
        return {
            "imports": len(product_state.get("imports", [])),
            "entries": len(product_state.get("entries", [])),
            "exceptions": len(exceptions),
            "forensic_cases": len(product_state.get("forensic_cases", [])),
            "reconciliations": len(product_state.get("reconciliations", [])),
            "reports": len(product_state.get("reports", [])),
            "receipts": len(product_state.get("receipts", [])),
        }
    if product == "runway":
        return {
            "subscriptions": len(product_state.get("subscriptions", [])),
            "vendors": len(product_state.get("vendors", [])),
            "ai_costs": len(product_state.get("ai_costs", [])),
            "roi_cases": len(product_state.get("roi_cases", [])),
            "waste_candidates": len(product_state.get("waste_candidates", [])),
            "savings_recommendations": len(product_state.get("savings_recommendations", [])),
            "approvals": len(product_state.get("approvals", [])),
            "receipts": len(product_state.get("receipts", [])),
            "blocked_actions": len(product_state.get("last_blocked", [])),
        }
    return {
        "scenarios": len(product_state.get("scenarios", [])),
        "fixture_rows": len(product_state.get("fixture_rows", [])),
        "receipts": len(product_state.get("receipts", [])),
        "blocked_actions": len(product_state.get("last_blocked", [])),
    }


def product_health(product: str) -> dict[str, Any]:
    _assert_product(product)
    state = load_state()
    meta = PRODUCTS[product]
    return {
        "product": meta["name"],
        "product_id": product,
        "status": meta["claim"],
        "mode": "local_internal_only",
        "route": meta["route"],
        "health_route": meta["health"],
        "tabs": meta["tabs"],
        "boundary": COMPLIANCE_BOUNDARY,
        "counts": _product_counts(product, state),
        "count_drilldowns": product_drilldowns(product),
        "right_rail": right_rail(product),
        "failure_states": failure_states(product),
        "blocked_actions": blocked_actions(),
        "synthetic_data_present": bool(state["products"][product].get("synthetic_data_present")),
        "receipt_count": len(state["products"][product].get("receipts", [])),
        "last_verified": _now(),
    }


def right_rail(product: str) -> dict[str, str]:
    names = {
        "genie": "local finance intelligence draft",
        "ledger": "local ledger review",
        "strategist": "local scenario planning",
        "runway": "subscription, vendor, AI cost, ROI and runway control",
    }
    return {
        "what": f"{PRODUCTS[product]['name']} provides {names[product]} from local/manual data only.",
        "why": "It gives Mani internal working evidence without pretending to connect to banks, accounting systems, tax systems or paid providers.",
        "how": "Rows are read from local fixtures/uploads, transformed into local outputs, and written to the JSON state file with receipts.",
        "who_owns_it": "Mani / AMTL local operator. Human review owns every financial decision.",
        "source_evidence": str(STATE_PATH),
        "freshness": _now(),
        "confidence": "medium for local fixture logic; lower for any imported row with missing source or weak categorisation.",
        "risk_if_wrong": "Could mislead internal planning if treated as advice or live financial truth.",
        "next_safe_action": "Review the cited rows, adjust assumptions locally, then create an internal receipt or report pack.",
        "write_boundary": "No external writes, lodgements, payments, payroll mutations or provider sends.",
        "receipt_link": f"/finance/api/{product}/receipts",
        "eli10": "This is a local calculator and evidence desk, not a bank or accountant.",
    }


def failure_states(product: str) -> list[dict[str, str]]:
    return [
        {"state": "no_data", "message": "Empty local data is shown as no local rows yet, not as live zero."},
        {"state": "synthetic_present", "message": "Synthetic rows are labelled and removable."},
        {"state": "synthetic_removed", "message": "Removal keeps receipts and strips synthetic rows from the product view."},
        {"state": "provider_gated", "message": "Model/provider sends are blocked_approval_required."},
        {"state": "bank_api_gated", "message": "Bank/API sync is blocked_approval_required."},
        {"state": "accounting_write_gated", "message": "Accounting writes are blocked_approval_required."},
        {"state": "bas_lodgement_gated", "message": "BAS/GST/tax lodgement is blocked_approval_required."},
        {"state": "payroll_payment_gated", "message": "Payroll/payment mutation is blocked_approval_required."},
        {"state": "no_receipts", "message": "No receipts yet is shown honestly until a local action occurs."},
        {"state": "no_outputs_yet", "message": "No answers, reports or scenarios yet is shown as an empty state."},
        {"state": "persistence_empty", "message": "Missing local state recreates a labelled local starter state."},
    ]


def product_drilldowns(product: str) -> dict[str, Any]:
    state = load_state()
    product_state = state["products"][product]
    if product == "genie":
        return {
            "answers": product_state.get("answers", []),
            "context_sources": product_state.get("context_sources", []),
            "receipts": product_state.get("receipts", []),
        }
    if product == "ledger":
        entries = product_state.get("entries", [])
        return {
            "entries": entries,
            "exceptions": ledger_exceptions(entries),
            "forensic_cases": product_state.get("forensic_cases", []),
            "reconciliations": product_state.get("reconciliations", []),
            "reports": product_state.get("reports", []),
            "receipts": product_state.get("receipts", []),
        }
    if product == "runway":
        return {
            "subscriptions": product_state.get("subscriptions", []),
            "vendors": product_state.get("vendors", []),
            "ai_costs": product_state.get("ai_costs", []),
            "roi_cases": product_state.get("roi_cases", []),
            "waste_candidates": product_state.get("waste_candidates", []),
            "savings_recommendations": product_state.get("savings_recommendations", []),
            "approvals": product_state.get("approvals", []),
            "receipts": product_state.get("receipts", []),
        }
    return {
        "scenarios": product_state.get("scenarios", []),
        "fixture_rows": product_state.get("fixture_rows", []),
        "receipts": product_state.get("receipts", []),
    }


def product_receipts(product: str) -> list[dict[str, Any]]:
    _assert_product(product)
    return load_state()["products"][product].get("receipts", [])


def product_demo_data_status(product: str) -> dict[str, Any]:
    _assert_product(product)
    state = load_state()
    product_state = state["products"][product]
    if product == "ledger":
        rows = product_state.get("entries", [])
    elif product == "genie":
        rows = product_state.get("context_sources", [])
    elif product == "runway":
        rows = (
            product_state.get("subscriptions", [])
            + product_state.get("vendors", [])
            + product_state.get("ai_costs", [])
            + product_state.get("fixture_rows", [])
        )
    else:
        rows = product_state.get("fixture_rows", [])
    synthetic_rows = [row for row in rows if row.get("synthetic") or row.get("source") == "synthetic_fixture"]
    return {
        "product": product,
        "synthetic_data_present": bool(product_state.get("synthetic_data_present")),
        "synthetic_removed_at": product_state.get("synthetic_removed_at"),
        "fixture_rows": len(synthetic_rows),
        "boundary": "Synthetic rows are labelled and removable; no fake live data claim is made.",
    }


def remove_product_synthetic(product: str, preview: bool = False) -> dict[str, Any]:
    _assert_product(product)
    state = load_state()
    before = product_demo_data_status(product)
    if preview:
        return {"preview": True, "would_remove_fixture_rows": before["fixture_rows"], **before}
    product_state = state["products"][product]
    if product == "ledger":
        product_state["entries"] = [row for row in product_state.get("entries", []) if not row.get("synthetic")]
    elif product == "genie":
        product_state["context_sources"] = [row for row in product_state.get("context_sources", []) if row.get("source") != "synthetic_fixture"]
    elif product == "runway":
        for key in ("subscriptions", "vendors", "ai_costs"):
            product_state[key] = [row for row in product_state.get(key, []) if not row.get("synthetic")]
        product_state["fixture_rows"] = [row for row in product_state.get("fixture_rows", []) if row.get("source") != "synthetic_fixture"]
    else:
        product_state["fixture_rows"] = [row for row in product_state.get("fixture_rows", []) if row.get("source") != "synthetic_fixture"]
    product_state["synthetic_data_present"] = False
    product_state["synthetic_removed_at"] = _now()
    save_state(state)
    receipt = create_product_receipt(product, "remove_synthetic", f"Removed {PRODUCTS[product]['name']} synthetic fixture rows.", [f"finance-{product}-demo-data"])
    return {"preview": False, "removed_fixture_rows": before["fixture_rows"], "receipt_id": receipt["id"], **product_demo_data_status(product)}


def reload_product_synthetic(product: str) -> dict[str, Any]:
    _assert_product(product)
    state = load_state()
    product_state = state["products"][product]
    fixture = _fixture_rows()
    if product == "ledger":
        reload_id = f"synthetic-reload-{uuid4().hex[:8]}"
        product_state["entries"] = [_ledger_entry_from_row(row, idx + 1, reload_id) for idx, row in enumerate(fixture)] + [
            row for row in product_state.get("entries", []) if not row.get("synthetic")
        ]
        product_state["imports"].insert(0, {"id": reload_id, "filename": "synthetic-reload-fixture.csv", "row_count": len(fixture), "synthetic": True, "created_at": _now(), "source": "local_demo_reload"})
    elif product == "genie":
        product_state["context_sources"] = fixture + [
            row for row in product_state.get("context_sources", []) if row.get("source") != "synthetic_fixture"
        ]
    elif product == "runway":
        defaults = _default_products_state()["runway"]
        for key in ("subscriptions", "vendors", "ai_costs"):
            existing = [row for row in product_state.get(key, []) if not row.get("synthetic")]
            product_state[key] = list(defaults[key]) + existing
        product_state["fixture_rows"] = fixture + [
            row for row in product_state.get("fixture_rows", []) if row.get("source") != "synthetic_fixture"
        ]
    else:
        product_state["fixture_rows"] = fixture + [
            row for row in product_state.get("fixture_rows", []) if row.get("source") != "synthetic_fixture"
        ]
    product_state["synthetic_data_present"] = True
    product_state["synthetic_removed_at"] = None
    save_state(state)
    receipt = create_product_receipt(product, "reload_synthetic", f"Reloaded labelled {PRODUCTS[product]['name']} synthetic demo rows.", [f"finance-{product}-demo-data"], {"row_count": len(fixture)})
    return {"product": product, "reloaded_fixture_rows": len(fixture), "receipt_id": receipt["id"], **product_demo_data_status(product)}


def product_blocked_action(product: str, action: str) -> dict[str, Any]:
    _assert_product(product)
    reason = BLOCKED_ACTIONS.get(action, "Unknown external or regulated action; blocked until approved target exists.")
    receipt = create_product_receipt(
        product,
        "blocked_external_action",
        f"{PRODUCTS[product]['name']} {action} blocked by local/internal finance boundary.",
        [f"finance-{product}-boundary"],
        {"action": action, "reason": reason},
    )
    state = load_state()
    state["products"][product]["last_blocked"].insert(0, {"action": action, "reason": reason, "receipt_id": receipt["id"], "created_at": _now()})
    save_state(state)
    return {
        "product": product,
        "action": action,
        "state": "blocked_approval_required",
        "reason": reason,
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def runway_health() -> dict[str, Any]:
    health = product_health("runway")
    health["status"] = "DONE_LOCAL_INTERNAL_RUNWAY_OFFICER_ONLY"
    health["mode"] = "local_internal_cost_runway_decision_support_only"
    health["source_contract"] = {
        "subscriptions": "manual exports, pasted vendor lists, browser-assist artifacts or RAG source hits",
        "vendor_costs": "Ledger entries, accounting-software exports, CSV uploads and user overrides",
        "ai_model_costs": "manual provider exports, usage summaries and local estimates",
        "roi": "user-entered benefit assumptions and local evidence references",
        "quality": "human-owned quality-risk rating; no automatic downgrade recommendation is final",
    }
    health["controls"] = [
        "Run cost scan",
        "Generate runway forecast",
        "Find waste",
        "Draft savings plan",
        "Add user override",
        "Create approval receipt",
        "Gate external/vendor/accounting action",
    ]
    return health


def run_runway_cost_scan() -> dict[str, Any]:
    state = load_state()
    runway = state["products"]["runway"]
    subscriptions = runway.get("subscriptions", [])
    vendors = runway.get("vendors", [])
    ai_costs = runway.get("ai_costs", [])
    total_subscriptions = round(sum(float(row.get("monthly_cost") or 0) for row in subscriptions), 2)
    total_vendors = round(sum(float(row.get("monthly_spend") or 0) for row in vendors), 2)
    total_ai = round(sum(float(row.get("monthly_cost") or 0) for row in ai_costs), 2)
    potential_waste: list[dict[str, Any]] = []
    for row in subscriptions:
        cost = float(row.get("monthly_cost") or 0)
        usage = str(row.get("usage") or "").lower()
        if usage in {"low", "medium"} and cost > 100:
            potential_waste.append(
                {
                    "type": "subscription",
                    "name": row.get("name"),
                    "monthly_cost": cost,
                    "reason": f"{row.get('usage')} usage with reviewable monthly cost",
                    "quality_risk": row.get("quality_risk", "unknown"),
                    "recommendation": row.get("recommendation", "review before changing"),
                }
            )
    for row in ai_costs:
        cost = float(row.get("monthly_cost") or 0)
        if cost > 0:
            potential_waste.append(
                {
                    "type": "ai_cost",
                    "name": row.get("workflow"),
                    "monthly_cost": cost,
                    "reason": "AI spend should be reviewed for batching, caching and prompt reuse before model downgrade.",
                    "quality_risk": row.get("quality", "watch"),
                    "recommendation": row.get("recommendation", "review quality-safe optimisations"),
                }
            )
    scan = {
        "id": f"runway-scan-{uuid4().hex[:10]}",
        "monthly_totals": {
            "subscriptions": total_subscriptions,
            "vendors": total_vendors,
            "ai_costs": total_ai,
            "combined": round(total_subscriptions + total_vendors + total_ai, 2),
        },
        "waste_candidates": potential_waste,
        "created_at": _now(),
        "boundary": COMPLIANCE_BOUNDARY,
        "external_write": False,
        "provider_called": False,
    }
    runway["waste_candidates"] = potential_waste
    runway.setdefault("roi_cases", []).insert(
        0,
        {
            "id": f"roi-{uuid4().hex[:8]}",
            "initiative": "Quality-safe cost review",
            "monthly_cost_base": scan["monthly_totals"]["combined"],
            "estimated_monthly_saving": round(sum(float(row.get("monthly_cost") or 0) * 0.12 for row in potential_waste), 2),
            "quality_guardrail": "Do not reduce quality, reliability or customer experience without human approval.",
            "synthetic": any(row.get("synthetic") for row in subscriptions + vendors + ai_costs),
            "created_at": _now(),
        },
    )
    save_state(state)
    receipt = create_product_receipt(
        "runway",
        "runway_cost_scan",
        "Ran Chief Financial / Runway Officer local cost scan.",
        ["finance-runway-cost-scan"],
        {"scan_id": scan["id"], "monthly_totals": scan["monthly_totals"], "waste_candidates": len(potential_waste)},
    )
    scan["receipt_id"] = receipt["id"]
    return scan


def create_runway_savings_plan() -> dict[str, Any]:
    state = load_state()
    runway = state["products"]["runway"]
    candidates = runway.get("waste_candidates", [])
    if not candidates:
        run_runway_cost_scan()
        state = load_state()
        runway = state["products"]["runway"]
        candidates = runway.get("waste_candidates", [])
    recommendations = []
    for candidate in candidates:
        cost = float(candidate.get("monthly_cost") or 0)
        recommendations.append(
            {
                "id": f"saving-{uuid4().hex[:8]}",
                "target": candidate.get("name"),
                "monthly_cost_under_review": cost,
                "estimated_saving": round(cost * 0.1, 2),
                "quality_guardrail": "Human review required before cancellation, downgrade, vendor negotiation or workflow change.",
                "next_action": candidate.get("recommendation") or "review with owner",
                "approval_state": "human_review_required",
                "created_at": _now(),
            }
        )
    runway["savings_recommendations"] = recommendations
    save_state(state)
    receipt = create_product_receipt(
        "runway",
        "runway_savings_plan",
        "Drafted quality-safe Runway Officer savings plan.",
        ["finance-runway-savings-plan"],
        {"recommendation_count": len(recommendations), "external_write": False},
    )
    return {
        "status": "runway_savings_plan_created_local_only",
        "recommendations": recommendations,
        "recommendation_count": len(recommendations),
        "receipt_id": receipt["id"],
        "provider_called": False,
        "external_write": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def _current_rows_for_reasoning(state: dict[str, Any]) -> list[dict[str, Any]]:
    ledger_rows = state["products"]["ledger"].get("entries", [])
    if ledger_rows:
        return ledger_rows
    return [_ledger_entry_from_row(row, idx + 1) for idx, row in enumerate(state["products"]["genie"].get("context_sources", []))]


def genie_ask(question: str) -> dict[str, Any]:
    state = load_state()
    rows = _current_rows_for_reasoning(state)
    receivables = round(sum(row["amount"] for row in rows if row["amount"] > 0), 2)
    payables = round(abs(sum(row["amount"] for row in rows if row["amount"] < 0)), 2)
    net = round(receivables - payables, 2)
    cited = rows[:5]
    caveats = [
        COMPLIANCE_BOUNDARY,
        "Draft uses only local fixture/upload rows currently in the Finance Suite state file.",
        "No bank, accounting, CRM or provider API was called.",
        "Human review is required before acting on any finance, tax, legal, accounting or investment matter.",
    ]
    blocked_terms = ["invest", "tax advice", "bas", "gst lodgement", "lodge", "legal advice", "payroll", "payment"]
    blocked = any(term in question.lower() for term in blocked_terms)
    if blocked:
        answer = "This request touches advice, lodgement, payment, payroll or regulated action. Genie can only draft internal questions and cite local rows until Mani approves an appropriate human workflow."
        receipt_kind = "blocked_guidance_request"
    elif not rows:
        answer = "No local finance rows are available yet. Import a local CSV or fixture before Genie drafts a finance intelligence answer."
        receipt_kind = "empty_answer"
    else:
        answer = (
            f"Local draft: the current local rows show {receivables:.2f} in receivable-positive items, "
            f"{payables:.2f} in payable-negative items and a net local cash effect of {net:.2f}. "
            "The safest next step is to review the largest payable/receivable rows and confirm their source before making any decision."
        )
        receipt_kind = "genie_ask"
    response = {
        "product": "genie",
        "question": question,
        "answer_draft": answer,
        "caveats": caveats,
        "assumptions": [
            "Amounts are treated as positive inflows and negative outflows.",
            "Synthetic rows, when present, are demonstration rows only.",
            "Rows without an external receipt are local evidence only.",
        ],
        "unknowns": [
            "Live bank balance",
            "Accounting platform truth",
            "Tax treatment",
            "Customer payment certainty",
        ],
        "follow_up_questions": [
            "Which row source should be treated as authoritative?",
            "Are any of these rows synthetic or stale?",
            "Which decision is this draft meant to support?",
        ],
        "source_rows": cited,
        "blocked_advice": blocked,
        "boundary": COMPLIANCE_BOUNDARY,
    }
    receipt = create_product_receipt("genie", receipt_kind, "Genie produced a local/internal answer draft.", ["finance-genie-local-context"], {"question": question, "blocked_advice": blocked})
    response["receipt_id"] = receipt["id"]
    state = load_state()
    state["products"]["genie"]["answers"].insert(0, {**response, "created_at": _now()})
    save_state(state)
    return response


def ledger_import(csv_text: str | None = None, filename: str = "ledger-local-fixture.csv") -> dict[str, Any]:
    state = load_state()
    rows = list(csv.DictReader(io.StringIO(csv_text or FIXTURE_CSV)))
    if not rows:
        raise ValueError("Ledger import contained no rows.")
    import_id = f"ledger-import-{uuid4().hex[:10]}"
    entries = [_ledger_entry_from_row(row, idx + 1, import_id) for idx, row in enumerate(rows)]
    product_state = state["products"]["ledger"]
    import_record = {
        "id": import_id,
        "filename": filename,
        "row_count": len(entries),
        "synthetic": any(entry["synthetic"] for entry in entries),
        "created_at": _now(),
        "source": "manual_fixture_or_upload",
    }
    product_state["imports"].insert(0, import_record)
    product_state["entries"] = entries + product_state.get("entries", [])
    product_state["synthetic_data_present"] = product_state["synthetic_data_present"] or import_record["synthetic"]
    save_state(state)
    receipt = create_product_receipt("ledger", "manual_import", f"Imported {len(entries)} Ledger rows from {filename}.", [filename], {"import_id": import_id, "row_count": len(entries)})
    state = load_state()
    for entry in state["products"]["ledger"]["entries"]:
        if entry["id"].startswith(f"ledger-entry-{import_id}-"):
            entry["receipt_id"] = receipt["id"]
    save_state(state)
    return {**import_record, "entries": entries, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def ledger_entries() -> dict[str, Any]:
    state = load_state()
    entries = state["products"]["ledger"].get("entries", [])
    return {
        "entries": entries,
        "exceptions": ledger_exceptions(entries),
        "categories": sorted({entry.get("category", "Uncategorised") for entry in entries}),
        "boundary": COMPLIANCE_BOUNDARY,
    }


def ledger_exceptions(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    exceptions = []
    for entry in entries:
        if abs(float(entry.get("amount") or 0)) >= 1500 or float(entry.get("confidence") or 0) < 0.8:
            exceptions.append({
                "entry_id": entry.get("id"),
                "reason": "large_amount_review" if abs(float(entry.get("amount") or 0)) >= 1500 else "low_confidence_category",
                "amount": entry.get("amount"),
                "confidence": entry.get("confidence"),
            })
    return exceptions


def ledger_reconcile() -> dict[str, Any]:
    state = load_state()
    entries = state["products"]["ledger"].get("entries", [])
    total = round(sum(float(entry.get("amount") or 0) for entry in entries), 2)
    exceptions = ledger_exceptions(entries)
    reconciliation = {
        "id": f"ledger-reconcile-{uuid4().hex[:10]}",
        "entry_count": len(entries),
        "net_local_total": total,
        "exceptions": exceptions,
        "status": "draft_local_reconciliation",
        "matched_external_bank": False,
        "external_write": False,
        "boundary": COMPLIANCE_BOUNDARY,
        "created_at": _now(),
    }
    state["products"]["ledger"]["reconciliations"].insert(0, reconciliation)
    state["products"]["ledger"]["reports"].insert(0, {"id": f"ledger-report-{uuid4().hex[:10]}", "type": "local_exception_report", "rows": exceptions, "created_at": _now()})
    save_state(state)
    receipt = create_product_receipt("ledger", "local_reconciliation", "Created local-only Ledger reconciliation draft.", ["finance-ledger-entries"], {"reconciliation_id": reconciliation["id"]})
    reconciliation["receipt_id"] = receipt["id"]
    return reconciliation


def _forensic_signal_for_entry(entry: dict[str, Any], duplicate_keys: dict[tuple[str, float], int], same_day_amounts: dict[tuple[str, float], int]) -> list[dict[str, Any]]:
    amount = abs(float(entry.get("amount") or 0))
    description = str(entry.get("description") or "")
    desc_key = description.strip().lower()
    date_key = str(entry.get("date") or "")
    signals: list[dict[str, Any]] = []
    if duplicate_keys.get((desc_key, amount), 0) > 1 and amount:
        signals.append({"type": "duplicate_description_amount", "severity": "medium", "reason": "Same description and amount appears more than once."})
    if same_day_amounts.get((date_key, amount), 0) > 1 and amount >= 500:
        signals.append({"type": "same_day_same_amount", "severity": "medium", "reason": "Same amount appears multiple times on the same date."})
    if amount >= 5000:
        signals.append({"type": "high_value_transaction", "severity": "high", "reason": "Large local ledger amount needs source-document review."})
    if amount >= 1000 and amount % 1000 == 0:
        signals.append({"type": "round_amount_review", "severity": "medium", "reason": "Large round amount can indicate estimate, split, cash or manual adjustment."})
    if float(entry.get("confidence") or 0) < 0.8:
        signals.append({"type": "low_confidence_classification", "severity": "medium", "reason": "Categorisation confidence is below local review threshold."})
    if not entry.get("receipt_id"):
        signals.append({"type": "missing_local_receipt_link", "severity": "low", "reason": "Ledger row has no local receipt link."})
    payroll_terms = ("payroll", "wage", "wages", "salary", "super", "employee")
    if any(term in description.lower() for term in payroll_terms):
        signals.append({"type": "payroll_record_review", "severity": "medium", "reason": "Payroll-related row should be checked against pay run and pay-slip records."})
    if "refund" in description.lower() or "reversal" in description.lower() or "adjustment" in description.lower():
        signals.append({"type": "refund_reversal_adjustment", "severity": "medium", "reason": "Refund, reversal or adjustment wording needs source trail review."})
    return signals


def forensic_accounting_health() -> dict[str, Any]:
    state = load_state()
    cases = state["products"]["ledger"].get("forensic_cases", [])
    open_cases = [case for case in cases if case.get("status") != "closed"]
    return {
        "product": "Ledger Forensic Accounting",
        "status": "DONE_LOCAL_INTERNAL_LEDGER_FORENSICS_ONLY",
        "mode": "local_internal_review_signals_only",
        "route": "/finance/ledger/forensics",
        "health_route": "/finance/api/ledger/forensics/health",
        "counts": {
            "cases": len(cases),
            "open_cases": len(open_cases),
            "high_severity": len([case for case in cases if case.get("severity") == "high"]),
            "ledger_entries_available": len(state["products"]["ledger"].get("entries", [])),
            "receipts": len(forensic_receipts()),
        },
        "screens": [
            "Forensic dashboard",
            "Exception triage",
            "Duplicate and split pattern review",
            "Payroll/pay-slip consistency review",
            "Source-document checklist",
            "Case register",
            "Evidence trail",
            "Receipts",
        ],
        "functions": [
            "Scan local Ledger rows for review signals.",
            "Group signals into local cases with severity and recommended checks.",
            "Link cases to source rows and receipts.",
            "Create local forensic review receipts.",
            "Keep language to review signals, not fraud accusations or legal conclusions.",
        ],
        "right_rail": {
            **right_rail("ledger"),
            "what": "Forensic Accounting helps find local ledger rows that deserve source-document review.",
            "how": "It scans duplicates, large round values, low-confidence categories, missing receipts, payroll rows, reversals and same-day repeated amounts.",
            "risk_if_wrong": "Could overstate concern if treated as proof of fraud; every signal requires human review.",
            "write_boundary": "No accusation, legal conclusion, accounting-system mutation, payroll action or external report filing.",
            "receipt_link": "/finance/api/ledger/forensics/receipts",
        },
        "failure_states": failure_states("ledger")
        + [
            {"state": "no_forensic_cases", "message": "No cases yet; run a local forensic scan."},
            {"state": "signal_not_finding", "message": "A signal is a review prompt, not a fraud finding or legal conclusion."},
            {"state": "source_document_missing", "message": "Rows without receipts are marked for source-document follow-up."},
        ],
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def scan_forensic_accounting() -> dict[str, Any]:
    state = load_state()
    entries = state["products"]["ledger"].get("entries", [])
    duplicate_keys: dict[tuple[str, float], int] = {}
    same_day_amounts: dict[tuple[str, float], int] = {}
    for entry in entries:
        amount = abs(float(entry.get("amount") or 0))
        desc_key = str(entry.get("description") or "").strip().lower()
        date_key = str(entry.get("date") or "")
        duplicate_keys[(desc_key, amount)] = duplicate_keys.get((desc_key, amount), 0) + 1
        same_day_amounts[(date_key, amount)] = same_day_amounts.get((date_key, amount), 0) + 1

    cases = []
    for entry in entries:
        signals = _forensic_signal_for_entry(entry, duplicate_keys, same_day_amounts)
        if not signals:
            continue
        severity_rank = {"low": 1, "medium": 2, "high": 3}
        severity = max((signal["severity"] for signal in signals), key=lambda item: severity_rank[item])
        cases.append({
            "case_id": f"forensic-case-{uuid4().hex[:10]}",
            "entry_id": entry.get("id"),
            "description": entry.get("description"),
            "amount": entry.get("amount"),
            "date": entry.get("date"),
            "severity": severity,
            "signals": signals,
            "status": "open_review_signal",
            "recommended_checks": [
                "Open the source document or destination-owned accounting receipt.",
                "Confirm supplier/employee/contact, amount, date, category and approval trail.",
                "Compare against payroll/pay-slip records when payroll terms are present.",
                "Record the human conclusion as a local receipt before relying on this case.",
            ],
            "not_a_finding": True,
            "external_write": False,
            "created_at": _now(),
            "boundary": COMPLIANCE_BOUNDARY,
        })

    state["products"]["ledger"]["forensic_cases"] = cases
    save_state(state)
    receipt = create_product_receipt(
        "ledger",
        "forensic_accounting_scan",
        f"Scanned Ledger rows and created {len(cases)} local forensic review cases.",
        ["finance-ledger-entries", "forensic-review-signals"],
        {"case_count": len(cases), "entry_count": len(entries)},
    )
    return {
        "status": "local_forensic_scan_complete",
        "case_count": len(cases),
        "cases": cases,
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "not_a_fraud_finding": True,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def forensic_cases() -> list[dict[str, Any]]:
    return load_state()["products"]["ledger"].get("forensic_cases", [])


def forensic_receipts() -> list[dict[str, Any]]:
    return [
        receipt
        for receipt in load_state()["products"]["ledger"].get("receipts", [])
        if "forensic" in receipt.get("kind", "")
    ]


def strategist_generate(inputs: dict[str, Any] | None = None) -> dict[str, Any]:
    state = load_state()
    entries = state["products"]["ledger"].get("entries", [])
    revenue = sum(float(entry.get("amount") or 0) for entry in entries if float(entry.get("amount") or 0) > 0)
    costs = abs(sum(float(entry.get("amount") or 0) for entry in entries if float(entry.get("amount") or 0) < 0))
    monthly_revenue = float((inputs or {}).get("monthly_revenue") or max(revenue, 1))
    monthly_costs = float((inputs or {}).get("monthly_costs") or max(costs, 1))
    cash_on_hand = float((inputs or {}).get("cash_on_hand") or 32000)
    price_change_percent = float((inputs or {}).get("price_change_percent") or 0)
    scenario = scenario_run(monthly_revenue, monthly_costs, cash_on_hand, price_change_percent)
    scenario.update(
        {
            "product": "strategist",
            "assumptions": [
                "Local fixture/upload rows are used as the starting signal.",
                "Cash on hand is an input assumption, not a bank balance.",
                "Scenario is draft decision support, not investment, tax, legal or accounting advice.",
            ],
            "risks": [
                "Collection timing may differ from the local rows.",
                "Pricing change may affect conversion or churn.",
                "Tax, payroll and accounting effects are not modelled.",
            ],
            "action_draft": [
                "Validate largest inflow and outflow rows.",
                "Run a conservative collection-delay scenario.",
                "Create a local report pack for human review.",
            ],
            "blocked_advice": ["investment_advice", "tax_advice", "legal_advice", "bas_lodgement"],
        }
    )
    state = load_state()
    state["products"]["strategist"]["scenarios"].insert(0, scenario)
    save_state(state)
    receipt = create_product_receipt("strategist", "scenario_generation", "Generated local Fin Strategist what-if scenario.", ["finance-strategist-local-data"], {"scenario_id": scenario["id"]})
    scenario["receipt_id"] = receipt["id"]
    return scenario


def strategist_scenarios() -> dict[str, Any]:
    state = load_state()
    return {
        "scenarios": state["products"]["strategist"].get("scenarios", []),
        "boundary": COMPLIANCE_BOUNDARY,
        "empty_state": "No scenarios yet. Generate a local scenario from fixture/upload rows.",
    }


def _report_receipts(state: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        receipt
        for receipt in state.get("receipts", [])
        if "report" in receipt.get("kind", "") or receipt.get("product") == "reports"
    ]


def reports_health() -> dict[str, Any]:
    state = load_state()
    return {
        "product": "Finance Reports",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_REPORTS_ONLY",
        "mode": "local_internal_only",
        "route": "/finance/reports",
        "health_route": "/finance/api/reports/health",
        "counts": {
            "reports": len(state.get("reports", [])),
            "genie_answers": len(state["products"]["genie"].get("answers", [])),
            "ledger_entries": len(state["products"]["ledger"].get("entries", [])),
            "ledger_exceptions": len(ledger_exceptions(state["products"]["ledger"].get("entries", []))),
            "ledger_forensic_cases": len(state["products"]["ledger"].get("forensic_cases", [])),
            "strategist_scenarios": len(state["products"]["strategist"].get("scenarios", [])),
            "risk_candidates": len(_risk_state(state).get("candidates", [])),
            "risk_register": len(_risk_state(state).get("risks", [])),
            "blocked_actions": sum(len(state["products"][product].get("last_blocked", [])) for product in PRODUCTS),
            "receipts": len(_report_receipts(state)),
        },
        "right_rail": {
            **right_rail("ledger"),
            "what": "Finance Reports creates local draft packs across Genie, The Ledger, Fin Strategist and Risk Intelligence.",
            "receipt_link": "/finance/api/reports/receipts",
            "write_boundary": "External export, publish, send and filing are blocked unless Mani approves a destination workflow.",
        },
        "failure_states": failure_states("ledger")
        + [
            {"state": "no_reports", "message": "No local draft reports yet. Generate a local report pack first."},
            {"state": "external_export_gated", "message": "External export/publish is blocked_approval_required with a local receipt."},
        ],
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def generate_finance_report(report_type: str = "full_local_finance_pack") -> dict[str, Any]:
    state = load_state()
    genie_answers = state["products"]["genie"].get("answers", [])
    ledger_rows = state["products"]["ledger"].get("entries", [])
    strategist_rows = state["products"]["strategist"].get("scenarios", [])
    risk_state = _risk_state(state)
    risk_rows = risk_state.get("risks", [])
    risk_candidates_rows = risk_state.get("candidates", [])
    exceptions = ledger_exceptions(ledger_rows)
    forensic_rows = state["products"]["ledger"].get("forensic_cases", [])
    report = {
        "id": f"finance-report-{uuid4().hex[:10]}",
        "product": "reports",
        "report_type": report_type,
        "title": "AMTL Finance Suite local/internal draft report pack",
        "sections": {
            "genie_question_answer_report": genie_answers[:5],
            "ledger_entries_exceptions_report": {"entries": ledger_rows, "exceptions": exceptions},
            "ledger_forensic_accounting_report": {
                "cases": forensic_rows[:20],
                "language_boundary": "Forensic cases are local review signals only, not fraud findings or legal/accounting conclusions.",
            },
            "fin_strategist_scenario_report": strategist_rows[:5],
            "risk_intelligence_report": {
                "approved_risks": risk_rows[:10],
                "draft_candidates": risk_candidates_rows[:10],
                "source_strategy": "approved local/RAG source index plus deterministic local scan; provider/external vector calls remain blocked",
            },
            "blocked_actions_report": {
                product: state["products"][product].get("last_blocked", [])
                for product in PRODUCTS
            },
        },
        "counts": {
            "genie_answers": len(genie_answers),
            "ledger_entries": len(ledger_rows),
            "ledger_exceptions": len(exceptions),
            "ledger_forensic_cases": len(forensic_rows),
            "strategist_scenarios": len(strategist_rows),
            "risk_candidates": len(risk_candidates_rows),
            "risk_register": len(risk_rows),
        },
        "external_export_state": "blocked_approval_required",
        "external_write": False,
        "provider_called": False,
        "boundary": COMPLIANCE_BOUNDARY,
        "created_at": _now(),
    }
    state["reports"].insert(0, report)
    save_state(state)
    receipt = create_receipt(
        "finance_reports_generate",
        "Generated local/internal Finance Suite draft report pack.",
        ["finance-reports-local-state"],
        {"report_id": report["id"], "report_type": report_type},
    )
    report["receipt_id"] = receipt["id"]
    return report


def reports_receipts() -> list[dict[str, Any]]:
    return _report_receipts(load_state())


def blocked_external_export(surface: str = "reports") -> dict[str, Any]:
    receipt = create_receipt(
        f"{surface}_external_export_blocked",
        f"{surface} external export/publish blocked by local/internal approval gate.",
        [f"finance-{surface}-boundary"],
        {"surface": surface, "action": "external_export_publish", "reason": "No approved destination, publish target, accounting/tax workflow, or external send approval."},
    )
    return {
        "surface": surface,
        "action": "external_export_publish",
        "state": "blocked_approval_required",
        "reason": "No approved destination, publish target, accounting/tax workflow, or external send approval.",
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def evidence_events() -> list[dict[str, Any]]:
    state = load_state()
    events: list[dict[str, Any]] = []
    for answer in state["products"]["genie"].get("answers", []):
        events.append({"id": answer.get("receipt_id") or answer.get("question", "genie-answer"), "type": "question_answer", "product": "genie", "summary": answer.get("answer_draft", ""), "receipt_id": answer.get("receipt_id"), "created_at": answer.get("created_at"), "source": "genie.answers"})
    for import_record in state["products"]["ledger"].get("imports", []):
        events.append({"id": import_record.get("id"), "type": "import", "product": "ledger", "summary": import_record.get("filename", ""), "created_at": import_record.get("created_at"), "source": "ledger.imports"})
    for entry in state["products"]["ledger"].get("entries", []):
        events.append({"id": entry.get("id"), "type": "entry", "product": "ledger", "summary": entry.get("description", ""), "receipt_id": entry.get("receipt_id"), "created_at": None, "source": "ledger.entries", "amount": entry.get("amount"), "confidence": entry.get("confidence")})
    for exception in ledger_exceptions(state["products"]["ledger"].get("entries", [])):
        events.append({"id": exception.get("entry_id"), "type": "exception", "product": "ledger", "summary": exception.get("reason", ""), "created_at": None, "source": "ledger.exceptions"})
    for case in state["products"]["ledger"].get("forensic_cases", []):
        events.append({"id": case.get("case_id"), "type": "forensic_case", "product": "ledger", "summary": case.get("description", ""), "created_at": case.get("created_at"), "source": "ledger.forensic_cases", "severity": case.get("severity"), "not_a_finding": case.get("not_a_finding")})
    for scenario in state["products"]["strategist"].get("scenarios", []):
        events.append({"id": scenario.get("id"), "type": "scenario", "product": "strategist", "summary": scenario.get("outputs", {}).get("risk", ""), "receipt_id": scenario.get("receipt_id"), "created_at": scenario.get("created_at"), "source": "strategist.scenarios"})
    risk_state = _risk_state(state)
    for candidate in risk_state.get("candidates", []):
        events.append({"id": candidate.get("candidate_id"), "type": "risk_candidate", "product": "risk_intelligence", "summary": candidate.get("suggested_subcategory", ""), "created_at": candidate.get("created_at"), "source": "risk.candidates", "confidence": candidate.get("confidence")})
    for risk in risk_state.get("risks", []):
        events.append({"id": risk.get("risk_id"), "type": "risk_register", "product": "risk_intelligence", "summary": risk.get("title", ""), "receipt_id": risk.get("receipt_link"), "created_at": risk.get("created_at"), "source": "risk.register", "confidence": risk.get("confidence"), "severity": risk.get("severity")})
    for override in risk_state.get("overrides", []):
        events.append({"id": f"{override.get('risk_id')}-{override.get('field')}-{override.get('created_at')}", "type": "risk_override", "product": "risk_intelligence", "summary": override.get("reason", ""), "created_at": override.get("created_at"), "source": "risk.overrides"})
    for session in state.get("browser_assist", []):
        events.append({"id": session.get("id"), "type": "browser_assist", "product": "browser_assist", "summary": session.get("task", ""), "receipt_id": session.get("receipt_id"), "created_at": session.get("created_at"), "source": "browser_assist.sessions"})
    for artifact in state.get("browser_assist_artifacts", []):
        events.append({"id": artifact.get("id"), "type": "browser_assist_artifact", "product": "browser_assist", "summary": artifact.get("task", ""), "receipt_id": artifact.get("receipt_id"), "created_at": artifact.get("created_at"), "source": "browser_assist.artifacts", "session_id": artifact.get("session_id")})
    for destination_receipt in state.get("destination_receipts", []):
        events.append({"id": destination_receipt.get("id"), "type": "destination_owned_receipt", "product": "browser_assist", "summary": destination_receipt.get("human_summary", ""), "receipt_id": destination_receipt.get("receipt_id"), "created_at": destination_receipt.get("created_at"), "source": "browser_assist.destination_receipts", "platform": destination_receipt.get("platform"), "destination_receipt_id": destination_receipt.get("destination_receipt_id")})
    for packet in state.get("cross_app_outbox", []):
        events.append({"id": packet.get("id"), "type": "cross_app_packet", "product": "cross_app", "summary": packet.get("summary", ""), "created_at": packet.get("created_at"), "source": "cross_app.outbox", "destination_id": packet.get("destination_id"), "delivery_state": packet.get("delivery_state")})
    for destination_receipt in state.get("cross_app_destination_receipts", []):
        events.append({"id": destination_receipt.get("id"), "type": "cross_app_destination_receipt", "product": "cross_app", "summary": destination_receipt.get("human_summary", ""), "receipt_id": destination_receipt.get("receipt_id"), "created_at": destination_receipt.get("created_at"), "source": "cross_app.destination_receipts", "destination_id": destination_receipt.get("destination_id"), "destination_receipt_id": destination_receipt.get("destination_receipt_id")})
    for product in PRODUCTS:
        for blocked in state["products"][product].get("last_blocked", []):
            events.append({"id": blocked.get("receipt_id"), "type": "blocked_action", "product": product, "summary": blocked.get("action", ""), "receipt_id": blocked.get("receipt_id"), "created_at": blocked.get("created_at"), "source": f"{product}.blocked"})
        events.append({"id": f"{product}-synthetic-status", "type": "synthetic_control", "product": product, "summary": json.dumps(product_demo_data_status(product), sort_keys=True), "created_at": state["products"][product].get("synthetic_removed_at"), "source": f"{product}.synthetic"})
    for receipt in state.get("receipts", []):
        events.append({"id": receipt.get("id"), "type": "receipt", "product": receipt.get("product", "suite"), "summary": receipt.get("summary", ""), "receipt_id": receipt.get("id"), "created_at": receipt.get("created_at"), "source": "receipts"})
    return events


def evidence_health() -> dict[str, Any]:
    events = evidence_events()
    return {
        "product": "Finance Evidence Centre",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_EVIDENCE_ONLY",
        "mode": "local_internal_only",
        "route": "/finance/evidence",
        "health_route": "/finance/api/evidence/health",
        "counts": {
            "events": len(events),
            "questions": len([event for event in events if event["type"] == "question_answer"]),
            "imports": len([event for event in events if event["type"] == "import"]),
            "entries": len([event for event in events if event["type"] == "entry"]),
            "exceptions": len([event for event in events if event["type"] == "exception"]),
            "forensic_cases": len([event for event in events if event["type"] == "forensic_case"]),
            "scenarios": len([event for event in events if event["type"] == "scenario"]),
            "risk_candidates": len([event for event in events if event["type"] == "risk_candidate"]),
            "risk_register": len([event for event in events if event["type"] == "risk_register"]),
            "risk_overrides": len([event for event in events if event["type"] == "risk_override"]),
            "browser_assist": len([event for event in events if event["type"] == "browser_assist"]),
            "browser_assist_artifacts": len([event for event in events if event["type"] == "browser_assist_artifact"]),
            "destination_owned_receipts": len([event for event in events if event["type"] == "destination_owned_receipt"]),
            "receipts": len([event for event in events if event["type"] == "receipt"]),
            "blocked_actions": len([event for event in events if event["type"] == "blocked_action"]),
            "synthetic_controls": len([event for event in events if event["type"] == "synthetic_control"]),
        },
        "right_rail": {
            **right_rail("genie"),
            "what": "Finance Evidence Centre lists local events across Genie, Ledger, Fin Strategist, Risk Intelligence, Browser Assist, reports and admin proof.",
            "receipt_link": "/finance/api/evidence/receipts",
        },
        "failure_states": failure_states("genie") + [{"state": "no_evidence_events", "message": "No evidence events yet is shown as an empty local state."}],
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def filter_evidence(product: str | None = None, event_type: str | None = None, query: str | None = None) -> dict[str, Any]:
    events = evidence_events()
    if product:
        events = [event for event in events if event.get("product") == product]
    if event_type:
        events = [event for event in events if event.get("type") == event_type]
    if query:
        query_lower = query.lower()
        events = [event for event in events if query_lower in json.dumps(event, sort_keys=True).lower()]
    receipt = create_receipt(
        "finance_evidence_filter",
        "Filtered local Finance Evidence Centre events.",
        ["finance-evidence-events"],
        {"product": product, "event_type": event_type, "query": query, "result_count": len(events)},
    )
    return {"events": events, "count": len(events), "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def cross_app_destinations() -> dict[str, Any]:
    return {
        "destinations": CROSS_APP_DESTINATIONS,
        "default_dispatch_mode": "local_outbox_only",
        "automation_state": "automatic_local_packet_generation_enabled",
        "destination_write_state": "blocked_destination_receipt_missing_until_destination_owned_receipt_exists",
        "boundary": COMPLIANCE_BOUNDARY,
    }


def _cross_app_source_metrics(state: dict[str, Any]) -> dict[str, Any]:
    entries = state["products"]["ledger"].get("entries", [])
    receivables = round(sum(float(row.get("amount") or 0) for row in entries if float(row.get("amount") or 0) > 0), 2)
    payables = round(abs(sum(float(row.get("amount") or 0) for row in entries if float(row.get("amount") or 0) < 0)), 2)
    runway = state["products"]["runway"]
    runway_costs = round(
        sum(float(row.get("monthly_cost") or 0) for row in runway.get("subscriptions", []))
        + sum(float(row.get("monthly_spend") or 0) for row in runway.get("vendors", []))
        + sum(float(row.get("monthly_cost") or 0) for row in runway.get("ai_costs", [])),
        2,
    )
    risks = _risk_state(state).get("risks", [])
    return {
        "receivables": receivables,
        "payables": payables,
        "runway_monthly_costs_under_review": runway_costs,
        "risk_count": len(risks),
        "risk_owner_missing": len([risk for risk in risks if str(risk.get("owner") or "").lower() in {"", "unassigned", "none"}]),
        "browser_assist_artifacts": len(state.get("browser_assist_artifacts", [])),
        "reports": len(state.get("reports", [])),
        "receipts": len(state.get("receipts", [])),
    }


def _cross_app_packet(destination_id: str, signal_type: str, summary: str, urgency: str, source_refs: list[str], payload: dict[str, Any]) -> dict[str, Any]:
    destination = CROSS_APP_DESTINATIONS[destination_id]
    return {
        "id": f"finance-xapp-{uuid4().hex[:10]}",
        "source_app": "AMTL Finance Suite",
        "destination_app": destination["name"],
        "destination_id": destination_id,
        "signal_type": signal_type,
        "summary": summary,
        "urgency": urgency,
        "confidence": payload.get("confidence", "medium"),
        "source_refs": source_refs,
        "payload": payload,
        "suggested_next_action": payload.get("suggested_next_action", "Review the source evidence and decide whether a human-owned follow-up is needed."),
        "blocked_actions": ["destination_write", "external_send", "customer_message_send", "provider_call", "accounting_mutation"],
        "dispatch_mode": "local_outbox_only",
        "automation_state": "automatic_local_packet_created",
        "delivery_state": "blocked_destination_receipt_missing",
        "requires_human_review": True,
        "destination_receipt_required_for_write": True,
        "external_write": False,
        "provider_called": False,
        "created_at": _now(),
        "boundary": COMPLIANCE_BOUNDARY,
    }


def generate_cross_app_packets(destinations: list[str] | None = None) -> list[dict[str, Any]]:
    state = load_state()
    metrics = _cross_app_source_metrics(state)
    wanted = set(destinations or CROSS_APP_DESTINATIONS.keys())
    unknown = sorted(wanted - set(CROSS_APP_DESTINATIONS))
    if unknown:
        raise ValueError(f"Unknown cross-app destination(s): {', '.join(unknown)}")
    rules = {
        "elaine": ("runway_watch", "Finance Suite has a runway/cashflow watch packet ready for Mani review.", "medium", ["finance-runway", "finance-evidence"], "Ask Mani whether to review subscriptions, vendors, pricing or receivables first."),
        "baldrick": ("runtime_health", "Finance Suite runtime and evidence status are ready for local supervisor visibility.", "low", ["finance-runtime", "finance-route-proof"], "Monitor health route and fallback state; do not mutate gateway or public route."),
        "costanza": ("payment_risk", "Finance Suite has customer/payment follow-up context for careful human review.", "medium", ["finance-ledger", "finance-receivables"], "Draft a polite customer follow-up only after human review."),
        "ripple": ("revenue_concentration", "Finance Suite has revenue/cash timing signals that may affect pipeline truth.", "medium", ["finance-ledger", "finance-strategist"], "Review whether customer concentration or payment timing affects forecast confidence."),
        "spark": ("roi_watch", "Finance Suite has cost/ROI signals that can inform offer or campaign review.", "medium", ["finance-runway", "finance-reports"], "Review quality-safe savings before changing campaigns or reducing quality."),
        "workshop": ("route_health", "Finance Suite route/module status is ready for launcher visibility.", "low", ["finance-health", "finance-runtime-registry"], "Show route and health state only; do not restart Workshop unless approved."),
        "beast": ("port_truth", "Finance Suite port/PID/health truth is ready for local runtime proof.", "low", ["finance-health", "finance-runtime-registry"], "Use local registry proof; do not mutate gateway or public routing."),
        "chronicle": ("evidence_memory", "Finance Suite evidence events are ready for memory capture.", "low", ["finance-evidence", "finance-receipts"], "Create memory only if Chronicle returns a destination-owned receipt."),
        "ck_writer": ("report_brief", "Finance Suite can provide a source-backed writing brief for internal reports.", "low", ["finance-reports", "finance-evidence"], "Draft internal explanation; do not publish or send."),
        "digital_sentinel": ("vendor_dependency", "Finance Suite has vendor/dependency review signals for security/compliance context.", "medium", ["finance-runway", "finance-ledger"], "Review vendor dependency and compliance risk locally; do not run external scans."),
        "concierge": ("human_review_task", "Finance Suite has human-review tasks and missing destination receipt context.", "medium", ["finance-evidence", "finance-browser-assist"], "Create a human review task draft; do not create a ticket unless Concierge owns the receipt."),
        "pre_sales": ("pricing_assumption", "Finance Suite has pricing, margin and payment-term assumptions for proposal review.", "medium", ["finance-strategist", "finance-runway"], "Use as proposal assumption context with clear caveats."),
    }
    packets: list[dict[str, Any]] = []
    for destination_id, (signal_type, summary, urgency, refs, next_action) in rules.items():
        if destination_id in wanted:
            packets.append(
                _cross_app_packet(
                    destination_id,
                    signal_type,
                    summary,
                    urgency,
                    refs,
                    {"metrics": metrics, "confidence": "medium", "suggested_next_action": next_action},
                )
            )
    return packets


def dispatch_cross_app_packets(destinations: list[str] | None = None, reason: str = "automatic local cross-app dispatch") -> dict[str, Any]:
    state = load_state()
    packets = generate_cross_app_packets(destinations)
    state.setdefault("cross_app_outbox", [])
    existing_by_signature = {
        (packet.get("destination_id"), packet.get("signal_type"), packet.get("summary")): packet
        for packet in state.get("cross_app_outbox", [])
    }
    stored: list[dict[str, Any]] = []
    for packet in packets:
        signature = (packet["destination_id"], packet["signal_type"], packet["summary"])
        previous = existing_by_signature.get(signature)
        if previous:
            previous["last_refreshed_at"] = _now()
            previous["refresh_count"] = int(previous.get("refresh_count") or 0) + 1
            stored.append(previous)
        else:
            state["cross_app_outbox"].insert(0, packet)
            stored.append(packet)
    save_state(state)
    receipt = create_receipt(
        "cross_app_local_dispatch",
        f"Created/refreshed {len(stored)} local cross-app handoff packets.",
        ["finance-cross-app-outbox"],
        {
            "reason": reason,
            "destination_ids": [packet["destination_id"] for packet in stored],
            "external_write": False,
            "provider_called": False,
            "delivery_state": "local_outbox_only",
        },
    )
    return {
        "status": "DONE_LOCAL_INTERNAL_CROSS_APP_OUTBOX_DISPATCH_ONLY",
        "dispatch_mode": "local_outbox_only",
        "packets": stored,
        "packet_count": len(stored),
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "destination_delivery_state": "blocked_destination_receipt_missing",
        "boundary": COMPLIANCE_BOUNDARY,
    }


def cross_app_outbox(destination_id: str | None = None, signal_type: str | None = None) -> dict[str, Any]:
    packets = list(load_state().get("cross_app_outbox", []))
    if destination_id:
        packets = [packet for packet in packets if packet.get("destination_id") == destination_id]
    if signal_type:
        packets = [packet for packet in packets if packet.get("signal_type") == signal_type]
    return {
        "packets": packets,
        "packet_count": len(packets),
        "dispatch_mode": "local_outbox_only",
        "destination_delivery_state": "blocked_destination_receipt_missing_without_destination_owned_receipt",
        "boundary": COMPLIANCE_BOUNDARY,
    }


def record_cross_app_destination_receipt(destination_id: str, packet_id: str, destination_receipt_id: str, human_summary: str) -> dict[str, Any]:
    if destination_id not in CROSS_APP_DESTINATIONS:
        raise ValueError("Unknown cross-app destination.")
    if not destination_receipt_id.strip():
        raise ValueError("destination_receipt_id is required.")
    state = load_state()
    packet = next((row for row in state.get("cross_app_outbox", []) if row.get("id") == packet_id), None)
    if not packet:
        raise ValueError("Unknown cross-app packet_id.")
    record = {
        "id": f"finance-xapp-dest-{uuid4().hex[:10]}",
        "destination_id": destination_id,
        "destination_app": CROSS_APP_DESTINATIONS[destination_id]["name"],
        "packet_id": packet_id,
        "destination_receipt_id": destination_receipt_id.strip(),
        "human_summary": human_summary.strip() or "Destination-owned receipt recorded by human operator.",
        "finance_suite_external_write": False,
        "finance_suite_provider_called": False,
        "status": "destination_owned_receipt_recorded",
        "created_at": _now(),
        "boundary": COMPLIANCE_BOUNDARY,
    }
    packet["delivery_state"] = "destination_owned_receipt_recorded"
    packet["destination_receipt_id"] = record["destination_receipt_id"]
    packet["destination_receipt_recorded_at"] = record["created_at"]
    state.setdefault("cross_app_destination_receipts", []).insert(0, record)
    save_state(state)
    receipt = create_receipt(
        "cross_app_destination_owned_receipt",
        f"Recorded destination-owned cross-app receipt for {CROSS_APP_DESTINATIONS[destination_id]['name']}.",
        ["finance-cross-app-outbox", packet_id],
        record,
    )
    record["receipt_id"] = receipt["id"]
    return record


def cross_app_destination_receipts() -> list[dict[str, Any]]:
    return load_state().get("cross_app_destination_receipts", [])


def cross_app_health() -> dict[str, Any]:
    state = load_state()
    outbox = state.get("cross_app_outbox", [])
    destination_receipts_rows = state.get("cross_app_destination_receipts", [])
    return {
        "product": "Finance Suite App Handoffs",
        "status": "DONE_LOCAL_INTERNAL_CROSS_APP_COMMUNICATIONS_ONLY",
        "mode": "automatic_local_outbox_no_destination_write",
        "route": "/finance/cross-app",
        "health_route": "/finance/api/cross-app/health",
        "automation": {
            "packet_generation": "automatic",
            "dispatch": "local_outbox_only",
            "destination_write": "blocked_destination_receipt_missing",
            "provider_called": False,
            "external_write": False,
        },
        "counts": {
            "destinations": len(CROSS_APP_DESTINATIONS),
            "outbox_packets": len(outbox),
            "destination_owned_receipts": len(destination_receipts_rows),
            "blocked_without_destination_receipt": len([packet for packet in outbox if packet.get("delivery_state") != "destination_owned_receipt_recorded"]),
        },
        "destinations": CROSS_APP_DESTINATIONS,
        "failure_states": [
            {"state": "destination_app_unavailable", "message": "Packet remains in Finance Suite local outbox."},
            {"state": "destination_receipt_missing", "message": "No cross-app write or success is claimed until a destination-owned receipt is recorded."},
            {"state": "external_write_blocked", "message": "Finance Suite does not push into other apps, CRMs, accounting software or public services in this local/internal mode."},
            {"state": "provider_call_blocked", "message": "No provider/model/vector call is required for cross-app packet generation."},
        ],
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def evidence_receipts() -> list[dict[str, Any]]:
    state = load_state()
    return [
        receipt
        for receipt in state.get("receipts", [])
        if "evidence" in receipt.get("kind", "") or receipt.get("kind", "").endswith("_blocked")
    ]


def admin_health() -> dict[str, Any]:
    return {
        "product": "Finance Admin / Proof",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_ADMIN_ONLY",
        "mode": "local_internal_only",
        "route": "/finance/admin",
        "health_route": "/finance/api/admin/health",
        "status_route": "/finance/api/admin/status",
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def admin_status(create_status_receipt: bool = True) -> dict[str, Any]:
    state = load_state()
    status = {
        "product": "Finance Admin / Proof",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_ADMIN_ONLY",
        "mode": "local_internal_only",
        "runtime_pid": os.getpid(),
        "persistence_path": str(STATE_PATH),
        "synthetic_data_status": {
            **{product: product_demo_data_status(product) for product in PRODUCTS},
            "risk_intelligence": risk_demo_data_status(),
        },
        "product_statuses": {
            **{product: product_health(product)["status"] for product in PRODUCTS},
            "risk_intelligence": risk_health()["status"],
            "reports": reports_health()["status"],
            "evidence": evidence_health()["status"],
            "browser_assist": browser_assist_health()["status"],
        },
        "provider_gated": "blocked_approval_required",
        "bank_api_gated": "blocked_approval_required",
        "accounting_write_gated": "blocked_approval_required",
        "bas_gst_tax_lodgement_gated": "blocked_approval_required",
        "payroll_payment_mutation_gated": "blocked_approval_required",
        "beast_gateway_state": "approved_local_gateway_route_pending_proof_or_proven_by_registry; Beast live sentinel may remain fallback if unavailable",
        "workshop_consumption_truth": "Workshop registry and hard-coded launcher are approved for local refresh/restart proof; external/public routing remains out of scope.",
        "caveats": [COMPLIANCE_BOUNDARY, "Local/internal only; no production finance readiness claim."],
        "counts": {
            "receipts": len(state.get("receipts", [])),
            "reports": len(state.get("reports", [])),
            "evidence_events": len(evidence_events()),
            "risk_candidates": len(_risk_state(state).get("candidates", [])),
            "risk_register": len(_risk_state(state).get("risks", [])),
            "ledger_forensic_cases": len(state["products"]["ledger"].get("forensic_cases", [])),
            "browser_assist_sessions": len(state.get("browser_assist", [])),
            "browser_assist_artifacts": len(state.get("browser_assist_artifacts", [])),
            "destination_owned_receipts": len(state.get("destination_receipts", [])),
        },
    }
    if create_status_receipt:
        receipt = create_receipt("finance_admin_status_view", "Viewed Finance Admin / Proof local status.", ["finance-admin-status"], {"runtime_pid": status["runtime_pid"]})
        status["receipt_id"] = receipt["id"]
    return status


def admin_receipts() -> list[dict[str, Any]]:
    return [receipt for receipt in load_state().get("receipts", []) if "admin" in receipt.get("kind", "")]


ACCOUNTING_BROWSER_PLATFORMS = {
    "quickbooks": "QuickBooks",
    "myob": "MYOB",
    "xero": "Xero",
}

BROWSER_ASSIST_TASKS = {
    "invoice_draft": "Draft invoice fields from local Ledger rows.",
    "bill_draft": "Draft supplier bill fields from local Ledger rows.",
    "journal_draft": "Draft journal-entry notes for human review.",
    "reconcile_review": "Prepare reconciliation review prompts and row checks.",
    "report_export_draft": "Prepare local report/export copy without publishing.",
    "pay_stub_draft": "Prepare pay-stub/pay-slip statement fields from payroll context for human review.",
}


def browser_assist_receipts() -> list[dict[str, Any]]:
    return [receipt for receipt in load_state().get("receipts", []) if "browser_assist" in receipt.get("kind", "") or "destination_owned" in receipt.get("kind", "")]


RISK_CATEGORY_GROUPS = {
    "Financial": [
        "cashflow risk",
        "runway risk",
        "margin risk",
        "pricing risk",
        "revenue concentration risk",
        "customer payment risk",
        "debt/financing risk",
        "investment/major-spend risk",
        "forecast confidence risk",
        "budget variance risk",
        "cost overrun risk",
        "working capital risk",
        "FX/currency risk",
        "interest rate risk",
    ],
    "Customer & Revenue": [
        "customer churn risk",
        "customer concentration risk",
        "low pipeline risk",
        "sales conversion risk",
        "contract renewal risk",
        "customer satisfaction risk",
        "support burden risk",
        "reputation risk",
        "account expansion risk",
        "failed onboarding risk",
    ],
    "Market & Strategy": [
        "market/seasonality risk",
        "competitive pressure risk",
        "positioning risk",
        "product-market fit risk",
        "demand shift risk",
        "channel dependency risk",
        "partnership risk",
        "geographic expansion risk",
        "strategic distraction risk",
        "business model risk",
    ],
    "Operations": [
        "operational capacity risk",
        "process failure risk",
        "delivery delay risk",
        "quality control risk",
        "inventory/stock risk",
        "fulfilment risk",
        "service continuity risk",
        "single point of failure risk",
        "manual workaround risk",
        "change management risk",
    ],
    "People & Culture": [
        "payroll/staffing risk",
        "key person risk",
        "hiring risk",
        "retention risk",
        "burnout risk",
        "skills gap risk",
        "leadership capacity risk",
        "succession risk",
        "contractor dependency risk",
        "culture/engagement risk",
    ],
    "Supplier & Vendor": [
        "supplier/vendor risk",
        "vendor lock-in risk",
        "price increase risk",
        "service degradation risk",
        "contract term risk",
        "vendor security risk",
        "supply chain disruption risk",
        "critical dependency risk",
        "outsourced delivery risk",
    ],
    "Technology": [
        "system outage risk",
        "cybersecurity risk",
        "data loss risk",
        "data quality risk",
        "integration failure risk",
        "technical debt risk",
        "scalability risk",
        "AI/model reliability risk",
        "automation failure risk",
        "access control risk",
        "backup/restore risk",
        "platform dependency risk",
    ],
    "Legal, Compliance & Governance": [
        "compliance boundary risk",
        "contract risk",
        "licensing/IP risk",
        "privacy risk",
        "data retention risk",
        "audit readiness risk",
        "policy breach risk",
        "regulatory change risk",
        "governance gap risk",
        "approval/control failure risk",
    ],
    "Product & Delivery": [
        "roadmap risk",
        "scope creep risk",
        "feature adoption risk",
        "usability risk",
        "accessibility risk",
        "release quality risk",
        "customer feedback miss risk",
        "documentation risk",
        "supportability risk",
        "maintenance burden risk",
    ],
    "Brand & Communications": [
        "brand trust risk",
        "messaging risk",
        "public perception risk",
        "crisis communication risk",
        "content quality risk",
        "misrepresentation risk",
        "community/customer backlash risk",
        "review/testimonial risk",
    ],
    "External Environment": [
        "economic risk",
        "political/regulatory risk",
        "weather/climate risk",
        "disaster/business interruption risk",
        "industry disruption risk",
        "public health risk",
        "infrastructure risk",
        "insurance risk",
    ],
}

RISK_SYNTHETIC_SOURCES = [
    {
        "id": "risk-source-synthetic-status-001",
        "source_type": "status_report",
        "source_system": "local_fixture",
        "title": "Synthetic delivery status signal",
        "text": "Delivery is blocked by missing approval, manual workaround and a single owner for final review.",
        "synthetic": True,
        "created_at": "2026-06-28T00:00:00+00:00",
    },
    {
        "id": "risk-source-synthetic-qa-001",
        "source_type": "qa_report",
        "source_system": "local_fixture",
        "title": "Synthetic QA reliability signal",
        "text": "Browser route was flaky, evidence was stale, and integration failure could affect release quality.",
        "synthetic": True,
        "created_at": "2026-06-28T00:00:00+00:00",
    },
]

RISK_SIGNAL_RULES = [
    ("dependency", "Operations", "critical dependency risk", "Dependency or single point of failure detected."),
    ("delay", "Product & Delivery", "delivery delay risk", "Delay wording detected in source material."),
    ("blocked", "Legal, Compliance & Governance", "approval/control failure risk", "Blocked or missing approval signal detected."),
    ("manual workaround", "Operations", "manual workaround risk", "Manual workaround detected."),
    ("single owner", "People & Culture", "key person risk", "Single owner/key person signal detected."),
    ("concentration", "Financial", "revenue concentration risk", "Concentration signal detected."),
    ("cash shortfall", "Financial", "cashflow risk", "Cash shortfall signal detected."),
    ("low confidence", "Technology", "data quality risk", "Low-confidence data signal detected."),
    ("stale", "Legal, Compliance & Governance", "audit readiness risk", "Stale evidence or stale review signal detected."),
    ("missing approval", "Legal, Compliance & Governance", "approval/control failure risk", "Missing approval signal detected."),
    ("fragile integration", "Technology", "integration failure risk", "Fragile integration signal detected."),
    ("cost spike", "Financial", "cost overrun risk", "Cost spike signal detected."),
    ("margin", "Financial", "margin risk", "Margin change signal detected."),
    ("payment delay", "Financial", "customer payment risk", "Payment delay signal detected."),
    ("exception", "Operations", "process failure risk", "Recurring exception signal detected."),
    ("weak assumption", "Financial", "forecast confidence risk", "Weak assumption signal detected."),
    ("ownerless", "People & Culture", "ownership gap risk", "Ownerless risk signal detected."),
]


def _default_risk_state() -> dict[str, Any]:
    return {
        "synthetic_data_present": True,
        "synthetic_removed_at": None,
        "source_records": list(RISK_SYNTHETIC_SOURCES),
        "candidates": [],
        "risks": [],
        "reviews": [],
        "merges": [],
        "archives": [],
        "overrides": [],
    }


def _risk_state(state: dict[str, Any] | None = None) -> dict[str, Any]:
    state = state or load_state()
    if "risk_intelligence" not in state:
        state["risk_intelligence"] = _default_risk_state()
        save_state(state)
    return state["risk_intelligence"]


def _field_value(value: Any, confidence: float, evidence: list[dict[str, Any]], user_value: Any | None = None) -> dict[str, Any]:
    return {
        "system_suggested_value": value,
        "user_confirmed_value": user_value,
        "current_displayed_value": user_value if user_value is not None else value,
        "confidence": confidence,
        "evidence_source": evidence,
        "freshness": _now(),
        "override_status": "user_override" if user_value is not None else "system_suggested",
        "override_reason": None,
        "locked_by_user": False,
        "last_reviewed_by": None,
        "last_reviewed_at": None,
    }


def _severity_from_signal(signal: str, confidence: float) -> str:
    if signal in {"cash shortfall", "blocked", "missing approval", "fragile integration", "payment delay"}:
        return "high" if confidence >= 0.72 else "medium"
    return "medium" if confidence >= 0.64 else "watch"


def _risk_source_records(state: dict[str, Any]) -> list[dict[str, Any]]:
    risk_state = _risk_state(state)
    records = list(risk_state.get("source_records", []))
    for entry in state["products"]["ledger"].get("entries", []):
        records.append(
            {
                "id": entry.get("id"),
                "source_type": "ledger_entry",
                "source_system": "ledger",
                "title": entry.get("description") or "Ledger entry",
                "text": f"{entry.get('description')} amount {entry.get('amount')} category {entry.get('category')} confidence {entry.get('confidence')}",
                "synthetic": bool(entry.get("synthetic")),
                "created_at": entry.get("date"),
                "payload": entry,
            }
        )
    for exception in ledger_exceptions(state["products"]["ledger"].get("entries", [])):
        records.append(
            {
                "id": f"exception-{exception.get('entry_id')}",
                "source_type": "ledger_exception",
                "source_system": "ledger",
                "title": exception.get("reason"),
                "text": f"Recurring exception {exception.get('reason')} on amount {exception.get('amount')} confidence {exception.get('confidence')}",
                "synthetic": False,
                "created_at": _now(),
                "payload": exception,
            }
        )
    for scenario in state["products"]["strategist"].get("scenarios", []):
        outputs = scenario.get("outputs", {})
        records.append(
            {
                "id": scenario.get("id"),
                "source_type": "scenario",
                "source_system": "strategist",
                "title": f"Scenario {scenario.get('id')}",
                "text": f"Runway {outputs.get('runway_months')} risk {outputs.get('risk')} weak assumption revenue costs collection timing price acceptance",
                "synthetic": False,
                "created_at": scenario.get("created_at"),
                "payload": scenario,
            }
        )
    for report in state.get("reports", [])[:20]:
        records.append(
            {
                "id": report.get("id"),
                "source_type": "report",
                "source_system": "reports",
                "title": report.get("title") or report.get("report_type"),
                "text": json.dumps(report, sort_keys=True)[:2000],
                "synthetic": False,
                "created_at": report.get("created_at"),
                "payload": {"report_id": report.get("id")},
            }
        )
    for receipt in state.get("receipts", [])[:50]:
        records.append(
            {
                "id": receipt.get("id"),
                "source_type": "receipt",
                "source_system": "evidence",
                "title": receipt.get("kind"),
                "text": receipt.get("summary", ""),
                "synthetic": False,
                "created_at": receipt.get("created_at"),
                "payload": {"receipt_id": receipt.get("id")},
            }
        )
    return records


def _normalised_source_path(path: Path) -> str:
    return str(path).replace("/", "\\").lower()


def _safe_risk_source_path(path: Path) -> bool:
    raw = _normalised_source_path(path)
    return not any(raw.startswith(prefix) for prefix in RISK_EXCLUDED_SOURCE_PREFIXES)


def _read_risk_source_file(path: Path) -> str:
    raw = path.read_bytes()[:RISK_SOURCE_INDEX_MAX_BYTES]
    return raw.decode("utf-8", "ignore").strip()


def _source_record_from_file(path: Path, source_system: str, synthetic: bool = False) -> dict[str, Any] | None:
    if not _safe_risk_source_path(path) or path.suffix.lower() not in RISK_INDEXABLE_EXTENSIONS:
        return None
    try:
        text = _read_risk_source_file(path)
    except OSError:
        return None
    if not text:
        return None
    digest = uuid4().hex[:8]
    return {
        "id": f"risk-source-index-{digest}",
        "source_type": "approved_source_index",
        "source_system": source_system,
        "title": path.name,
        "text": text[:5000],
        "synthetic": synthetic,
        "created_at": _now(),
        "payload": {
            "path": str(path),
            "extension": path.suffix.lower(),
            "bytes_indexed": min(len(text.encode("utf-8", "ignore")), RISK_SOURCE_INDEX_MAX_BYTES),
        },
    }


def _iter_risk_nas_files(max_files: int, max_seconds: float) -> tuple[list[Path], list[dict[str, Any]]]:
    started = time.monotonic()
    files: list[Path] = []
    issues: list[dict[str, Any]] = []
    stack = list(RISK_SOURCE_ROOTS)
    while stack and len(files) < max_files and time.monotonic() - started < max_seconds:
        current = stack.pop()
        if not _safe_risk_source_path(current):
            continue
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    path = Path(entry.path)
                    if not _safe_risk_source_path(path):
                        continue
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            stack.append(path)
                        elif entry.is_file(follow_symlinks=False) and path.suffix.lower() in RISK_INDEXABLE_EXTENSIONS:
                            files.append(path)
                            if len(files) >= max_files:
                                break
                    except OSError as exc:
                        issues.append({"path": str(path), "error": str(exc)})
        except OSError as exc:
            issues.append({"path": str(current), "error": str(exc)})
    return files, issues


def index_risk_sources(include_nas: bool = False, max_nas_files: int = 25, max_seconds: float = 8.0) -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    indexed: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for path in APPROVED_RISK_SOURCE_FILES:
        if not path.exists():
            skipped.append({"path": str(path), "reason": "missing"})
            continue
        record = _source_record_from_file(path, "approved_local_file")
        if record:
            indexed.append(record)
        else:
            skipped.append({"path": str(path), "reason": "not_indexable_or_empty"})
    nas_issues: list[dict[str, Any]] = []
    if include_nas:
        nas_files, nas_issues = _iter_risk_nas_files(max_files=max(0, max_nas_files), max_seconds=max_seconds)
        for path in nas_files:
            record = _source_record_from_file(path, "approved_nas_source")
            if record:
                indexed.append(record)
    existing = [
        record for record in risk_state.get("source_records", [])
        if record.get("source_type") != "approved_source_index"
    ]
    risk_state["source_records"] = indexed + existing
    risk_state["source_index"] = {
        "indexed_at": _now(),
        "approval": "mani_approved_local_rag_source_indexing",
        "include_nas": include_nas,
        "provider_called": False,
        "vector_store_used": False,
        "external_write": False,
        "excluded_prefixes": list(RISK_EXCLUDED_SOURCE_PREFIXES),
        "approved_local_files": [str(path) for path in APPROVED_RISK_SOURCE_FILES],
        "approved_nas_roots": [str(path) for path in RISK_SOURCE_ROOTS],
        "indexed_count": len(indexed),
        "skipped": skipped,
        "nas_issues": nas_issues[:20],
    }
    save_state(state)
    receipt = create_receipt(
        "risk_source_indexed",
        f"Indexed {len(indexed)} approved local/RAG source records for Risk Intelligence with exact excluded NAS prefixes.",
        ["finance-risk-source-index"],
        risk_state["source_index"],
    )
    return {
        "status": "DONE_LOCAL_INTERNAL_APPROVED_RISK_SOURCE_INDEXING_ONLY",
        "indexed_count": len(indexed),
        "indexed_records": indexed[:20],
        "source_index": risk_state["source_index"],
        "receipt_id": receipt["id"],
        "boundary": "Approved local/RAG source indexing only. No provider call, no external vector store, no live accounting sync, no external write.",
    }


def rag_health() -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    records = _risk_source_records(state)
    source_index = risk_state.get("source_index", {})
    user_sources = [record for record in risk_state.get("source_records", []) if record.get("source_type") == "user_supplied_source"]
    return {
        "product": "Finance Suite Sources & Search",
        "status": "DONE_LOCAL_INTERNAL_RAG_SOURCE_INTELLIGENCE_ONLY",
        "mode": "local_internal_retrieval_only",
        "route": "/finance/rag",
        "health_route": "/finance/api/rag/status",
        "boundary": COMPLIANCE_BOUNDARY,
        "counts": {
            "sources": len(records),
            "indexed_sources": source_index.get("indexed_count", 0),
            "user_sources": len(user_sources),
            "excluded_prefixes": len(RISK_EXCLUDED_SOURCE_PREFIXES),
            "provider_calls": 0,
            "external_writes": 0,
        },
        "tabs": ["Search", "Sources", "Internal Sources", "External References", "Exclusions", "Receipts", "Limits"],
        "source_index": source_index,
        "excluded_prefixes": list(RISK_EXCLUDED_SOURCE_PREFIXES),
        "accepted_source_types": [
            "internal files and AMTL docs",
            "manual uploads or pasted text",
            "NAS folders except the two excluded prefixes",
            "external source references supplied by the user",
            "external pasted excerpts supplied by the user",
        ],
        "blocked_without_approval": [
            "external URL fetching",
            "paid vector database use",
            "provider embedding/model calls",
            "live accounting/provider sync",
            "external writes",
        ],
        "right_rail": {
            "what": "Sources & Search is accessed from the Finance Suite menu and from risk source review/search actions.",
            "why": "It lets Finance Suite ground risk, runway, Ledger and Genie work in local/manual evidence.",
            "how": "Sources are indexed into the local JSON state and retrieved with deterministic text matching until a provider/vector path is separately approved.",
            "source_evidence": str(STATE_PATH),
            "freshness": _now(),
            "write_boundary": "No external fetch, provider call, vector-store write or accounting mutation.",
        },
        "failure_states": [
            {"state": "no_sources", "message": "Search returns no local hits until sources are indexed or supplied."},
            {"state": "excluded_path", "message": "The two approved NAS exclusions are skipped exactly."},
            {"state": "external_reference_only", "message": "External URLs are stored as citations unless pasted text is supplied."},
            {"state": "provider_vector_gated", "message": "Provider embeddings/vector DB calls remain blocked_approval_required."},
        ],
        "last_verified": _now(),
    }


def rag_sources(limit: int = 80) -> dict[str, Any]:
    records = _risk_source_records(load_state())
    return {
        "sources": records[: max(1, min(limit, 250))],
        "source_count": len(records),
        "boundary": COMPLIANCE_BOUNDARY,
        "provider_called": False,
        "vector_store_used": False,
        "external_write": False,
    }


def register_rag_source(
    name: str,
    source_scope: str = "internal",
    source_type: str = "manual",
    text: str | None = None,
    path: str | None = None,
    url: str | None = None,
    citation: str | None = None,
) -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    source_scope = (source_scope or "internal").strip().lower()
    source_type = (source_type or "manual").strip().lower()
    title = (name or citation or url or path or "User supplied RAG source").strip()
    record_text = (text or "").strip()
    blocked_fetch = False
    indexed_path = None
    if path:
        candidate = Path(path)
        if not _safe_risk_source_path(candidate):
            raise ValueError("Path is outside approved local/RAG indexing scope or matches an excluded NAS prefix.")
        indexed_path = str(candidate)
        if not record_text and candidate.exists():
            loaded = _read_risk_source_file(candidate)
            record_text = loaded or ""
    if url and not record_text:
        blocked_fetch = True
        record_text = f"External reference only. URL fetching is blocked without separate approval. Citation: {citation or url}"
    record = {
        "id": f"rag-user-source-{uuid4().hex[:10]}",
        "source_type": "user_supplied_source",
        "source_system": f"{source_scope}:{source_type}",
        "title": title,
        "text": record_text[:5000],
        "synthetic": False,
        "created_at": _now(),
        "payload": {
            "source_scope": source_scope,
            "source_type": source_type,
            "path": indexed_path,
            "url": url,
            "citation": citation,
            "external_fetch_state": "blocked_approval_required" if blocked_fetch else "not_required",
        },
    }
    risk_state.setdefault("source_records", []).insert(0, record)
    save_state(state)
    receipt = create_receipt(
        "rag_source_registered",
        f"Registered Finance Suite RAG source: {title}.",
        ["finance-rag-source", record["id"]],
        {"source_id": record["id"], "external_fetch_state": record["payload"]["external_fetch_state"], "provider_called": False},
    )
    return {
        "status": "rag_source_registered_local_only",
        "source": record,
        "receipt_id": receipt["id"],
        "provider_called": False,
        "vector_store_used": False,
        "external_write": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def search_rag_sources(query: str, limit: int = 8) -> dict[str, Any]:
    terms = [term for term in (query or "").lower().replace("/", " ").split() if len(term) >= 2]
    records = _risk_source_records(load_state())
    scored: list[dict[str, Any]] = []
    for record in records:
        haystack = f"{record.get('title', '')} {record.get('source_system', '')} {record.get('text', '')}".lower()
        score = sum(haystack.count(term) for term in terms) if terms else 0
        if score:
            excerpt_source = record.get("text") or record.get("title") or ""
            first_term = next((term for term in terms if term in excerpt_source.lower()), "")
            index = excerpt_source.lower().find(first_term) if first_term else 0
            start = max(0, index - 80)
            excerpt = excerpt_source[start : start + 260]
            scored.append(
                {
                    "score": score,
                    "source_record_id": record.get("id"),
                    "title": record.get("title"),
                    "source_system": record.get("source_system"),
                    "source_type": record.get("source_type"),
                    "citation": record.get("payload", {}).get("path") or record.get("payload", {}).get("url") or record.get("title"),
                    "excerpt": excerpt,
                    "synthetic": bool(record.get("synthetic")),
                }
            )
    scored.sort(key=lambda row: row["score"], reverse=True)
    receipt = create_receipt(
        "rag_local_search",
        f"Searched Finance Suite local/RAG sources for '{query}'.",
        ["finance-rag-search"],
        {"query": query, "hit_count": len(scored), "provider_called": False, "vector_store_used": False},
    )
    return {
        "query": query,
        "hits": scored[: max(1, min(limit, 25))],
        "hit_count": len(scored),
        "receipt_id": receipt["id"],
        "provider_called": False,
        "vector_store_used": False,
        "external_write": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def scan_risk_sources() -> dict[str, Any]:
    state = load_state()
    records = _risk_source_records(state)
    signals: list[dict[str, Any]] = []
    for record in records:
        text = (record.get("text") or "").lower()
        for signal, category, subcategory, why in RISK_SIGNAL_RULES:
            if signal in text:
                confidence = 0.86 if record.get("source_type") in {"ledger_exception", "scenario"} else 0.72
                signals.append(
                    {
                        "signal": signal,
                        "source_record_id": record.get("id"),
                        "source_type": record.get("source_type"),
                        "source_system": record.get("source_system"),
                        "source_citation": record.get("title"),
                        "suggested_category": category,
                        "suggested_subcategory": subcategory,
                        "suggested_severity": _severity_from_signal(signal, confidence),
                        "confidence": confidence,
                        "why_detected": why,
                        "synthetic": bool(record.get("synthetic")),
                        "freshness": record.get("created_at") or _now(),
                    }
                )
    receipt = create_receipt(
        "risk_source_scan",
        f"Scanned {len(records)} local/RAG-ready sources and found {len(signals)} risk signals.",
        ["finance-risk-source-scan"],
        {"source_count": len(records), "signal_count": len(signals), "provider_called": False},
    )
    return {
        "source_count": len(records),
        "signals": signals,
        "signal_count": len(signals),
        "receipt_id": receipt["id"],
        "rag_strategy": {
            "current": "approved local/RAG source indexing plus deterministic local scanning over finance state, reports, receipts and fixture-backed artefacts",
            "future": "larger provider/external vector store use remains separately approval-gated",
            "provider_called": False,
            "vector_store_used": False,
            "state": "approved_local_rag_indexing_provider_vector_store_blocked",
            "source_index": _risk_state(state).get("source_index", {}),
        },
        "boundary": COMPLIANCE_BOUNDARY,
    }


def _candidate_from_signal(signal: dict[str, Any]) -> dict[str, Any]:
    cid = f"risk-candidate-{uuid4().hex[:10]}"
    evidence = [
        {
            "source_record_id": signal["source_record_id"],
            "source_type": signal["source_type"],
            "source_system": signal["source_system"],
            "citation": signal["source_citation"],
        }
    ]
    title = f"{signal['suggested_subcategory'].title()} signal from {signal['source_system']}"
    return {
        "candidate_id": cid,
        "status": "draft_candidate",
        "source_signal": signal["signal"],
        "source_citation": signal["source_citation"],
        "suggested_category": signal["suggested_category"],
        "suggested_subcategory": signal["suggested_subcategory"],
        "suggested_severity": signal["suggested_severity"],
        "suggested_owner": "Unassigned",
        "confidence": signal["confidence"],
        "why_detected": signal["why_detected"],
        "next_safe_action": "Review source evidence, assign an owner, then approve, edit, merge, split, lock or archive.",
        "synthetic": signal["synthetic"],
        "field_overrides": {
            "title": _field_value(title, signal["confidence"], evidence),
            "category": _field_value(signal["suggested_category"], signal["confidence"], evidence),
            "subcategory": _field_value(signal["suggested_subcategory"], signal["confidence"], evidence),
            "severity": _field_value(signal["suggested_severity"], signal["confidence"], evidence),
            "owner": _field_value("Unassigned", 0.55, evidence),
        },
        "supporting_evidence": evidence,
        "created_at": _now(),
    }


def generate_risk_candidates() -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    scan = scan_risk_sources()
    existing_keys = {
        (candidate.get("source_signal"), candidate.get("source_citation"), candidate.get("suggested_subcategory"))
        for candidate in risk_state.get("candidates", [])
        if candidate.get("status") != "archived"
    }
    new_candidates = []
    for signal in scan["signals"]:
        key = (signal["signal"], signal["source_citation"], signal["suggested_subcategory"])
        if key in existing_keys:
            continue
        candidate = _candidate_from_signal(signal)
        new_candidates.append(candidate)
        existing_keys.add(key)
    risk_state["candidates"] = new_candidates + risk_state.get("candidates", [])
    save_state(state)
    receipt = create_receipt(
        "risk_candidate_generated",
        f"Generated {len(new_candidates)} local draft risk candidates.",
        ["finance-risk-source-scan"],
        {"generated_count": len(new_candidates), "provider_called": False},
    )
    return {
        "generated_count": len(new_candidates),
        "candidates": new_candidates,
        "total_candidates": len(risk_state.get("candidates", [])),
        "source_scan_receipt_id": scan["receipt_id"],
        "receipt_id": receipt["id"],
        "boundary": COMPLIANCE_BOUNDARY,
    }


def risk_candidates() -> dict[str, Any]:
    risk_state = _risk_state()
    return {
        "candidates": risk_state.get("candidates", []),
        "count": len(risk_state.get("candidates", [])),
        "boundary": COMPLIANCE_BOUNDARY,
    }


def _candidate_to_risk(candidate: dict[str, Any], edits: dict[str, Any] | None = None) -> dict[str, Any]:
    edits = edits or {}
    risk_id = f"risk-{uuid4().hex[:10]}"
    field_overrides = candidate.get("field_overrides", {})
    title = edits.get("title") or field_overrides.get("title", {}).get("current_displayed_value") or candidate.get("source_signal")
    category = edits.get("category") or field_overrides.get("category", {}).get("current_displayed_value") or candidate.get("suggested_category")
    subcategory = edits.get("subcategory") or field_overrides.get("subcategory", {}).get("current_displayed_value") or candidate.get("suggested_subcategory")
    severity = edits.get("severity") or field_overrides.get("severity", {}).get("current_displayed_value") or candidate.get("suggested_severity")
    owner = edits.get("owner") or field_overrides.get("owner", {}).get("current_displayed_value") or "Unassigned"
    return {
        "risk_id": risk_id,
        "title": title,
        "category": category,
        "subcategory": subcategory,
        "description": edits.get("description") or candidate.get("why_detected"),
        "business_area_affected": edits.get("business_area_affected") or "Finance / Operations",
        "financial_impact": edits.get("financial_impact") or "scenario impact requires human review",
        "non_financial_impact": edits.get("non_financial_impact") or "delivery, confidence or operational exposure",
        "likelihood": edits.get("likelihood") or "medium",
        "impact": edits.get("impact") or severity,
        "severity": severity,
        "velocity": edits.get("velocity") or "medium",
        "time_horizon": edits.get("time_horizon") or "30-90 days",
        "owner": owner,
        "status": "active",
        "confidence": candidate.get("confidence"),
        "freshness": _now(),
        "supporting_evidence": candidate.get("supporting_evidence", []),
        "source_system": candidate.get("supporting_evidence", [{}])[0].get("source_system", "local"),
        "trigger_condition": edits.get("trigger_condition") or "source signal recurs or severity rises",
        "early_warning_signals": edits.get("early_warning_signals") or [candidate.get("source_signal")],
        "current_controls": edits.get("current_controls") or ["human review", "local receipt trail"],
        "mitigation_plan": edits.get("mitigation_plan") or "Assign owner, validate evidence and run scenario review.",
        "contingency_plan": edits.get("contingency_plan") or "Escalate to human decision gate before any external action.",
        "residual_risk": edits.get("residual_risk") or "medium",
        "related_decision": edits.get("related_decision") or "pending human review",
        "related_scenario": edits.get("related_scenario") or None,
        "related_entity": edits.get("related_entity") or {"customer": None, "vendor": None, "project": None, "person": owner, "system": candidate.get("source_citation")},
        "review_cadence": edits.get("review_cadence") or "monthly",
        "last_reviewed": None,
        "receipt_link": None,
        "field_overrides": field_overrides,
        "mitigations": [],
        "decision_gate": {
            "decision_being_considered": edits.get("related_decision") or "pending human review",
            "supporting_scenario": edits.get("related_scenario"),
            "risks_triggered": [risk_id],
            "required_evidence": ["source citation", "owner review", "scenario impact"],
            "missing_evidence": ["human-approved decision"],
            "red_flags": [candidate.get("source_signal")],
            "safe_next_question": "What evidence would reduce this risk signal?",
            "human_approval_needed": True,
            "do_not_proceed_until": ["owner assigned", "evidence reviewed", "external actions approved separately"],
            "decision_receipt": None,
        },
        "created_at": _now(),
    }


def approve_risk_candidate(candidate_id: str, edits: dict[str, Any] | None = None) -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    candidate = next((row for row in risk_state.get("candidates", []) if row.get("candidate_id") == candidate_id), None)
    if not candidate:
        raise ValueError("Risk candidate not found.")
    risk = _candidate_to_risk(candidate, edits)
    receipt = create_receipt(
        "risk_candidate_approved",
        f"Approved risk candidate {candidate_id} into risk register.",
        ["finance-risk-candidate"],
        {"candidate_id": candidate_id, "risk_id": risk["risk_id"]},
    )
    risk["receipt_link"] = receipt["id"]
    candidate["status"] = "approved"
    candidate["approved_risk_id"] = risk["risk_id"]
    risk_state["risks"].insert(0, risk)
    save_state(state)
    return {"risk": risk, "candidate": candidate, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def risk_register() -> dict[str, Any]:
    risk_state = _risk_state()
    risks = risk_state.get("risks", [])
    return {
        "risks": risks,
        "counts": {
            "active_risks": len([risk for risk in risks if risk.get("status") == "active"]),
            "high_severity": len([risk for risk in risks if risk.get("severity") == "high"]),
            "ownerless": len([risk for risk in risks if risk.get("owner") in {"Unassigned", "", None}]),
            "overridden_fields": sum(1 for risk in risks for field in risk.get("field_overrides", {}).values() if field.get("override_status") == "user_override"),
            "mitigations": sum(len(risk.get("mitigations", [])) for risk in risks),
            "decision_gates": len([risk for risk in risks if risk.get("decision_gate")]),
        },
        "boundary": COMPLIANCE_BOUNDARY,
    }


def risk_source_review() -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    source_records = _risk_source_records(state)
    risks = risk_state.get("risks", [])
    candidates = risk_state.get("candidates", [])
    active = [risk for risk in risks if risk.get("status") == "active"]
    decision_gates = [risk.get("decision_gate") for risk in risks if risk.get("decision_gate")]
    source_type_counts: dict[str, int] = {}
    for record in source_records:
        source_type = record.get("source_type") or "unknown"
        source_type_counts[source_type] = source_type_counts.get(source_type, 0) + 1
    return {
        "product": "Fin Strategist Risk Intelligence Source Review",
        "status": "DONE_LOCAL_INTERNAL_RISK_SOURCE_REVIEW_SCREEN_ONLY",
        "route": "/finance/strategist/risk/source-review",
        "boundary": COMPLIANCE_BOUNDARY,
        "source_records": source_records[:50],
        "source_type_counts": source_type_counts,
        "candidates": candidates[:50],
        "risks": risks[:50],
        "overrides": risk_state.get("overrides", [])[:50],
        "reviews": risk_state.get("reviews", [])[:20],
        "merges": risk_state.get("merges", [])[:20],
        "archives": risk_state.get("archives", [])[:20],
        "receipts": risk_receipts()[:20],
        "decision_gates": decision_gates[:50],
        "scenario_links": [risk for risk in active if risk.get("related_scenario")][:30],
        "mitigations": [
            {"risk_id": risk.get("risk_id"), "title": risk.get("title"), "mitigations": risk.get("mitigations", [])}
            for risk in risks
            if risk.get("mitigations")
        ],
        "screen_contract": {
            "candidate_inbox": "Draft candidates must remain editable and require human approval.",
            "source_citations": "Every candidate and register row should show source evidence where available.",
            "confidence_and_gaps": "Low confidence, missing owner and stale review states stay visible.",
            "category_mapper": "Risk categories include finance and non-finance business risk groups.",
            "mitigation_planner": "Mitigation text is local planning support only.",
            "override_history": "User overrides preserve the original suggestion and reason.",
            "approval_boundary": "Local/RAG source indexing is approved; provider/external vector/live accounting actions remain blocked unless separately approved.",
        },
        "counts": {
            "sources": len(source_records),
            "candidates": len(candidates),
            "risks": len(risks),
            "active_risks": len(active),
            "decision_gates": len(decision_gates),
            "overrides": len(risk_state.get("overrides", [])),
            "reviews": len(risk_state.get("reviews", [])),
            "receipts": len(risk_receipts()),
        },
    }


def update_risk(risk_id: str, updates: dict[str, Any]) -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    risk = next((row for row in risk_state.get("risks", []) if row.get("risk_id") == risk_id), None)
    if not risk:
        raise ValueError("Risk not found.")
    allowed = {
        "title",
        "category",
        "subcategory",
        "description",
        "business_area_affected",
        "financial_impact",
        "non_financial_impact",
        "likelihood",
        "impact",
        "severity",
        "velocity",
        "time_horizon",
        "owner",
        "status",
        "trigger_condition",
        "early_warning_signals",
        "current_controls",
        "mitigation_plan",
        "contingency_plan",
        "residual_risk",
        "related_decision",
        "related_scenario",
        "related_entity",
        "review_cadence",
    }
    for key, value in updates.items():
        if key in allowed:
            risk[key] = value
    receipt = create_receipt("risk_edited", f"Edited risk {risk_id}.", ["finance-risk-register"], {"risk_id": risk_id, "updated_fields": sorted(set(updates) & allowed)})
    risk["receipt_link"] = receipt["id"]
    save_state(state)
    return {"risk": risk, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def override_risk_field(risk_id: str, field: str, value: Any, reason: str, locked_by_user: bool = False, reviewed_by: str = "local_user") -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    risk = next((row for row in risk_state.get("risks", []) if row.get("risk_id") == risk_id), None)
    if not risk:
        raise ValueError("Risk not found.")
    evidence = risk.get("supporting_evidence", [])
    original = risk.get(field)
    risk[field] = value
    risk.setdefault("field_overrides", {})[field] = {
        "system_suggested_value": original,
        "user_confirmed_value": value,
        "current_displayed_value": value,
        "confidence": risk.get("confidence", 0.5),
        "evidence_source": evidence,
        "freshness": _now(),
        "override_status": "user_override",
        "override_reason": reason,
        "locked_by_user": locked_by_user,
        "last_reviewed_by": reviewed_by,
        "last_reviewed_at": _now(),
    }
    risk_state.setdefault("overrides", []).insert(0, {"risk_id": risk_id, "field": field, "value": value, "reason": reason, "created_at": _now()})
    receipt = create_receipt("risk_overridden", f"Overrode {field} for risk {risk_id}.", ["finance-risk-override"], {"risk_id": risk_id, "field": field, "locked_by_user": locked_by_user})
    risk["receipt_link"] = receipt["id"]
    save_state(state)
    return {"risk": risk, "override": risk["field_overrides"][field], "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def merge_risks(primary_risk_id: str, secondary_risk_id: str, reason: str = "Related local risk signals.") -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    primary = next((row for row in risk_state.get("risks", []) if row.get("risk_id") == primary_risk_id), None)
    secondary = next((row for row in risk_state.get("risks", []) if row.get("risk_id") == secondary_risk_id), None)
    if not primary or not secondary:
        raise ValueError("Both risks must exist to merge.")
    primary.setdefault("supporting_evidence", []).extend(secondary.get("supporting_evidence", []))
    primary.setdefault("merged_risk_ids", []).append(secondary_risk_id)
    secondary["status"] = "merged"
    merge_record = {"primary_risk_id": primary_risk_id, "secondary_risk_id": secondary_risk_id, "reason": reason, "created_at": _now()}
    risk_state.setdefault("merges", []).insert(0, merge_record)
    receipt = create_receipt("risk_merged", f"Merged risk {secondary_risk_id} into {primary_risk_id}.", ["finance-risk-register"], merge_record)
    primary["receipt_link"] = receipt["id"]
    save_state(state)
    return {"primary": primary, "secondary": secondary, "merge": merge_record, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def archive_risk(risk_id: str, reason: str = "Archived after local review.") -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    risk = next((row for row in risk_state.get("risks", []) if row.get("risk_id") == risk_id), None)
    if not risk:
        raise ValueError("Risk not found.")
    risk["status"] = "archived"
    archive = {"risk_id": risk_id, "reason": reason, "created_at": _now()}
    risk_state.setdefault("archives", []).insert(0, archive)
    receipt = create_receipt("risk_archived", f"Archived risk {risk_id}.", ["finance-risk-register"], archive)
    risk["receipt_link"] = receipt["id"]
    save_state(state)
    return {"risk": risk, "archive": archive, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def review_risk_register(reviewed_by: str = "local_user", notes: str = "Local risk review completed.") -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    now = _now()
    for risk in risk_state.get("risks", []):
        if risk.get("status") == "active":
            risk["last_reviewed"] = now
            for field in risk.get("field_overrides", {}).values():
                field["last_reviewed_by"] = reviewed_by
                field["last_reviewed_at"] = now
    review = {"id": f"risk-review-{uuid4().hex[:10]}", "reviewed_by": reviewed_by, "notes": notes, "risk_count": len(risk_state.get("risks", [])), "created_at": now}
    risk_state.setdefault("reviews", []).insert(0, review)
    receipt = create_receipt("risk_review_completed", "Completed local Risk Intelligence review.", ["finance-risk-register"], review)
    review["receipt_id"] = receipt["id"]
    save_state(state)
    return {"review": review, "receipt_id": receipt["id"], "boundary": COMPLIANCE_BOUNDARY}


def risk_demo_data_status() -> dict[str, Any]:
    risk_state = _risk_state()
    synthetic_sources = [source for source in risk_state.get("source_records", []) if source.get("synthetic")]
    synthetic_candidates = [candidate for candidate in risk_state.get("candidates", []) if candidate.get("synthetic")]
    return {
        "synthetic_data_present": bool(risk_state.get("synthetic_data_present")),
        "synthetic_removed_at": risk_state.get("synthetic_removed_at"),
        "fixture_rows": len(synthetic_sources) + len(synthetic_candidates),
        "boundary": "Risk synthetic rows are labelled and removable; no fake live risk data claim is made.",
    }


def reload_risk_synthetic() -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    existing = [source for source in risk_state.get("source_records", []) if not source.get("synthetic")]
    risk_state["source_records"] = list(RISK_SYNTHETIC_SOURCES) + existing
    risk_state["synthetic_data_present"] = True
    risk_state["synthetic_removed_at"] = None
    save_state(state)
    receipt = create_receipt("risk_synthetic_reloaded", "Reloaded labelled Risk Intelligence synthetic source rows.", ["finance-risk-demo-data"], {"row_count": len(RISK_SYNTHETIC_SOURCES)})
    return {"receipt_id": receipt["id"], **risk_demo_data_status()}


def remove_risk_synthetic(preview: bool = False) -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    before = risk_demo_data_status()
    if preview:
        return {"preview": True, "would_remove_fixture_rows": before["fixture_rows"], **before}
    risk_state["source_records"] = [source for source in risk_state.get("source_records", []) if not source.get("synthetic")]
    risk_state["candidates"] = [candidate for candidate in risk_state.get("candidates", []) if not candidate.get("synthetic")]
    risk_state["synthetic_data_present"] = False
    risk_state["synthetic_removed_at"] = _now()
    save_state(state)
    receipt = create_receipt("risk_synthetic_removed", "Removed Risk Intelligence synthetic source and candidate rows.", ["finance-risk-demo-data"], {"removed_rows": before["fixture_rows"]})
    return {"preview": False, "removed_fixture_rows": before["fixture_rows"], "receipt_id": receipt["id"], **risk_demo_data_status()}


def risk_receipts() -> list[dict[str, Any]]:
    return [receipt for receipt in load_state().get("receipts", []) if receipt.get("kind", "").startswith("risk_") or receipt.get("kind", "").startswith("risk")]


def risk_health() -> dict[str, Any]:
    state = load_state()
    risk_state = _risk_state(state)
    risks = risk_state.get("risks", [])
    candidates = risk_state.get("candidates", [])
    active = [risk for risk in risks if risk.get("status") == "active"]
    ownerless = [risk for risk in active if risk.get("owner") in {"Unassigned", "", None}]
    high = [risk for risk in active if risk.get("severity") == "high"]
    stale = [risk for risk in active if not risk.get("last_reviewed")]
    return {
        "product": "Fin Strategist Risk Intelligence",
        "status": "DONE_LOCAL_INTERNAL_RISK_INTELLIGENCE_ONLY",
        "mode": "local_internal_risk_decision_support_only",
        "route": "/finance/strategist/risk",
        "health_route": "/finance/api/risk/health",
        "category_groups": RISK_CATEGORY_GROUPS,
        "dashboard": {
            "overall_risk_posture": "watch" if high else "stable_watch",
            "top_active_risks": active[:5],
            "new_emerging_risks": candidates[:5],
            "stale_evidence_risks": stale,
            "ownerless_risks": ownerless,
            "high_severity_risks": high,
            "scenario_linked_risks": [risk for risk in active if risk.get("related_scenario")],
            "blocked_decision_gates": [risk.get("decision_gate") for risk in active if risk.get("decision_gate", {}).get("human_approval_needed")],
            "recent_receipts": risk_receipts()[:10],
        },
        "counts": {
            "active_risks": len(active),
            "candidates": len(candidates),
            "high_severity": len(high),
            "stale_evidence": len(stale),
            "ownerless_risks": len(ownerless),
            "linked_scenarios": len([risk for risk in active if risk.get("related_scenario")]),
            "mitigations": sum(len(risk.get("mitigations", [])) for risk in risks),
            "decision_gates": len([risk for risk in risks if risk.get("decision_gate")]),
            "overridden_fields": sum(1 for risk in risks for field in risk.get("field_overrides", {}).values() if field.get("override_status") == "user_override"),
            "receipts": len(risk_receipts()),
            "synthetic_records": risk_demo_data_status()["fixture_rows"],
        },
        "right_rail": {
            **right_rail("strategist"),
            "what": "Risk Intelligence drafts and manages business risk signals across finance, operations, delivery, technology and governance.",
            "why": "Risk signals often live in numbers and narrative artefacts; this module keeps them visible with evidence and overrides.",
            "receipt_link": "/finance/api/risk/receipts",
            "write_boundary": "Draft decision support only. No advice, provider call, bank/API, accounting write, payroll/payment mutation or browser final action.",
        },
        "failure_states": failure_states("strategist")
        + [
            {"state": "no_risks", "message": "No approved risks yet; generate candidates first."},
            {"state": "no_candidates", "message": "No draft candidates yet; run local source scan/generation."},
            {"state": "no_source_data", "message": "No local sources available is shown as an empty scan."},
            {"state": "source_scan_empty", "message": "A scan with zero signals creates a receipt and no fake risk."},
            {"state": "low_confidence_candidate", "message": "Low-confidence candidates require human review before approval."},
            {"state": "stale_evidence", "message": "Risks without recent review are flagged as stale."},
            {"state": "override_conflict", "message": "User overrides preserve system suggestion and reason."},
            {"state": "provider_vector_gated", "message": "Local/RAG source indexing is approved; provider or external vector store use remains approval-gated."},
            {"state": "browser_assist_final_action_gated", "message": "Final browser accounting actions are blocked_approval_required."},
        ],
        "source_strategy": {
            "current": "deterministic local source scanning and fixture-backed extraction",
            "future_rag": "approved local source manifests and NAS indexing with exact excluded prefixes; provider/external vector use remains separately approval-gated",
            "auto_population": "draft candidates only; user approval/override remains first-class",
            "source_index": risk_state.get("source_index", {}),
        },
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def browser_assist_health() -> dict[str, Any]:
    state = load_state()
    return {
        "product": "Finance Browser Assist",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_BROWSER_ASSIST_ONLY",
        "mode": "local_internal_screen_assist_only",
        "route": "/finance/browser-assist",
        "health_route": "/finance/api/browser-assist/health",
        "supported_platforms": list(ACCOUNTING_BROWSER_PLATFORMS.values()),
        "supported_tasks": BROWSER_ASSIST_TASKS,
        "counts": {
            "sessions": len(state.get("browser_assist", [])),
            "session_artifacts": len(state.get("browser_assist_artifacts", [])),
            "receipts": len(browser_assist_receipts()),
            "destination_owned_receipts": len(state.get("destination_receipts", [])),
            "ledger_entries_available": len(state["products"]["ledger"].get("entries", [])),
            "payroll_source_rows": len(_payroll_source_rows(state)),
        },
        "rules": [
            "The user logs in manually in their own browser session.",
            "Finance Suite does not collect, store or request credentials, MFA codes, bank credentials or API keys.",
            "Finance Suite prepares copy-ready drafts, checklists and receipts from local/manual data.",
            "Pay-stub/pay-slip assist prepares statement fields for accounting-software payroll screens but does not issue, send, post or lodge them.",
            "Every Browser Assist preparation creates a session artifact for Genie, Ledger and Fin Strategist double-checking.",
            "Finance Suite must not click submit, post, pay, reconcile, connect bank feeds or mutate accounting data.",
            "Final accounting actions remain human-owned and approval-gated.",
        ],
        "right_rail": {
            **right_rail("ledger"),
            "what": "Browser Assist helps a logged-in human transfer local Finance Suite drafts into QuickBooks, MYOB or Xero.",
            "how": "It turns local Ledger/Genie/Strategist data into copy-ready fields and step checklists, then records a receipt.",
            "write_boundary": "No autonomous login, credential handling, submit/post/pay/reconcile final click, payment or accounting mutation.",
            "receipt_link": "/finance/api/browser-assist/receipts",
        },
        "failure_states": failure_states("ledger")
        + [
            {"state": "not_logged_in", "message": "The user must log in manually; this app does not handle credentials."},
            {"state": "unsupported_platform", "message": "Only QuickBooks, MYOB and Xero browser-assist templates are available in this local build."},
            {"state": "pay_stub_human_review_required", "message": "Pay-stub/pay-slip fields must be reviewed against payroll records before save, issue, send or filing."},
            {"state": "session_artifact_missing", "message": "If no session artifact exists, the session is not ready for cross-product double-checking."},
            {"state": "final_submit_gated", "message": "Submit/post/pay/reconcile actions return blocked_approval_required with a receipt."},
            {"state": "no_screen_access", "message": "No autonomous browser-control or screen-reading claim is made by this local feature."},
        ],
        "boundary": COMPLIANCE_BOUNDARY,
        "last_verified": _now(),
    }


def _normalise_platform(platform: str) -> str:
    key = (platform or "").strip().lower().replace(" ", "")
    aliases = {"quickbooks": "quickbooks", "quickbooksonline": "quickbooks", "qbo": "quickbooks", "myob": "myob", "xero": "xero"}
    if key not in aliases:
        raise ValueError("Unsupported accounting browser-assist platform. Use quickbooks, myob, or xero.")
    return aliases[key]


def _payroll_source_rows(state: dict[str, Any]) -> list[dict[str, Any]]:
    payroll_terms = ("payroll", "wage", "wages", "salary", "super", "employee", "pay run", "payroll clearing")
    rows = []
    for row in state["products"]["ledger"].get("entries", []):
        haystack = f"{row.get('description', '')} {row.get('category', '')} {row.get('kind', '')}".lower()
        if any(term in haystack for term in payroll_terms):
            rows.append(row)
    return rows[:10]


def _pay_stub_statement_fields(
    state: dict[str, Any],
    employee_name: str | None = None,
    pay_period_start: str | None = None,
    pay_period_end: str | None = None,
    pay_date: str | None = None,
    gross_pay: float | None = None,
    net_pay: float | None = None,
    tax_withheld: float | None = None,
    superannuation: float | None = None,
    earnings: list[dict[str, Any]] | None = None,
    deductions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    payroll_rows = _payroll_source_rows(state)
    payroll_total = round(abs(sum(float(row.get("amount") or 0) for row in payroll_rows)), 2)
    inferred_gross = gross_pay if gross_pay is not None else (payroll_total if payroll_total else 0.0)
    inferred_tax = tax_withheld if tax_withheld is not None else 0.0
    inferred_super = superannuation if superannuation is not None else round(float(inferred_gross) * 0.115, 2) if inferred_gross else 0.0
    inferred_net = net_pay if net_pay is not None else max(round(float(inferred_gross) - float(inferred_tax), 2), 0.0)
    return {
        "employee_name": employee_name or "Human-reviewed employee name required",
        "pay_period_start": pay_period_start or "Human review required",
        "pay_period_end": pay_period_end or "Human review required",
        "payment_date": pay_date or "Human review required",
        "gross_pay": round(float(inferred_gross), 2),
        "net_pay": round(float(inferred_net), 2),
        "tax_withheld": round(float(inferred_tax), 2),
        "superannuation": round(float(inferred_super), 2),
        "earnings": earnings or ([{"label": "Ordinary hours / wages", "amount": round(float(inferred_gross), 2)}] if inferred_gross else []),
        "deductions": deductions or [],
        "payroll_source_rows": [
            {
                "date": row.get("date"),
                "description": row.get("description"),
                "amount": row.get("amount"),
                "source": row.get("source"),
                "receipt_id": row.get("receipt_id"),
            }
            for row in payroll_rows
        ],
        "required_human_checks": [
            "Confirm employee name and payroll profile inside the accounting software.",
            "Confirm pay period, payment date, gross pay, net pay, tax withheld, deductions, allowances and superannuation.",
            "Do not show paid family and domestic violence leave as a labelled leave line unless a qualified human process confirms the safe reporting treatment.",
            "Preview or save as draft first; final issue/send/post remains human-owned.",
        ],
        "fair_work_reference": "Fair Work Ombudsman: pay slips should be provided within one working day of payment and include required pay details; this app only provides a local draft/checklist.",
    }


def _create_browser_assist_artifact(state: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    destination_receipts = [
        row
        for row in state.get("destination_receipts", [])
        if row.get("session_id") == session.get("id")
    ]
    artifact = {
        "id": f"browser-artifact-{uuid4().hex[:10]}",
        "session_id": session.get("id"),
        "platform": session.get("platform"),
        "platform_name": session.get("platform_name"),
        "task": session.get("task"),
        "task_label": session.get("task_label"),
        "status": "session_artifact_created",
        "created_at": _now(),
        "session_created_at": session.get("created_at"),
        "data_sources": session.get("data_sources", ["ledger-local-rows", "genie-local-context", "strategist-local-scenarios"]),
        "draft_fields_snapshot": session.get("draft_fields", {}),
        "human_checklist": session.get("human_checklist", []),
        "blocked_final_actions": session.get("blocked_final_actions", []),
        "destination_receipts": destination_receipts,
        "double_check_map": {
            "genie": "Review whether the business context and caveats match the copied accounting-software draft.",
            "ledger": "Reconcile amounts, contacts, dates, categories, payroll fields and receipt IDs against local ledger rows.",
            "fin_strategist": "Check whether the session changes cashflow, runway, margin, payroll or risk assumptions.",
        },
        "verification_questions": [
            "Which screen in the accounting software was used?",
            "Was the item only previewed/saved as draft, or was any final action taken by the human?",
            "What destination-owned receipt, audit ID or screenshot reference came back?",
            "Which fields should Genie/Ledger/Fin Strategist re-check before relying on this work?",
        ],
        "finance_suite_external_write": False,
        "finance_suite_provider_called": False,
        "credential_handling": "none",
        "boundary": COMPLIANCE_BOUNDARY,
    }
    state.setdefault("browser_assist_artifacts", []).insert(0, artifact)
    return artifact


def prepare_browser_assist(platform: str, task: str = "reconcile_review", source: str = "ledger") -> dict[str, Any]:
    platform_key = _normalise_platform(platform)
    if task not in BROWSER_ASSIST_TASKS:
        raise ValueError("Unsupported browser-assist task.")
    state = load_state()
    entries = state["products"]["ledger"].get("entries", [])[:10]
    genie_answers = state["products"]["genie"].get("answers", [])[:3]
    scenarios = state["products"]["strategist"].get("scenarios", [])[:3]
    session = {
        "id": f"browser-assist-{uuid4().hex[:10]}",
        "platform": platform_key,
        "platform_name": ACCOUNTING_BROWSER_PLATFORMS[platform_key],
        "task": task,
        "task_label": BROWSER_ASSIST_TASKS[task],
        "status": "draft_ready_human_browser_assist_only",
        "credential_handling": "none",
        "autonomous_browser_control": False,
        "external_write": False,
        "provider_called": False,
        "draft_fields": {
            "copy_ready_summary": "Human-reviewed draft only. Verify every field inside the accounting product before saving.",
            "ledger_rows": [
                {
                    "date": row.get("date"),
                    "description": row.get("description"),
                    "amount": row.get("amount"),
                    "category": row.get("category"),
                    "source": row.get("source"),
                    "confidence": row.get("confidence"),
                }
                for row in entries
            ],
            "genie_context": [answer.get("answer_draft") for answer in genie_answers],
            "strategist_context": [scenario.get("outputs", {}) for scenario in scenarios],
        },
        "data_sources": ["ledger-local-rows", "genie-local-context", "strategist-local-scenarios"],
        "human_checklist": [
            f"Open {ACCOUNTING_BROWSER_PLATFORMS[platform_key]} in your own browser and log in manually.",
            "Navigate to the relevant invoice, bill, journal, reconciliation or report screen yourself.",
            "Copy draft fields one at a time and verify date, amount, account/category and contact before any save.",
            "Use Preview or Save as draft where available; do not post, submit, pay, connect feeds or finalise from this assist panel.",
            "Record a receipt in Finance Suite after human review.",
        ],
        "blocked_final_actions": ["submit", "post", "pay", "final_reconcile", "connect_bank_feed", "publish_export"],
        "boundary": COMPLIANCE_BOUNDARY,
        "created_at": _now(),
    }
    if task == "pay_stub_draft":
        session["draft_fields"]["pay_stub_statement"] = _pay_stub_statement_fields(state)
        session["human_checklist"] = [
            f"Open {ACCOUNTING_BROWSER_PLATFORMS[platform_key]} in your own browser and log in manually.",
            "Navigate to Payroll / Pay runs / Pay slips or the nearest pay-statement draft screen yourself.",
            "Use the accounting software payroll record as the authority; copy these fields only as a checklist or draft aid.",
            "Preview or save as draft first. Do not issue, send, post payroll, pay employees or file externally from this assist panel.",
            "Record the destination-owned payroll/pay-slip receipt or audit ID after human review.",
        ]
        session["blocked_final_actions"] = ["issue_pay_slip", "send_pay_slip", "post_payroll", "pay_employee", "file_payroll", "connect_bank_feed"]
    state["browser_assist"].insert(0, session)
    artifact = _create_browser_assist_artifact(state, session)
    session["session_artifact_id"] = artifact["id"]
    save_state(state)
    receipt = create_receipt(
        "browser_assist_prepare",
        f"Prepared {ACCOUNTING_BROWSER_PLATFORMS[platform_key]} browser-assist draft for {task}.",
        ["finance-browser-assist", "ledger-local-rows"],
        {"session_id": session["id"], "platform": platform_key, "task": task, "source": source},
    )
    session["receipt_id"] = receipt["id"]
    artifact["receipt_id"] = receipt["id"]
    state = load_state()
    for stored in state.get("browser_assist", []):
        if stored.get("id") == session["id"]:
            stored["receipt_id"] = receipt["id"]
            stored["session_artifact_id"] = artifact["id"]
            break
    for stored in state.get("browser_assist_artifacts", []):
        if stored.get("id") == artifact["id"]:
            stored["receipt_id"] = receipt["id"]
            break
    save_state(state)
    return session


def prepare_pay_stub_assist(
    platform: str,
    employee_name: str | None = None,
    pay_period_start: str | None = None,
    pay_period_end: str | None = None,
    pay_date: str | None = None,
    gross_pay: float | None = None,
    net_pay: float | None = None,
    tax_withheld: float | None = None,
    superannuation: float | None = None,
    earnings: list[dict[str, Any]] | None = None,
    deductions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    platform_key = _normalise_platform(platform)
    state = load_state()
    statement = _pay_stub_statement_fields(
        state,
        employee_name,
        pay_period_start,
        pay_period_end,
        pay_date,
        gross_pay,
        net_pay,
        tax_withheld,
        superannuation,
        earnings,
        deductions,
    )
    session = prepare_browser_assist(platform_key, "pay_stub_draft", "payroll")
    state = load_state()
    for stored in state.get("browser_assist", []):
        if stored.get("id") == session["id"]:
            stored["draft_fields"]["pay_stub_statement"] = statement
            session = stored
            break
    for artifact in state.get("browser_assist_artifacts", []):
        if artifact.get("session_id") == session["id"]:
            artifact["draft_fields_snapshot"] = session.get("draft_fields", {})
            break
    save_state(state)
    receipt = create_receipt(
        "browser_assist_pay_stub_draft",
        f"Prepared {ACCOUNTING_BROWSER_PLATFORMS[platform_key]} pay-stub/pay-slip draft packet for human review.",
        ["finance-browser-assist-payroll", "ledger-payroll-local-rows"],
        {"session_id": session["id"], "platform": platform_key, "employee_name": statement["employee_name"]},
    )
    session["pay_stub_receipt_id"] = receipt["id"]
    session["pay_stub_statement"] = statement
    session["automation_state"] = "human_review_required_before_any_save_issue_send_post_file"
    session["external_write"] = False
    session["provider_called"] = False
    state = load_state()
    for stored in state.get("browser_assist", []):
        if stored.get("id") == session["id"]:
            stored["pay_stub_receipt_id"] = receipt["id"]
            stored["pay_stub_statement"] = statement
            stored["automation_state"] = session["automation_state"]
            break
    for artifact in state.get("browser_assist_artifacts", []):
        if artifact.get("session_id") == session["id"]:
            artifact["pay_stub_receipt_id"] = receipt["id"]
            artifact["draft_fields_snapshot"] = session.get("draft_fields", {})
            break
    save_state(state)
    return session


def block_browser_assist_final_action(platform: str, action: str) -> dict[str, Any]:
    platform_key = _normalise_platform(platform)
    receipt = create_receipt(
        "browser_assist_final_action_blocked",
        f"{ACCOUNTING_BROWSER_PLATFORMS[platform_key]} browser final action blocked: {action}.",
        ["finance-browser-assist-boundary"],
        {"platform": platform_key, "action": action, "reason": BLOCKED_ACTIONS["browser_final_submit"]},
    )
    return {
        "platform": platform_key,
        "platform_name": ACCOUNTING_BROWSER_PLATFORMS[platform_key],
        "action": action,
        "state": "blocked_approval_required",
        "reason": BLOCKED_ACTIONS["browser_final_submit"],
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "credential_handling": "none",
        "boundary": COMPLIANCE_BOUNDARY,
    }


def record_destination_owned_receipt(
    platform: str,
    destination_receipt_id: str,
    action: str,
    human_summary: str,
    session_id: str | None = None,
    evidence_ref: str | None = None,
) -> dict[str, Any]:
    platform_key = _normalise_platform(platform)
    destination_receipt_id = (destination_receipt_id or "").strip()
    action = (action or "").strip()
    human_summary = (human_summary or "").strip()
    if not destination_receipt_id:
        raise ValueError("destination_receipt_id is required.")
    if not action:
        raise ValueError("action is required.")
    if not human_summary:
        raise ValueError("human_summary is required.")

    state = load_state()
    known_session = None
    if session_id:
        known_session = next((row for row in state.get("browser_assist", []) if row.get("id") == session_id), None)

    record = {
        "id": f"destination-owned-{uuid4().hex[:10]}",
        "platform": platform_key,
        "platform_name": ACCOUNTING_BROWSER_PLATFORMS[platform_key],
        "destination_receipt_id": destination_receipt_id,
        "action": action,
        "human_summary": human_summary,
        "session_id": session_id,
        "session_found": bool(known_session),
        "evidence_ref": evidence_ref,
        "status": "destination_owned_receipt_recorded",
        "receipt_owner": "destination_or_human_operator",
        "finance_suite_external_write": False,
        "finance_suite_provider_called": False,
        "credential_handling": "none",
        "created_at": _now(),
        "boundary": COMPLIANCE_BOUNDARY,
    }
    state.setdefault("destination_receipts", []).insert(0, record)
    save_state(state)
    receipt = create_receipt(
        "browser_assist_destination_owned_receipt",
        f"Recorded destination-owned {ACCOUNTING_BROWSER_PLATFORMS[platform_key]} receipt for {action}.",
        ["finance-browser-assist", "destination-owned-receipt"],
        record,
    )
    record["receipt_id"] = receipt["id"]
    return record


def destination_owned_receipts() -> list[dict[str, Any]]:
    return load_state().get("destination_receipts", [])


def browser_assist_artifacts(session_id: str | None = None) -> list[dict[str, Any]]:
    artifacts = load_state().get("browser_assist_artifacts", [])
    if session_id:
        return [artifact for artifact in artifacts if artifact.get("session_id") == session_id]
    return artifacts


def create_browser_assist_session_artifact(session_id: str) -> dict[str, Any]:
    state = load_state()
    session = next((row for row in state.get("browser_assist", []) if row.get("id") == session_id), None)
    if not session:
        raise ValueError("Unknown browser-assist session_id.")
    artifact = _create_browser_assist_artifact(state, session)
    receipt = create_receipt(
        "browser_assist_session_artifact",
        f"Created Browser Assist session artifact for {session_id}.",
        ["finance-browser-assist-session", session_id],
        {"artifact_id": artifact["id"], "session_id": session_id},
    )
    artifact["receipt_id"] = receipt["id"]
    state = load_state()
    state.setdefault("browser_assist_artifacts", []).insert(0, artifact)
    save_state(state)
    return artifact


def blocked_actions() -> list[dict[str, Any]]:
    return [
        {
            "action": action,
            "state": "blocked_approval_required",
            "reason": reason,
            "external_write": False,
            "safe_local_alternative": "Use manual import, fixture ingestion, local receipt, or report pack export.",
        }
        for action, reason in BLOCKED_ACTIONS.items()
    ]


def external_action_status(action: str) -> dict[str, Any]:
    reason = BLOCKED_ACTIONS.get(action, "Unknown external action; blocked until a specific approved target exists.")
    receipt = create_receipt(
        "blocked_external_action",
        f"{action} blocked by local/internal finance boundary.",
        ["finance-suite-boundary"],
        {"action": action, "reason": reason},
    )
    return {
        "action": action,
        "state": "blocked_approval_required",
        "reason": reason,
        "receipt_id": receipt["id"],
        "external_write": False,
        "provider_called": False,
        "boundary": COMPLIANCE_BOUNDARY,
    }


def ingest_fixture(csv_text: str | None = None, filename: str = "finance-suite-demo.csv") -> dict[str, Any]:
    state = load_state()
    text = csv_text or FIXTURE_CSV
    rows = list(csv.DictReader(io.StringIO(text)))
    if not rows:
        raise ValueError("Fixture import contained no rows.")
    total = 0.0
    payables = 0.0
    receivables = 0.0
    for row in rows:
        amount = float(row.get("amount") or 0)
        total += amount
        if amount < 0:
            payables += abs(amount)
        else:
            receivables += amount
    import_record = {
        "id": f"import-{uuid4().hex[:10]}",
        "filename": filename,
        "rows": rows,
        "row_count": len(rows),
        "receivables": round(receivables, 2),
        "payables": round(payables, 2),
        "net_cash_effect": round(total, 2),
        "source": "manual_fixture_or_upload",
        "synthetic": any(row.get("source") == "synthetic_fixture" for row in rows),
        "created_at": _now(),
    }
    state["imports"].insert(0, import_record)
    state["synthetic_data_present"] = state["synthetic_data_present"] or import_record["synthetic"]
    state["receipts"].insert(
        0,
        {
            "id": f"finance-suite-{uuid4().hex[:12]}",
            "kind": "manual_import",
            "summary": f"Imported {len(rows)} local finance rows from {filename}.",
            "source_refs": [filename],
            "payload": {"import_id": import_record["id"], "row_count": len(rows)},
            "boundary": COMPLIANCE_BOUNDARY,
            "external_write": False,
            "provider_called": False,
            "created_at": _now(),
        },
    )
    save_state(state)
    return import_record


def scenario_run(monthly_revenue: float, monthly_costs: float, cash_on_hand: float, price_change_percent: float = 0.0) -> dict[str, Any]:
    state = load_state()
    adjusted_revenue = monthly_revenue * (1 + price_change_percent / 100)
    burn = monthly_costs - adjusted_revenue
    monthly_margin = adjusted_revenue - monthly_costs
    runway_months = None if burn <= 0 else round(cash_on_hand / burn, 1)
    risk = "watch" if runway_months is None or runway_months >= 9 else "high" if runway_months < 4 else "medium"
    scenario = {
        "id": f"scenario-{uuid4().hex[:10]}",
        "inputs": {
            "monthly_revenue": monthly_revenue,
            "monthly_costs": monthly_costs,
            "cash_on_hand": cash_on_hand,
            "price_change_percent": price_change_percent,
        },
        "outputs": {
            "adjusted_monthly_revenue": round(adjusted_revenue, 2),
            "monthly_margin": round(monthly_margin, 2),
            "burn_rate": round(max(burn, 0), 2),
            "runway_months": runway_months,
            "risk": risk,
            "next_question": "Which assumption is least certain: revenue, costs, collection timing, or price acceptance?",
        },
        "boundary": COMPLIANCE_BOUNDARY,
        "created_at": _now(),
    }
    state["scenarios"].insert(0, scenario)
    save_state(state)
    create_receipt("scenario_generation", "Generated local Fin Strategist scenario.", ["finance-suite-scenario"], {"scenario_id": scenario["id"]})
    return scenario


def create_report_pack(report_type: str = "local_finance_review_pack") -> dict[str, Any]:
    state = load_state()
    latest_import = state.get("imports", [{}])[0] if state.get("imports") else {}
    report = {
        "id": f"report-{uuid4().hex[:10]}",
        "report_type": report_type,
        "title": "AMTL Finance Suite local review pack",
        "sections": ["suite boundary", "Genie lens", "Ledger lens", "Fin Strategist lens", "evidence ledger", "blocked live actions"],
        "latest_import": latest_import,
        "latest_scenario": state.get("scenarios", [{}])[0] if state.get("scenarios") else {},
        "external_send_state": "not_sent",
        "boundary": COMPLIANCE_BOUNDARY,
        "created_at": _now(),
    }
    state["reports"].insert(0, report)
    save_state(state)
    create_receipt("local_report_pack", f"Created {report_type}.", ["finance-suite-report"], {"report_id": report["id"]})
    return report


def _suite_import_fixture_rows(state: dict[str, Any]) -> int:
    return sum(record.get("row_count", 0) for record in state.get("imports", []) if record.get("synthetic"))


def demo_data_status() -> dict[str, Any]:
    state = load_state()
    product_statuses = {product: product_demo_data_status(product) for product in PRODUCTS}
    risk_status = risk_demo_data_status()
    suite_fixture_rows = _suite_import_fixture_rows(state)
    total_fixture_rows = (
        suite_fixture_rows
        + sum(status["fixture_rows"] for status in product_statuses.values())
        + risk_status["fixture_rows"]
    )
    synthetic_present = (
        bool(state.get("synthetic_data_present"))
        or any(status["synthetic_data_present"] for status in product_statuses.values())
        or bool(risk_status["synthetic_data_present"])
    )
    return {
        "demo_organisation": DEMO_ORGANISATION,
        "synthetic_data_present": synthetic_present,
        "synthetic_removed_at": state.get("synthetic_removed_at"),
        "suite_fixture_rows": suite_fixture_rows,
        "fixture_rows": total_fixture_rows,
        "product_statuses": product_statuses,
        "risk_intelligence": risk_status,
        "boundary": "Synthetic rows are labelled and removable across Finance Suite; no fake live data claim is made.",
    }


def remove_synthetic(preview: bool = False) -> dict[str, Any]:
    before = demo_data_status()
    if preview:
        return {"preview": True, "would_remove_fixture_rows": before["fixture_rows"], **before}
    product_results = {
        product: remove_product_synthetic(product, preview=False)
        for product in PRODUCTS
    }
    risk_result = remove_risk_synthetic(preview=False)
    state = load_state()
    state["imports"] = [record for record in state.get("imports", []) if not record.get("synthetic")]
    state["synthetic_data_present"] = False
    state["synthetic_removed_at"] = _now()
    save_state(state)
    receipt = create_receipt(
        "remove_all_synthetic",
        "Removed all labelled Finance Suite synthetic fixture rows across suite, products and Risk Intelligence.",
        ["finance-suite-demo-data", "finance-products-demo-data", "finance-risk-demo-data"],
        {"before_fixture_rows": before["fixture_rows"], "product_receipts": {key: value.get("receipt_id") for key, value in product_results.items()}, "risk_receipt": risk_result.get("receipt_id")},
    )
    return {
        "preview": False,
        "removed_fixture_rows": before["fixture_rows"],
        "receipt_id": receipt["id"],
        "product_results": product_results,
        "risk_result": risk_result,
        **demo_data_status(),
    }


def restore_synthetic() -> dict[str, Any]:
    product_results = {
        product: reload_product_synthetic(product)
        for product in PRODUCTS
    }
    risk_result = reload_risk_synthetic()
    state = load_state()
    state["imports"] = [record for record in state.get("imports", []) if not record.get("synthetic")]
    save_state(state)
    suite_import = ingest_fixture(filename="fat-lady-sang-training-services-synthetic.csv")
    state = load_state()
    state["synthetic_data_present"] = True
    state["synthetic_removed_at"] = None
    save_state(state)
    receipt = create_receipt(
        "restore_all_synthetic",
        "Restored labelled Finance Suite synthetic demo data for Fat Lady Sang training services.",
        ["finance-suite-demo-data", "finance-products-demo-data", "finance-risk-demo-data"],
        {
            "demo_organisation": DEMO_ORGANISATION,
            "suite_import_id": suite_import["id"],
            "product_receipts": {key: value.get("receipt_id") for key, value in product_results.items()},
            "risk_receipt": risk_result.get("receipt_id"),
        },
    )
    return {
        "preview": False,
        "restored": True,
        "receipt_id": receipt["id"],
        "suite_import": suite_import,
        "product_results": product_results,
        "risk_result": risk_result,
        **demo_data_status(),
    }


def receipts() -> list[dict[str, Any]]:
    return load_state().get("receipts", [])


def ai_task_receipts() -> list[dict[str, Any]]:
    return load_state().get("ai_tasks", [])


async def run_app_ai_task(task_requested: str, model_tier: str = "free") -> dict[str, Any]:
    return {"state": "unavailable", "message": "Feature not in this build",
            "output_text": "Feature not in this build", "provider_call_performed": False}
