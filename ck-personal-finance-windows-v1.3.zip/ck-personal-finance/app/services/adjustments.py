# Author: Mani Padisetti
"""Adjustments service — depreciation, prepayments, accruals, provisions."""

from app.database import get_db
from datetime import datetime, timedelta
import calendar


def _get_next_entry_number(conn) -> str:
    row = conn.execute("SELECT value FROM settings WHERE key = 'next_journal_number'").fetchone()
    num = int(row["value"]) if row else 1
    conn.execute(
        "UPDATE settings SET value = ?, updated_at = datetime('now') WHERE key = 'next_journal_number'",
        (str(num + 1),),
    )
    return f"JE-{num:04d}"


def _create_adjusting_journal(conn, date: str, description: str, reference: str,
                               debit_account_id: int, credit_account_id: int,
                               amount: float) -> dict | None:
    """Create an adjusting journal entry. Returns None if already exists (idempotent)."""
    existing = conn.execute(
        "SELECT id FROM journal_entries WHERE reference = ? AND entry_type = 'adjusting'",
        (reference,),
    ).fetchone()
    if existing:
        return None

    entry_number = _get_next_entry_number(conn)
    cursor = conn.execute(
        """INSERT INTO journal_entries (entry_number, date, description, reference, entry_type, source)
        VALUES (?, ?, ?, ?, 'adjusting', 'adjustment')""",
        (entry_number, date, description, reference),
    )
    entry_id = cursor.lastrowid

    conn.execute(
        "INSERT INTO journal_lines (journal_entry_id, account_id, debit, credit) VALUES (?, ?, ?, 0)",
        (entry_id, debit_account_id, round(amount, 2)),
    )
    conn.execute(
        "INSERT INTO journal_lines (journal_entry_id, account_id, debit, credit) VALUES (?, ?, 0, ?)",
        (entry_id, credit_account_id, round(amount, 2)),
    )
    return {"id": entry_id, "entry_number": entry_number, "amount": round(amount, 2)}


def generate_depreciation(schedule_id: int, period_date: str) -> dict:
    """Generate depreciation journal entry for a schedule at a given period."""
    with get_db() as conn:
        schedule = conn.execute(
            "SELECT * FROM depreciation_schedules WHERE id = ?", (schedule_id,)
        ).fetchone()
        if not schedule:
            return {"error": "Schedule not found"}

        depreciable = schedule["cost"] - schedule["residual_value"]
        months = schedule["useful_life_months"]

        if schedule["method"] == "straight_line":
            monthly_amount = depreciable / months
        else:
            # Diminishing value: annual rate = 2 / useful_life_years
            years = months / 12
            annual_rate = min(2 / years, 1.0)
            # Get accumulated depreciation so far
            accum = conn.execute(
                """SELECT COALESCE(SUM(jl.credit), 0) as total
                FROM journal_lines jl
                JOIN journal_entries je ON je.id = jl.journal_entry_id
                WHERE jl.account_id = ? AND je.reference LIKE ?""",
                (schedule["accum_account_id"], f"DEP-{schedule_id}-%"),
            ).fetchone()["total"]
            book_value = schedule["cost"] - accum
            if book_value <= schedule["residual_value"]:
                return {"skipped": True, "reason": "Fully depreciated"}
            monthly_amount = (book_value * annual_rate) / 12
            # Don't depreciate below residual
            if book_value - monthly_amount < schedule["residual_value"]:
                monthly_amount = book_value - schedule["residual_value"]

        reference = f"DEP-{schedule_id}-{period_date[:7]}"
        result = _create_adjusting_journal(
            conn, period_date,
            f"Depreciation: {schedule['description']}",
            reference,
            schedule["expense_account_id"],
            schedule["accum_account_id"],
            round(monthly_amount, 2),
        )
        if result is None:
            return {"skipped": True, "reason": "Already generated", "reference": reference}
        return {"generated": True, **result}


def generate_prepayment(schedule_id: int, period_date: str) -> dict:
    """Generate prepayment amortisation journal entry."""
    with get_db() as conn:
        schedule = conn.execute(
            "SELECT * FROM prepayment_schedules WHERE id = ?", (schedule_id,)
        ).fetchone()
        if not schedule:
            return {"error": "Schedule not found"}

        monthly_amount = schedule["total_amount"] / schedule["periods"]
        reference = f"PRE-{schedule_id}-{period_date[:7]}"

        result = _create_adjusting_journal(
            conn, period_date,
            f"Prepayment amortisation: {schedule['description']}",
            reference,
            schedule["expense_account_id"],
            schedule["prepaid_account_id"],
            round(monthly_amount, 2),
        )
        if result is None:
            return {"skipped": True, "reason": "Already generated", "reference": reference}
        return {"generated": True, **result}


def generate_accrual(accrual_id: int, period_date: str) -> dict:
    """Generate accrual journal entry."""
    with get_db() as conn:
        accrual = conn.execute(
            "SELECT * FROM accruals WHERE id = ?", (accrual_id,)
        ).fetchone()
        if not accrual:
            return {"error": "Accrual not found"}

        reference = f"ACC-{accrual_id}-{period_date[:7]}"
        result = _create_adjusting_journal(
            conn, period_date,
            f"Accrual: {accrual['description']}",
            reference,
            accrual["expense_account_id"],
            accrual["liability_account_id"],
            accrual["amount"],
        )
        if result is None:
            return {"skipped": True, "reason": "Already generated", "reference": reference}
        return {"generated": True, **result}


def generate_provision(provision_id: int, period_date: str) -> dict:
    """Generate provision journal entry."""
    with get_db() as conn:
        provision = conn.execute(
            "SELECT * FROM provisions WHERE id = ?", (provision_id,)
        ).fetchone()
        if not provision:
            return {"error": "Provision not found"}

        reference = f"PROV-{provision_id}-{period_date[:7]}"
        result = _create_adjusting_journal(
            conn, period_date,
            f"Provision: {provision['description']}",
            reference,
            provision["expense_account_id"],
            provision["liability_account_id"],
            provision["amount"],
        )
        if result is None:
            return {"skipped": True, "reason": "Already generated", "reference": reference}
        return {"generated": True, **result}


def generate_all(period_date: str) -> dict:
    """Generate all adjusting entries for a period."""
    results = {"depreciation": [], "prepayments": [], "accruals": [], "provisions": []}

    with get_db() as conn:
        for dep in conn.execute("SELECT id FROM depreciation_schedules WHERE is_active = 1").fetchall():
            results["depreciation"].append(generate_depreciation(dep["id"], period_date))
        for pre in conn.execute("SELECT id FROM prepayment_schedules WHERE is_active = 1").fetchall():
            results["prepayments"].append(generate_prepayment(pre["id"], period_date))
        for acc in conn.execute("SELECT id FROM accruals WHERE is_active = 1").fetchall():
            results["accruals"].append(generate_accrual(acc["id"], period_date))
        for prov in conn.execute("SELECT id FROM provisions WHERE is_active = 1").fetchall():
            results["provisions"].append(generate_provision(prov["id"], period_date))

    total = sum(len(v) for v in results.values())
    generated = sum(
        1 for items in results.values()
        for item in items if item.get("generated")
    )
    return {"period_date": period_date, "total_schedules": total, "generated": generated, "results": results}
