# Author: Mani Padisetti
"""SQLite database connection and schema management."""

import sqlite3
from contextlib import contextmanager
from app.config import DATABASE_PATH, init_data_dir

_db_path = DATABASE_PATH


def set_db_path(path: str):
    global _db_path
    _db_path = path


def get_connection() -> sqlite3.Connection:
    init_data_dir()
    conn = sqlite3.connect(_db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def get_db():
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('asset', 'liability', 'equity', 'revenue', 'cogs', 'expense', 'other_income', 'other_expense')),
    sub_type TEXT,
    description TEXT,
    is_system INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    tax_code TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS financial_periods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    period_type TEXT NOT NULL CHECK(period_type IN ('monthly', 'quarterly', 'yearly')),
    is_closed INTEGER NOT NULL DEFAULT 0,
    closed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    genie_id TEXT UNIQUE,
    date TEXT NOT NULL,
    description TEXT NOT NULL,
    amount REAL NOT NULL,
    balance REAL,
    reference TEXT,
    source TEXT NOT NULL DEFAULT 'genie' CHECK(source IN ('genie', 'manual', 'import', 'adjustment')),
    category TEXT,
    is_reconciled INTEGER NOT NULL DEFAULT 0,
    account_id INTEGER REFERENCES accounts(id),
    bank_account TEXT,
    raw_data TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS journal_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_number TEXT NOT NULL UNIQUE,
    date TEXT NOT NULL,
    description TEXT NOT NULL,
    reference TEXT,
    entry_type TEXT NOT NULL DEFAULT 'standard' CHECK(entry_type IN ('standard', 'adjusting', 'closing', 'reversing', 'opening')),
    source TEXT NOT NULL DEFAULT 'manual' CHECK(source IN ('manual', 'auto', 'genie', 'adjustment', 'depreciation', 'tax')),
    transaction_id INTEGER REFERENCES transactions(id),
    period_id INTEGER REFERENCES financial_periods(id),
    is_posted INTEGER NOT NULL DEFAULT 0,
    posted_at TEXT,
    created_by TEXT NOT NULL DEFAULT 'system',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS journal_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    journal_entry_id INTEGER NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
    account_id INTEGER NOT NULL REFERENCES accounts(id),
    debit REAL NOT NULL DEFAULT 0,
    credit REAL NOT NULL DEFAULT 0,
    description TEXT,
    tax_code TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK(debit >= 0),
    CHECK(credit >= 0),
    CHECK(NOT (debit > 0 AND credit > 0))
);

CREATE TABLE IF NOT EXISTS genie_sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sync_started_at TEXT NOT NULL DEFAULT (datetime('now')),
    sync_completed_at TEXT,
    transactions_fetched INTEGER DEFAULT 0,
    transactions_created INTEGER DEFAULT 0,
    transactions_skipped INTEGER DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running', 'completed', 'failed')),
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_accounts_code ON accounts(code);
CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts(type);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_transactions_genie_id ON transactions(genie_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_date ON journal_entries(date);
CREATE INDEX IF NOT EXISTS idx_journal_entries_number ON journal_entries(entry_number);
CREATE INDEX IF NOT EXISTS idx_journal_lines_entry ON journal_lines(journal_entry_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_account ON journal_lines(account_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_posted_date ON journal_entries(is_posted, date);

CREATE TABLE IF NOT EXISTS depreciation_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_account_id INTEGER NOT NULL REFERENCES accounts(id),
    accum_account_id INTEGER NOT NULL REFERENCES accounts(id),
    expense_account_id INTEGER NOT NULL REFERENCES accounts(id),
    description TEXT NOT NULL,
    cost REAL NOT NULL,
    residual_value REAL NOT NULL DEFAULT 0,
    useful_life_months INTEGER NOT NULL,
    method TEXT NOT NULL DEFAULT 'straight_line' CHECK(method IN ('straight_line', 'diminishing_value')),
    start_date TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS prepayment_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prepaid_account_id INTEGER NOT NULL REFERENCES accounts(id),
    expense_account_id INTEGER NOT NULL REFERENCES accounts(id),
    description TEXT NOT NULL,
    total_amount REAL NOT NULL,
    periods INTEGER NOT NULL,
    start_date TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS accruals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_account_id INTEGER NOT NULL REFERENCES accounts(id),
    liability_account_id INTEGER NOT NULL REFERENCES accounts(id),
    description TEXT NOT NULL,
    amount REAL NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'monthly' CHECK(frequency IN ('monthly', 'quarterly', 'yearly')),
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS gst_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id INTEGER REFERENCES transactions(id),
    journal_entry_id INTEGER REFERENCES journal_entries(id),
    gst_type TEXT NOT NULL CHECK(gst_type IN ('collected', 'paid')),
    gross_amount REAL NOT NULL,
    gst_amount REAL NOT NULL,
    net_amount REAL NOT NULL,
    bas_period TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bas_lodgements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period TEXT NOT NULL,
    quarter TEXT NOT NULL,
    financial_year INTEGER NOT NULL,
    label_1a REAL NOT NULL DEFAULT 0,
    label_1b REAL NOT NULL DEFAULT 0,
    label_w1 REAL NOT NULL DEFAULT 0,
    label_w2 REAL NOT NULL DEFAULT 0,
    gst_payable REAL NOT NULL DEFAULT 0,
    payg_withheld REAL NOT NULL DEFAULT 0,
    total_payable REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'lodged', 'paid')),
    lodged_at TEXT,
    paid_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fbt_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT NOT NULL,
    fbt_type TEXT NOT NULL,
    taxable_value REAL NOT NULL,
    fbt_year TEXT NOT NULL,
    employee_name TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS super_obligations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_name TEXT NOT NULL,
    quarter TEXT NOT NULL,
    ordinary_earnings REAL NOT NULL,
    super_rate REAL NOT NULL DEFAULT 0.115,
    super_amount REAL NOT NULL,
    due_date TEXT NOT NULL,
    paid_date TEXT,
    status TEXT NOT NULL DEFAULT 'owing' CHECK(status IN ('owing', 'paid')),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS payg_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_name TEXT NOT NULL,
    period TEXT NOT NULL,
    gross_pay REAL NOT NULL,
    tax_withheld REAL NOT NULL,
    net_pay REAL NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    financial_year INTEGER NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS budget_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    budget_id INTEGER NOT NULL REFERENCES budgets(id) ON DELETE CASCADE,
    account_id INTEGER NOT NULL REFERENCES accounts(id),
    month TEXT NOT NULL,
    amount REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS mapping_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern TEXT NOT NULL,
    account_id INTEGER NOT NULL REFERENCES accounts(id),
    category TEXT,
    priority INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS import_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    file_type TEXT NOT NULL DEFAULT 'csv' CHECK(file_type IN ('csv', 'ofx')),
    total_rows INTEGER NOT NULL DEFAULT 0,
    imported INTEGER NOT NULL DEFAULT 0,
    skipped INTEGER NOT NULL DEFAULT 0,
    duplicates INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'preview' CHECK(status IN ('preview', 'confirmed', 'cancelled')),
    preview_data TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    confirmed_at TEXT
);

CREATE TABLE IF NOT EXISTS provisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_account_id INTEGER NOT NULL REFERENCES accounts(id),
    liability_account_id INTEGER NOT NULL REFERENCES accounts(id),
    description TEXT NOT NULL,
    amount REAL NOT NULL,
    review_date TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    detail TEXT,
    user TEXT NOT NULL DEFAULT 'system',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at);
"""

DEFAULT_ACCOUNTS = [
    ("1000", "Cash at Bank", "asset", "current_asset", "Primary business bank account", 1),
    ("1010", "Petty Cash", "asset", "current_asset", "Cash on hand", 1),
    ("1100", "Accounts Receivable", "asset", "current_asset", "Money owed by customers", 1),
    ("1150", "Allowance for Doubtful Debts", "asset", "current_asset", "Provision for bad debts", 1),
    ("1200", "Prepaid Expenses", "asset", "current_asset", "Expenses paid in advance", 1),
    ("1300", "Inventory", "asset", "current_asset", "Stock on hand", 0),
    ("1400", "GST Receivable", "asset", "current_asset", "GST paid on purchases (BAS credit)", 1),
    ("1500", "Office Equipment", "asset", "fixed_asset", "Computers, furniture, fittings", 0),
    ("1510", "Accum. Depreciation â€” Office Equipment", "asset", "fixed_asset", "Accumulated depreciation", 0),
    ("1600", "Motor Vehicles", "asset", "fixed_asset", "Business vehicles", 0),
    ("1610", "Accum. Depreciation â€” Motor Vehicles", "asset", "fixed_asset", "Accumulated depreciation", 0),
    ("1700", "Plant & Equipment", "asset", "fixed_asset", "Machinery and plant", 0),
    ("1710", "Accum. Depreciation â€” Plant & Equipment", "asset", "fixed_asset", "Accumulated depreciation", 0),
    ("2000", "Accounts Payable", "liability", "current_liability", "Money owed to suppliers", 1),
    ("2100", "GST Payable", "liability", "current_liability", "GST collected on sales (BAS liability)", 1),
    ("2200", "PAYG Withholding Payable", "liability", "current_liability", "Employee tax withheld", 1),
    ("2300", "Superannuation Payable", "liability", "current_liability", "Super guarantee owing", 1),
    ("2400", "Income Tax Payable", "liability", "current_liability", "Provision for income tax", 1),
    ("2500", "Wages Payable", "liability", "current_liability", "Accrued wages", 1),
    ("2600", "Credit Card", "liability", "current_liability", "Business credit card balance", 0),
    ("2700", "Loan â€” Short Term", "liability", "current_liability", "Loans due within 12 months", 0),
    ("2800", "Loan â€” Long Term", "liability", "non_current_liability", "Loans due after 12 months", 0),
    ("3000", "Owner's Equity", "equity", "owners_equity", "Capital contributed by owner", 1),
    ("3100", "Retained Earnings", "equity", "retained_earnings", "Accumulated profits/losses", 1),
    ("3200", "Drawings", "equity", "drawings", "Owner withdrawals", 1),
    ("3300", "Current Year Earnings", "equity", "current_earnings", "Profit/loss for current period", 1),
    ("4000", "Sales Revenue", "revenue", "operating", "Income from core business", 1),
    ("4100", "Service Revenue", "revenue", "operating", "Income from services rendered", 1),
    ("4200", "Interest Income", "other_income", "interest", "Bank interest earned", 1),
    ("4300", "Other Income", "other_income", "other", "Miscellaneous income", 1),
    ("5000", "Cost of Goods Sold", "cogs", "direct", "Direct cost of products sold", 1),
    ("5100", "Direct Labour", "cogs", "direct", "Wages for production staff", 0),
    ("5200", "Subcontractor Costs", "cogs", "direct", "Outsourced work costs", 0),
    ("6000", "Accounting & Legal", "expense", "admin", "Professional services", 1),
    ("6050", "Advertising & Marketing", "expense", "admin", "Promotional expenses", 1),
    ("6100", "Bank Fees & Charges", "expense", "admin", "Banking costs", 1),
    ("6150", "Computer & IT Expenses", "expense", "admin", "Software, hosting, tech", 1),
    ("6200", "Depreciation Expense", "expense", "depreciation", "Asset depreciation", 1),
    ("6250", "Electricity & Gas", "expense", "premises", "Utility costs", 1),
    ("6300", "Insurance", "expense", "admin", "Business insurance premiums", 1),
    ("6350", "Interest Expense", "expense", "finance", "Loan interest charges", 0),
    ("6400", "Motor Vehicle Expenses", "expense", "transport", "Fuel, rego, maintenance", 0),
    ("6450", "Office Supplies", "expense", "admin", "Stationery, consumables", 1),
    ("6500", "Postage & Freight", "expense", "admin", "Shipping and postal", 0),
    ("6550", "Printing & Stationery", "expense", "admin", "Print costs", 0),
    ("6600", "Rent", "expense", "premises", "Office/premises lease", 0),
    ("6650", "Repairs & Maintenance", "expense", "premises", "Building and equipment repairs", 0),
    ("6700", "Subscriptions & Memberships", "expense", "admin", "Industry memberships", 1),
    ("6750", "Superannuation Expense", "expense", "employment", "Super guarantee contributions", 1),
    ("6800", "Telephone & Internet", "expense", "admin", "Communications", 1),
    ("6850", "Travel & Accommodation", "expense", "travel", "Business travel", 0),
    ("6900", "Wages & Salaries", "expense", "employment", "Employee remuneration", 1),
    ("6950", "Workers Compensation", "expense", "employment", "WorkCover premiums", 0),
    ("8000", "Bad Debts", "other_expense", "other", "Irrecoverable debts written off", 0),
    ("8100", "Donations", "other_expense", "other", "Charitable donations", 0),
    ("8200", "Fines & Penalties", "other_expense", "other", "Regulatory fines", 0),
]

DEFAULT_SETTINGS = [
    ("business_name", "Almost Magic Tech Lab"),
    ("abn", ""),
    ("financial_year_start", "07"),
    ("gst_registered", "true"),
    ("gst_method", "accrual"),
    ("bas_frequency", "quarterly"),
    ("base_currency", "AUD"),
    ("next_journal_number", "1"),
]


def log_audit(action: str, entity_type: str, entity_id: int | None = None,
              detail: str | None = None, user: str = "system"):
    """Write an entry to the audit log."""
    with get_db() as conn:
        conn.execute(
            "INSERT INTO audit_log (action, entity_type, entity_id, detail, user) VALUES (?, ?, ?, ?, ?)",
            (action, entity_type, entity_id, detail, user),
        )


def init_db():
    with get_db() as conn:
        conn.executescript(SCHEMA)
        existing = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        if existing == 0:
            conn.executemany(
                "INSERT INTO accounts (code, name, type, sub_type, description, is_system) VALUES (?, ?, ?, ?, ?, ?)",
                DEFAULT_ACCOUNTS,
            )
        for key, value in DEFAULT_SETTINGS:
            conn.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value),
            )