# Author: Mani Padisetti
"""Pydantic models for financial reports and periods."""

from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class PeriodType(str, Enum):
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    YEARLY = "yearly"


class PeriodCreate(BaseModel):
    name: str = Field(..., min_length=1)
    start_date: str
    end_date: str
    period_type: PeriodType


class PeriodUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1)


class ReportFormat(str, Enum):
    JSON = "json"
    CSV = "csv"
    PDF = "pdf"
    EXCEL = "excel"
