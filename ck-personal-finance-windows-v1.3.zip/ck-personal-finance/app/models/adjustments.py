# Author: Mani Padisetti
"""Pydantic models for accruals and adjustments."""

from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class DepreciationMethod(str, Enum):
    STRAIGHT_LINE = "straight_line"
    DIMINISHING_VALUE = "diminishing_value"


class DepreciationCreate(BaseModel):
    asset_account_id: int
    accum_account_id: int
    expense_account_id: int
    description: str = Field(..., min_length=1)
    cost: float = Field(..., gt=0)
    residual_value: float = Field(default=0, ge=0)
    useful_life_months: int = Field(..., gt=0)
    method: DepreciationMethod = DepreciationMethod.STRAIGHT_LINE
    start_date: str


class PrepaymentCreate(BaseModel):
    prepaid_account_id: int
    expense_account_id: int
    description: str = Field(..., min_length=1)
    total_amount: float = Field(..., gt=0)
    periods: int = Field(..., gt=0)
    start_date: str


class AccrualCreate(BaseModel):
    expense_account_id: int
    liability_account_id: int
    description: str = Field(..., min_length=1)
    amount: float = Field(..., gt=0)
    frequency: str = "monthly"


class ProvisionCreate(BaseModel):
    expense_account_id: int
    liability_account_id: int
    description: str = Field(..., min_length=1)
    amount: float = Field(..., gt=0)
    review_date: Optional[str] = None
