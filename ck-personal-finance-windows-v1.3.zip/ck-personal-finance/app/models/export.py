# Author: Mani Padisetti
"""Pydantic models for compliance and export."""

from pydantic import BaseModel, Field
from typing import Optional


class ReportExportRequest(BaseModel):
    report_type: str = Field(..., description="trial_balance, profit_and_loss, balance_sheet, cash_flow")
    format: str = Field("csv", description="csv, pdf, excel")
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    as_at_date: Optional[str] = None


class AccountantPackRequest(BaseModel):
    financial_year: int
    formats: list[str] = Field(default=["csv"])
