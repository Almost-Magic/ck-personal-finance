# Author: Mani Padisetti
"""Pydantic models for analytics and reporting."""

from pydantic import BaseModel, Field
from typing import Optional


class BudgetCreate(BaseModel):
    name: str = Field(..., min_length=1)
    financial_year: int
    description: Optional[str] = None


class BudgetLineCreate(BaseModel):
    account_id: int
    month: str  # YYYY-MM
    amount: float


class NLQueryRequest(BaseModel):
    query: str = Field(..., min_length=1)
