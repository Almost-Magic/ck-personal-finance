# Author: Mani Padisetti
"""Pydantic models for narrative intelligence."""

from pydantic import BaseModel, Field
from typing import Optional


class CommentaryRequest(BaseModel):
    report_type: str = Field(..., description="trial_balance, profit_and_loss, balance_sheet, cash_flow")
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    as_at_date: Optional[str] = None


class VarianceRequest(BaseModel):
    from_date_1: str
    to_date_1: str
    from_date_2: str
    to_date_2: str


class AnomalyRequest(BaseModel):
    from_date: str
    to_date: str
    threshold: float = Field(default=2.0, description="Multiplier for spike detection")
