# Author: Mani Padisetti
"""Pydantic models for Chart of Accounts."""

from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class AccountType(str, Enum):
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    COGS = "cogs"
    EXPENSE = "expense"
    OTHER_INCOME = "other_income"
    OTHER_EXPENSE = "other_expense"


class AccountCreate(BaseModel):
    code: str = Field(..., min_length=1, max_length=10)
    name: str = Field(..., min_length=1, max_length=200)
    type: AccountType
    sub_type: Optional[str] = None
    description: Optional[str] = None
    tax_code: Optional[str] = None


class AccountUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    sub_type: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    tax_code: Optional[str] = None
