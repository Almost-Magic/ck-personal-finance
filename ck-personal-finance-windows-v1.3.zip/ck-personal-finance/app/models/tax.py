# Author: Mani Padisetti
"""Pydantic models for tax engine."""

from pydantic import BaseModel, Field
from typing import Optional


class GSTEntryCreate(BaseModel):
    transaction_id: Optional[int] = None
    journal_entry_id: Optional[int] = None
    gst_type: str  # 'collected' or 'paid'
    gross_amount: float
    gst_amount: float
    net_amount: float
    bas_period: Optional[str] = None


class FBTItemCreate(BaseModel):
    description: str = Field(..., min_length=1)
    fbt_type: str = Field(..., min_length=1)
    taxable_value: float = Field(..., gt=0)
    fbt_year: str
    employee_name: Optional[str] = None


class SuperObligationCreate(BaseModel):
    employee_name: str = Field(..., min_length=1)
    quarter: str
    ordinary_earnings: float = Field(..., gt=0)
    super_rate: float = Field(default=0.115)
    due_date: str


class PAYGEntryCreate(BaseModel):
    employee_name: str = Field(..., min_length=1)
    period: str
    gross_pay: float = Field(..., gt=0)
    tax_withheld: float = Field(..., ge=0)
