# Author: Mani Padisetti
"""Pydantic models for transactions and journal entries."""

from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class TransactionSource(str, Enum):
    GENIE = "genie"
    MANUAL = "manual"
    IMPORT = "import"
    ADJUSTMENT = "adjustment"


class TransactionCreate(BaseModel):
    date: str
    description: str = Field(..., min_length=1)
    amount: float
    balance: Optional[float] = None
    reference: Optional[str] = None
    source: TransactionSource = TransactionSource.MANUAL
    category: Optional[str] = None
    account_id: Optional[int] = None
    bank_account: Optional[str] = None


class TransactionUpdate(BaseModel):
    description: Optional[str] = Field(None, min_length=1)
    category: Optional[str] = None
    account_id: Optional[int] = None
    is_reconciled: Optional[bool] = None


class JournalEntryType(str, Enum):
    STANDARD = "standard"
    ADJUSTING = "adjusting"
    CLOSING = "closing"
    REVERSING = "reversing"
    OPENING = "opening"


class JournalLineCreate(BaseModel):
    account_id: int
    debit: float = Field(default=0, ge=0)
    credit: float = Field(default=0, ge=0)
    description: Optional[str] = None
    tax_code: Optional[str] = None


class JournalEntryCreate(BaseModel):
    date: str
    description: str = Field(..., min_length=1)
    reference: Optional[str] = None
    entry_type: JournalEntryType = JournalEntryType.STANDARD
    lines: list[JournalLineCreate] = Field(..., min_length=2)
