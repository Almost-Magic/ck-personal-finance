# Author: Mani Padisetti
"""Pydantic models for import engine."""

from pydantic import BaseModel, Field
from typing import Optional


class MappingRuleCreate(BaseModel):
    pattern: str = Field(..., min_length=1)
    account_id: int
    category: Optional[str] = None
    priority: int = 0


class MappingRuleUpdate(BaseModel):
    pattern: Optional[str] = None
    account_id: Optional[int] = None
    category: Optional[str] = None
    priority: Optional[int] = None
    is_active: Optional[bool] = None


class CategoriseRequest(BaseModel):
    descriptions: list[str]
