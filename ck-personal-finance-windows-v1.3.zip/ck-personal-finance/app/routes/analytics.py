# Author: Mani Padisetti
"""Analytics routes — trends, ledger, ageing, budgets, NL queries."""

from fastapi import APIRouter, HTTPException, Query
from app.database import get_db
from app.models.analytics import BudgetCreate, BudgetLineCreate, NLQueryRequest
from app.services.analytics import (
    monthly_trends, quarterly_trends, account_ledger,
    aged_receivables, aged_payables, budget_vs_actual, nl_query,
)

router = APIRouter(prefix="/analytics", tags=["analytics"])


# --- Trends ---

@router.get("/trends/monthly")
async def get_monthly_trends(
    from_date: str = Query(...),
    to_date: str = Query(...),
):
    return monthly_trends(from_date, to_date)


@router.get("/trends/quarterly")
async def get_quarterly_trends(
    from_date: str = Query(...),
    to_date: str = Query(...),
):
    return quarterly_trends(from_date, to_date)


# --- Account Ledger ---

@router.get("/ledger/{account_id}")
async def get_account_ledger(
    account_id: int,
    from_date: str | None = None,
    to_date: str | None = None,
):
    result = account_ledger(account_id, from_date=from_date, to_date=to_date)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Ageing ---

@router.get("/aged-receivables")
async def get_aged_receivables(as_at_date: str = Query(...)):
    return aged_receivables(as_at_date)


@router.get("/aged-payables")
async def get_aged_payables(as_at_date: str = Query(...)):
    return aged_payables(as_at_date)


# --- Budgets ---

@router.get("/budgets")
async def list_budgets():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM budgets ORDER BY financial_year DESC, id").fetchall()
        return [dict(r) for r in rows]


@router.post("/budgets", status_code=201)
async def create_budget(budget: BudgetCreate):
    with get_db() as conn:
        cursor = conn.execute(
            "INSERT INTO budgets (name, financial_year, description) VALUES (?, ?, ?)",
            (budget.name, budget.financial_year, budget.description),
        )
        row = conn.execute("SELECT * FROM budgets WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/budgets/{budget_id}")
async def get_budget(budget_id: int):
    with get_db() as conn:
        budget = conn.execute("SELECT * FROM budgets WHERE id = ?", (budget_id,)).fetchone()
        if not budget:
            raise HTTPException(status_code=404, detail="Budget not found")
        lines = conn.execute("""
            SELECT bl.*, a.code, a.name as account_name
            FROM budget_lines bl
            JOIN accounts a ON a.id = bl.account_id
            WHERE bl.budget_id = ?
            ORDER BY bl.month, a.code
        """, (budget_id,)).fetchall()
        result = dict(budget)
        result["lines"] = [dict(l) for l in lines]
        return result


@router.post("/budgets/{budget_id}/lines", status_code=201)
async def add_budget_line(budget_id: int, line: BudgetLineCreate):
    with get_db() as conn:
        budget = conn.execute("SELECT id FROM budgets WHERE id = ?", (budget_id,)).fetchone()
        if not budget:
            raise HTTPException(status_code=404, detail="Budget not found")
        cursor = conn.execute(
            "INSERT INTO budget_lines (budget_id, account_id, month, amount) VALUES (?, ?, ?, ?)",
            (budget_id, line.account_id, line.month, line.amount),
        )
        row = conn.execute("SELECT * FROM budget_lines WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.delete("/budgets/{budget_id}")
async def delete_budget(budget_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM budgets WHERE id = ?", (budget_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Budget not found")
        conn.execute("DELETE FROM budgets WHERE id = ?", (budget_id,))
        return {"deleted": True, "id": budget_id}


@router.get("/budgets/{budget_id}/vs-actual")
async def get_budget_vs_actual(budget_id: int):
    result = budget_vs_actual(budget_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Natural Language Queries ---

@router.post("/query")
async def natural_language_query(req: NLQueryRequest):
    return await nl_query(req.query)
