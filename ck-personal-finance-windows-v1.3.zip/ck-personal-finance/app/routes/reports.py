# Author: Mani Padisetti
"""Financial report routes — Trial Balance, P&L, Balance Sheet, Cash Flow."""

from fastapi import APIRouter, HTTPException, Query
from app.services.reports import trial_balance, profit_and_loss, balance_sheet, cash_flow

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("/trial-balance")
async def get_trial_balance(
    from_date: str | None = None,
    to_date: str | None = None,
):
    return trial_balance(from_date=from_date, to_date=to_date)


@router.get("/profit-and-loss")
async def get_profit_and_loss(
    from_date: str = Query(..., description="Start date YYYY-MM-DD"),
    to_date: str = Query(..., description="End date YYYY-MM-DD"),
):
    return profit_and_loss(from_date=from_date, to_date=to_date)


@router.get("/balance-sheet")
async def get_balance_sheet(
    as_at_date: str = Query(..., description="As at date YYYY-MM-DD"),
):
    return balance_sheet(as_at_date=as_at_date)


@router.get("/cash-flow")
async def get_cash_flow(
    from_date: str = Query(..., description="Start date YYYY-MM-DD"),
    to_date: str = Query(..., description="End date YYYY-MM-DD"),
):
    return cash_flow(from_date=from_date, to_date=to_date)
