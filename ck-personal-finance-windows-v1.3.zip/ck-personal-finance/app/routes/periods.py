# Author: Mani Padisetti
"""Financial period routes — CRUD, close, and auto-generate."""

from fastapi import APIRouter, HTTPException
from app.database import get_db
from app.models.reports import PeriodCreate, PeriodUpdate
from app.services.reports import generate_periods

router = APIRouter(prefix="/periods", tags=["periods"])


@router.get("")
async def list_periods():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM financial_periods ORDER BY start_date"
        ).fetchall()
        return [dict(r) for r in rows]


@router.get("/{period_id}")
async def get_period(period_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Period not found")
        return dict(row)


@router.post("", status_code=201)
async def create_period(period: PeriodCreate):
    with get_db() as conn:
        overlap = conn.execute(
            """SELECT id FROM financial_periods
            WHERE start_date <= ? AND end_date >= ?""",
            (period.end_date, period.start_date),
        ).fetchone()
        if overlap:
            raise HTTPException(status_code=409, detail="Period overlaps with existing period")
        cursor = conn.execute(
            """INSERT INTO financial_periods (name, start_date, end_date, period_type)
            VALUES (?, ?, ?, ?)""",
            (period.name, period.start_date, period.end_date, period.period_type.value),
        )
        row = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.put("/{period_id}")
async def update_period(period_id: int, period: PeriodUpdate):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Period not found")
        if existing["is_closed"]:
            raise HTTPException(status_code=400, detail="Cannot update a closed period")
        if period.name is not None:
            conn.execute("UPDATE financial_periods SET name = ? WHERE id = ?", (period.name, period_id))
        row = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        return dict(row)


@router.post("/{period_id}/close")
async def close_period(period_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Period not found")
        if existing["is_closed"]:
            raise HTTPException(status_code=400, detail="Period is already closed")
        conn.execute(
            "UPDATE financial_periods SET is_closed = 1, closed_at = datetime('now') WHERE id = ?",
            (period_id,),
        )
        row = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        return dict(row)


@router.delete("/{period_id}")
async def delete_period(period_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM financial_periods WHERE id = ?", (period_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Period not found")
        if existing["is_closed"]:
            raise HTTPException(status_code=400, detail="Cannot delete a closed period")
        in_use = conn.execute(
            "SELECT COUNT(*) FROM journal_entries WHERE period_id = ?", (period_id,)
        ).fetchone()[0]
        if in_use > 0:
            raise HTTPException(status_code=400, detail="Cannot delete period with journal entries")
        conn.execute("DELETE FROM financial_periods WHERE id = ?", (period_id,))
        return {"deleted": True, "id": period_id}


@router.post("/generate/{financial_year}")
async def generate_fy_periods(financial_year: int):
    periods = generate_periods(financial_year)
    return {"financial_year": financial_year, "periods": periods}
