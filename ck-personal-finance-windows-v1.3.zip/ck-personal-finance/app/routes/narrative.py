# Author: Mani Padisetti
"""Narrative intelligence routes — AI commentary, variance, anomalies."""

from fastapi import APIRouter, HTTPException
from app.models.narrative import CommentaryRequest, VarianceRequest, AnomalyRequest
from app.services.narrative import (
    generate_commentary, variance_analysis, detect_anomalies, financial_summary,
)

router = APIRouter(prefix="/narrative", tags=["narrative"])


@router.post("/commentary")
async def commentary(req: CommentaryRequest):
    result = await generate_commentary(
        report_type=req.report_type,
        from_date=req.from_date,
        to_date=req.to_date,
        as_at_date=req.as_at_date,
    )
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/variance")
async def variance(req: VarianceRequest):
    return await variance_analysis(
        req.from_date_1, req.to_date_1,
        req.from_date_2, req.to_date_2,
    )


@router.post("/anomalies")
async def anomalies(req: AnomalyRequest):
    return detect_anomalies(req.from_date, req.to_date, req.threshold)


@router.get("/summary")
async def summary():
    return await financial_summary()
