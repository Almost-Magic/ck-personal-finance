# Author: Mani Padisetti
"""Export routes — report export, accountant pack, audit trail, compliance."""

import base64
from fastapi import APIRouter, Query
from fastapi.responses import Response
from app.database import log_audit
from app.models.export import ReportExportRequest, AccountantPackRequest
from app.services.export import generate_report, accountant_pack, get_audit_trail, compliance_checklist

router = APIRouter(prefix="/export", tags=["export"])


@router.post("/report")
async def export_report(req: ReportExportRequest):
    result = generate_report(
        report_type=req.report_type,
        fmt=req.format,
        from_date=req.from_date,
        to_date=req.to_date,
        as_at_date=req.as_at_date,
    )
    if "error" in result:
        return {"status": 400, "error": result["error"]}

    log_audit("export", "report", detail=f"{req.report_type} as {req.format}")

    if req.format in ("pdf", "excel"):
        # Return binary content as base64 for JSON response
        return {
            "filename": result["filename"],
            "format": result["format"],
            "content_type": result["content_type"],
            "size": result["size"],
            "content_base64": base64.b64encode(result["content"]).decode("ascii"),
        }
    elif req.format == "csv":
        return {
            "filename": result["filename"],
            "format": "csv",
            "content_type": "text/csv",
            "content": result["content"],
        }
    else:
        return {
            "report": result.get("report", result),
            "format": result.get("format", "json"),
        }


@router.post("/report/download")
async def download_report(req: ReportExportRequest):
    """Download a report as a file (binary response)."""
    result = generate_report(
        report_type=req.report_type,
        fmt=req.format,
        from_date=req.from_date,
        to_date=req.to_date,
        as_at_date=req.as_at_date,
    )
    if "error" in result:
        return {"status": 400, "error": result["error"]}

    if req.format == "csv":
        return Response(
            content=result["content"],
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={result['filename']}"},
        )
    elif req.format == "pdf":
        return Response(
            content=result["content"],
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={result['filename']}"},
        )
    elif req.format == "excel":
        return Response(
            content=result["content"],
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={result['filename']}"},
        )
    return result.get("report", result)


@router.post("/accountant-pack")
async def create_accountant_pack(req: AccountantPackRequest):
    result = accountant_pack(req.financial_year, req.formats)
    log_audit("export", "accountant_pack", detail=f"FY{req.financial_year}")

    return {
        "filename": result["filename"],
        "size": result["size"],
        "reports_included": result["reports_included"],
        "formats": result["formats"],
        "financial_year": result["financial_year"],
        "content_base64": base64.b64encode(result["content"]).decode("ascii"),
    }


@router.get("/audit-trail")
async def audit_trail(
    entity_type: str | None = None,
    entity_id: int | None = None,
    action: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = Query(default=100, le=1000),
):
    return get_audit_trail(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        from_date=from_date,
        to_date=to_date,
        limit=limit,
    )


@router.get("/compliance/checklist")
async def get_compliance_checklist(financial_year: int = Query(...)):
    return compliance_checklist(financial_year)
