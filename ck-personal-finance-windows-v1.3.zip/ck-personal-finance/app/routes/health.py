# Author: Mani Padisetti
"""Health and status endpoints."""

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    return {"status": "healthy", "version": "1.0.0", "name": "The Ledger"}
