# Author: Mani Padisetti
"""Journal entry routes — double-entry bookkeeping."""

from fastapi import APIRouter, HTTPException, Query
from app.database import get_db
from app.models.transactions import JournalEntryCreate

router = APIRouter(prefix="/journals", tags=["journals"])


def _get_next_entry_number(conn) -> str:
    row = conn.execute("SELECT value FROM settings WHERE key = 'next_journal_number'").fetchone()
    num = int(row["value"]) if row else 1
    conn.execute(
        "UPDATE settings SET value = ?, updated_at = datetime('now') WHERE key = 'next_journal_number'",
        (str(num + 1),),
    )
    return f"JE-{num:04d}"


def _format_entry(conn, entry_id: int) -> dict:
    entry = conn.execute("SELECT * FROM journal_entries WHERE id = ?", (entry_id,)).fetchone()
    if not entry:
        return None
    result = dict(entry)
    lines = conn.execute(
        """SELECT jl.*, a.code as account_code, a.name as account_name, a.type as account_type
        FROM journal_lines jl
        JOIN accounts a ON a.id = jl.account_id
        WHERE jl.journal_entry_id = ?
        ORDER BY jl.id""",
        (entry_id,),
    ).fetchall()
    result["lines"] = [dict(l) for l in lines]
    result["total_debits"] = round(sum(l["debit"] for l in lines), 2)
    result["total_credits"] = round(sum(l["credit"] for l in lines), 2)
    return result


@router.get("")
async def list_journals(
    entry_type: str | None = None, is_posted: bool | None = None,
    from_date: str | None = None, to_date: str | None = None,
    page: int = Query(default=1, ge=1), limit: int = Query(default=50, ge=1, le=500),
):
    with get_db() as conn:
        query = "SELECT * FROM journal_entries WHERE 1=1"
        count_query = "SELECT COUNT(*) FROM journal_entries WHERE 1=1"
        params = []
        if entry_type:
            query += " AND entry_type = ?"
            count_query += " AND entry_type = ?"
            params.append(entry_type)
        if is_posted is not None:
            query += " AND is_posted = ?"
            count_query += " AND is_posted = ?"
            params.append(1 if is_posted else 0)
        if from_date:
            query += " AND date >= ?"
            count_query += " AND date >= ?"
            params.append(from_date)
        if to_date:
            query += " AND date <= ?"
            count_query += " AND date <= ?"
            params.append(to_date)
        total = conn.execute(count_query, params).fetchone()[0]
        query += " ORDER BY date DESC, id DESC"
        offset = (page - 1) * limit
        query += " LIMIT ? OFFSET ?"
        rows = conn.execute(query, params + [limit, offset]).fetchall()
        entries = []
        for row in rows:
            entries.append(_format_entry(conn, row["id"]))
        return {"entries": entries, "total": total, "page": page, "limit": limit}


@router.get("/stats")
async def journal_stats():
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM journal_entries").fetchone()[0]
        posted = conn.execute("SELECT COUNT(*) FROM journal_entries WHERE is_posted = 1").fetchone()[0]
        draft = total - posted
        by_type = conn.execute(
            "SELECT entry_type, COUNT(*) as count FROM journal_entries GROUP BY entry_type"
        ).fetchall()
        return {
            "total": total, "posted": posted, "draft": draft,
            "by_type": {r["entry_type"]: r["count"] for r in by_type},
        }


@router.get("/{entry_id}")
async def get_journal(entry_id: int):
    with get_db() as conn:
        result = _format_entry(conn, entry_id)
        if not result:
            raise HTTPException(status_code=404, detail="Journal entry not found")
        return result


@router.post("", status_code=201)
async def create_journal(entry: JournalEntryCreate):
    total_debits = round(sum(l.debit for l in entry.lines), 2)
    total_credits = round(sum(l.credit for l in entry.lines), 2)

    if total_debits == 0 and total_credits == 0:
        raise HTTPException(status_code=400, detail="Journal entry cannot have all zero amounts")

    if total_debits != total_credits:
        raise HTTPException(
            status_code=400,
            detail=f"Debits ({total_debits}) must equal Credits ({total_credits})",
        )

    for line in entry.lines:
        if line.debit > 0 and line.credit > 0:
            raise HTTPException(
                status_code=400,
                detail="A journal line cannot have both debit and credit amounts",
            )

    with get_db() as conn:
        for line in entry.lines:
            account = conn.execute("SELECT id FROM accounts WHERE id = ?", (line.account_id,)).fetchone()
            if not account:
                raise HTTPException(status_code=400, detail=f"Account {line.account_id} not found")

        entry_number = _get_next_entry_number(conn)
        cursor = conn.execute(
            """INSERT INTO journal_entries (entry_number, date, description, reference, entry_type, source)
            VALUES (?, ?, ?, ?, ?, 'manual')""",
            (entry_number, entry.date, entry.description, entry.reference, entry.entry_type.value),
        )
        entry_id = cursor.lastrowid

        for line in entry.lines:
            conn.execute(
                """INSERT INTO journal_lines (journal_entry_id, account_id, debit, credit, description, tax_code)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (entry_id, line.account_id, line.debit, line.credit, line.description, line.tax_code),
            )

        return _format_entry(conn, entry_id)


@router.post("/{entry_id}/post")
async def post_journal(entry_id: int):
    with get_db() as conn:
        entry = conn.execute("SELECT * FROM journal_entries WHERE id = ?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(status_code=404, detail="Journal entry not found")
        if entry["is_posted"]:
            raise HTTPException(status_code=400, detail="Journal entry is already posted")
        conn.execute(
            "UPDATE journal_entries SET is_posted = 1, posted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?",
            (entry_id,),
        )
        return _format_entry(conn, entry_id)


@router.delete("/{entry_id}")
async def delete_journal(entry_id: int):
    with get_db() as conn:
        entry = conn.execute("SELECT * FROM journal_entries WHERE id = ?", (entry_id,)).fetchone()
        if not entry:
            raise HTTPException(status_code=404, detail="Journal entry not found")
        if entry["is_posted"]:
            raise HTTPException(
                status_code=400,
                detail="Cannot delete a posted journal entry — create a reversing entry instead",
            )
        conn.execute("DELETE FROM journal_entries WHERE id = ?", (entry_id,))
        return {"deleted": True, "id": entry_id}
