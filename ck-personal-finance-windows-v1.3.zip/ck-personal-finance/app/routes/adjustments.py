# Author: Mani Padisetti
"""Adjustment routes — depreciation, prepayments, accruals, provisions."""

from fastapi import APIRouter, HTTPException
from app.database import get_db
from app.models.adjustments import (
    DepreciationCreate, PrepaymentCreate, AccrualCreate, ProvisionCreate,
)
from app.services.adjustments import (
    generate_depreciation, generate_prepayment,
    generate_accrual, generate_provision, generate_all,
)

router = APIRouter(prefix="/adjustments", tags=["adjustments"])


# --- Depreciation ---

@router.get("/depreciation")
async def list_depreciation():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM depreciation_schedules ORDER BY id").fetchall()
        return [dict(r) for r in rows]


@router.post("/depreciation", status_code=201)
async def create_depreciation(data: DepreciationCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO depreciation_schedules
            (asset_account_id, accum_account_id, expense_account_id, description,
             cost, residual_value, useful_life_months, method, start_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (data.asset_account_id, data.accum_account_id, data.expense_account_id,
             data.description, data.cost, data.residual_value,
             data.useful_life_months, data.method.value, data.start_date),
        )
        row = conn.execute("SELECT * FROM depreciation_schedules WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/depreciation/{schedule_id}")
async def get_depreciation(schedule_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM depreciation_schedules WHERE id = ?", (schedule_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Depreciation schedule not found")
        return dict(row)


@router.delete("/depreciation/{schedule_id}")
async def delete_depreciation(schedule_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM depreciation_schedules WHERE id = ?", (schedule_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Depreciation schedule not found")
        conn.execute("DELETE FROM depreciation_schedules WHERE id = ?", (schedule_id,))
        return {"deleted": True, "id": schedule_id}


@router.post("/depreciation/{schedule_id}/generate")
async def generate_dep(schedule_id: int, period_date: str):
    result = generate_depreciation(schedule_id, period_date)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Prepayments ---

@router.get("/prepayments")
async def list_prepayments():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM prepayment_schedules ORDER BY id").fetchall()
        return [dict(r) for r in rows]


@router.post("/prepayments", status_code=201)
async def create_prepayment(data: PrepaymentCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO prepayment_schedules
            (prepaid_account_id, expense_account_id, description, total_amount, periods, start_date)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (data.prepaid_account_id, data.expense_account_id, data.description,
             data.total_amount, data.periods, data.start_date),
        )
        row = conn.execute("SELECT * FROM prepayment_schedules WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/prepayments/{schedule_id}")
async def get_prepayment(schedule_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM prepayment_schedules WHERE id = ?", (schedule_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Prepayment schedule not found")
        return dict(row)


@router.delete("/prepayments/{schedule_id}")
async def delete_prepayment(schedule_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM prepayment_schedules WHERE id = ?", (schedule_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Prepayment schedule not found")
        conn.execute("DELETE FROM prepayment_schedules WHERE id = ?", (schedule_id,))
        return {"deleted": True, "id": schedule_id}


@router.post("/prepayments/{schedule_id}/generate")
async def generate_pre(schedule_id: int, period_date: str):
    result = generate_prepayment(schedule_id, period_date)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Accruals ---

@router.get("/accruals")
async def list_accruals():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM accruals ORDER BY id").fetchall()
        return [dict(r) for r in rows]


@router.post("/accruals", status_code=201)
async def create_accrual(data: AccrualCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO accruals
            (expense_account_id, liability_account_id, description, amount, frequency)
            VALUES (?, ?, ?, ?, ?)""",
            (data.expense_account_id, data.liability_account_id, data.description,
             data.amount, data.frequency),
        )
        row = conn.execute("SELECT * FROM accruals WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/accruals/{accrual_id}")
async def get_accrual(accrual_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM accruals WHERE id = ?", (accrual_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Accrual not found")
        return dict(row)


@router.delete("/accruals/{accrual_id}")
async def delete_accrual(accrual_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM accruals WHERE id = ?", (accrual_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Accrual not found")
        conn.execute("DELETE FROM accruals WHERE id = ?", (accrual_id,))
        return {"deleted": True, "id": accrual_id}


@router.post("/accruals/{accrual_id}/generate")
async def generate_acc(accrual_id: int, period_date: str):
    result = generate_accrual(accrual_id, period_date)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Provisions ---

@router.get("/provisions")
async def list_provisions():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM provisions ORDER BY id").fetchall()
        return [dict(r) for r in rows]


@router.post("/provisions", status_code=201)
async def create_provision(data: ProvisionCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO provisions
            (expense_account_id, liability_account_id, description, amount, review_date)
            VALUES (?, ?, ?, ?, ?)""",
            (data.expense_account_id, data.liability_account_id, data.description,
             data.amount, data.review_date),
        )
        row = conn.execute("SELECT * FROM provisions WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/provisions/{provision_id}")
async def get_provision(provision_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM provisions WHERE id = ?", (provision_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Provision not found")
        return dict(row)


@router.delete("/provisions/{provision_id}")
async def delete_provision(provision_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM provisions WHERE id = ?", (provision_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Provision not found")
        conn.execute("DELETE FROM provisions WHERE id = ?", (provision_id,))
        return {"deleted": True, "id": provision_id}


@router.post("/provisions/{provision_id}/generate")
async def generate_prov(provision_id: int, period_date: str):
    result = generate_provision(provision_id, period_date)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# --- Generate All ---

@router.post("/generate-all")
async def generate_all_adjustments(period_date: str):
    return generate_all(period_date)
