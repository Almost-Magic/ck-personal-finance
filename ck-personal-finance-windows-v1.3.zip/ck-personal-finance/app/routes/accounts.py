# Author: Mani Padisetti
"""Chart of Accounts routes."""

from fastapi import APIRouter, HTTPException
from app.database import get_db
from app.models.accounts import AccountCreate, AccountUpdate

router = APIRouter(prefix="/accounts", tags=["accounts"])


@router.get("")
async def list_accounts(type: str | None = None, is_active: bool | None = None, search: str | None = None):
    with get_db() as conn:
        query = "SELECT * FROM accounts WHERE 1=1"
        params = []
        if type:
            query += " AND type = ?"
            params.append(type)
        if is_active is not None:
            query += " AND is_active = ?"
            params.append(1 if is_active else 0)
        if search:
            query += " AND (name LIKE ? OR code LIKE ? OR description LIKE ?)"
            params.extend([f"%{search}%"] * 3)
        query += " ORDER BY code"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]


@router.get("/types")
async def account_types():
    with get_db() as conn:
        rows = conn.execute("SELECT type, COUNT(*) as count FROM accounts GROUP BY type ORDER BY type").fetchall()
        return [dict(r) for r in rows]


@router.get("/stats")
async def account_stats():
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        active = conn.execute("SELECT COUNT(*) FROM accounts WHERE is_active = 1").fetchone()[0]
        by_type = conn.execute("SELECT type, COUNT(*) as count FROM accounts GROUP BY type").fetchall()
        return {"total": total, "active": active, "inactive": total - active,
                "by_type": {r["type"]: r["count"] for r in by_type}}


@router.get("/{account_id}")
async def get_account(account_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Account not found")
        return dict(row)


@router.post("", status_code=201)
async def create_account(account: AccountCreate):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM accounts WHERE code = ?", (account.code,)).fetchone()
        if existing:
            raise HTTPException(status_code=409, detail=f"Account code '{account.code}' already exists")
        cursor = conn.execute(
            "INSERT INTO accounts (code, name, type, sub_type, description, tax_code) VALUES (?, ?, ?, ?, ?, ?)",
            (account.code, account.name, account.type.value, account.sub_type, account.description, account.tax_code),
        )
        row = conn.execute("SELECT * FROM accounts WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.put("/{account_id}")
async def update_account(account_id: int, account: AccountUpdate):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Account not found")
        if existing["is_system"] and account.is_active is False:
            raise HTTPException(status_code=400, detail="Cannot deactivate a system account")
        updates = {}
        if account.name is not None:
            updates["name"] = account.name
        if account.sub_type is not None:
            updates["sub_type"] = account.sub_type
        if account.description is not None:
            updates["description"] = account.description
        if account.is_active is not None:
            updates["is_active"] = 1 if account.is_active else 0
        if account.tax_code is not None:
            updates["tax_code"] = account.tax_code
        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            set_clause += ", updated_at = datetime('now')"
            values = list(updates.values()) + [account_id]
            conn.execute(f"UPDATE accounts SET {set_clause} WHERE id = ?", values)
        row = conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()
        return dict(row)


@router.delete("/{account_id}")
async def delete_account(account_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Account not found")
        if existing["is_system"]:
            raise HTTPException(status_code=400, detail="Cannot delete a system account")
        in_use = conn.execute("SELECT COUNT(*) FROM journal_lines WHERE account_id = ?", (account_id,)).fetchone()[0]
        if in_use > 0:
            raise HTTPException(status_code=400, detail="Cannot delete account with existing journal entries")
        conn.execute("DELETE FROM accounts WHERE id = ?", (account_id,))
        return {"deleted": True, "id": account_id}
