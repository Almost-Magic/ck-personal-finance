# Author: Mani Padisetti
"""Tax engine routes — GST, BAS, income tax, FBT, super, PAYG."""

from fastapi import APIRouter, HTTPException
from app.database import get_db
from app.models.tax import (
    GSTEntryCreate, FBTItemCreate, SuperObligationCreate, PAYGEntryCreate,
)
from app.services.tax import gst_position, prepare_bas, income_tax_provision, calculate_gst

router = APIRouter(prefix="/tax", tags=["tax"])


# --- GST ---

@router.get("/gst/position")
async def get_gst_position(from_date: str | None = None, to_date: str | None = None):
    return gst_position(from_date=from_date, to_date=to_date)


@router.post("/gst/calculate")
async def calc_gst(amount: float, inclusive: bool = True):
    return calculate_gst(amount, inclusive)


@router.post("/gst/entries", status_code=201)
async def create_gst_entry(entry: GSTEntryCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO gst_entries
            (transaction_id, journal_entry_id, gst_type, gross_amount, gst_amount, net_amount, bas_period)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (entry.transaction_id, entry.journal_entry_id, entry.gst_type,
             entry.gross_amount, entry.gst_amount, entry.net_amount, entry.bas_period),
        )
        row = conn.execute("SELECT * FROM gst_entries WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.get("/gst/entries")
async def list_gst_entries():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM gst_entries ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]


# --- BAS ---

@router.post("/bas/prepare")
async def prepare_bas_endpoint(quarter: str, financial_year: int):
    if quarter not in ("Q1", "Q2", "Q3", "Q4"):
        raise HTTPException(status_code=400, detail="Quarter must be Q1, Q2, Q3, or Q4")
    return prepare_bas(quarter, financial_year)


@router.get("/bas")
async def list_bas():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM bas_lodgements ORDER BY financial_year DESC, quarter").fetchall()
        return [dict(r) for r in rows]


@router.get("/bas/{bas_id}")
async def get_bas(bas_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="BAS not found")
        return dict(row)


@router.post("/bas/{bas_id}/lodge")
async def lodge_bas(bas_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="BAS not found")
        if row["status"] != "draft":
            raise HTTPException(status_code=400, detail=f"BAS is already {row['status']}")
        conn.execute(
            "UPDATE bas_lodgements SET status = 'lodged', lodged_at = datetime('now') WHERE id = ?",
            (bas_id,),
        )
        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        return dict(row)


@router.post("/bas/{bas_id}/paid")
async def mark_bas_paid(bas_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="BAS not found")
        if row["status"] == "paid":
            raise HTTPException(status_code=400, detail="BAS is already paid")
        conn.execute(
            "UPDATE bas_lodgements SET status = 'paid', paid_at = datetime('now') WHERE id = ?",
            (bas_id,),
        )
        row = conn.execute("SELECT * FROM bas_lodgements WHERE id = ?", (bas_id,)).fetchone()
        return dict(row)


# --- Income Tax ---

@router.get("/income-tax")
async def get_income_tax(financial_year: int):
    return income_tax_provision(financial_year)


# --- FBT ---

@router.get("/fbt")
async def list_fbt():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM fbt_items ORDER BY fbt_year DESC, id").fetchall()
        return [dict(r) for r in rows]


@router.post("/fbt", status_code=201)
async def create_fbt(item: FBTItemCreate):
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO fbt_items (description, fbt_type, taxable_value, fbt_year, employee_name)
            VALUES (?, ?, ?, ?, ?)""",
            (item.description, item.fbt_type, item.taxable_value, item.fbt_year, item.employee_name),
        )
        row = conn.execute("SELECT * FROM fbt_items WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.delete("/fbt/{item_id}")
async def delete_fbt(item_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM fbt_items WHERE id = ?", (item_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="FBT item not found")
        conn.execute("DELETE FROM fbt_items WHERE id = ?", (item_id,))
        return {"deleted": True, "id": item_id}


# --- Superannuation ---

@router.get("/super")
async def list_super():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM super_obligations ORDER BY due_date DESC").fetchall()
        return [dict(r) for r in rows]


@router.post("/super", status_code=201)
async def create_super(obligation: SuperObligationCreate):
    super_amount = round(obligation.ordinary_earnings * obligation.super_rate, 2)
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO super_obligations
            (employee_name, quarter, ordinary_earnings, super_rate, super_amount, due_date)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (obligation.employee_name, obligation.quarter, obligation.ordinary_earnings,
             obligation.super_rate, super_amount, obligation.due_date),
        )
        row = conn.execute("SELECT * FROM super_obligations WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.post("/super/{obligation_id}/paid")
async def mark_super_paid(obligation_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM super_obligations WHERE id = ?", (obligation_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Super obligation not found")
        if row["status"] == "paid":
            raise HTTPException(status_code=400, detail="Already paid")
        conn.execute(
            "UPDATE super_obligations SET status = 'paid', paid_date = datetime('now') WHERE id = ?",
            (obligation_id,),
        )
        row = conn.execute("SELECT * FROM super_obligations WHERE id = ?", (obligation_id,)).fetchone()
        return dict(row)


# --- PAYG ---

@router.get("/payg")
async def list_payg():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM payg_entries ORDER BY period DESC").fetchall()
        return [dict(r) for r in rows]


@router.post("/payg", status_code=201)
async def create_payg(entry: PAYGEntryCreate):
    net_pay = round(entry.gross_pay - entry.tax_withheld, 2)
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO payg_entries (employee_name, period, gross_pay, tax_withheld, net_pay)
            VALUES (?, ?, ?, ?, ?)""",
            (entry.employee_name, entry.period, entry.gross_pay, entry.tax_withheld, net_pay),
        )
        row = conn.execute("SELECT * FROM payg_entries WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)
