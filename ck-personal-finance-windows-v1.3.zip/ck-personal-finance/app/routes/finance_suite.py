"""AMTL Finance Suite local/internal wrapper routes."""

from __future__ import annotations

from html import escape
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from app.services.finance_suite import (
    COMPLIANCE_BOUNDARY,
    MODULES,
    PRODUCTS,
    admin_health,
    admin_receipts,
    admin_status,
    ai_provider_readiness,
    ai_task_receipts,
    block_browser_assist_final_action,
    blocked_external_export,
    blocked_actions,
    browser_assist_artifacts,
    browser_assist_health,
    browser_assist_receipts,
    create_browser_assist_session_artifact,
    create_receipt,
    create_report_pack,
    cross_app_destination_receipts,
    cross_app_destinations,
    cross_app_health,
    cross_app_outbox,
    demo_data_status,
    destination_owned_receipts,
    dispatch_cross_app_packets,
    evidence_events,
    evidence_health,
    evidence_receipts,
    external_action_status,
    failure_states,
    filter_evidence,
    forensic_accounting_health,
    forensic_cases,
    forensic_receipts,
    generate_finance_report,
    genie_ask,
    ingest_fixture,
    index_risk_sources,
    ledger_entries,
    ledger_import,
    ledger_reconcile,
    product_blocked_action,
    product_demo_data_status,
    product_drilldowns,
    product_health,
    product_receipts,
    approve_risk_candidate,
    archive_risk,
    generate_risk_candidates,
    prepare_browser_assist,
    prepare_pay_stub_assist,
    record_destination_owned_receipt,
    record_cross_app_destination_receipt,
    merge_risks,
    reports_health,
    reports_receipts,
    receipts,
    rag_health,
    rag_sources,
    register_rag_source,
    reload_product_synthetic,
    reload_risk_synthetic,
    remove_product_synthetic,
    remove_risk_synthetic,
    remove_synthetic,
    restore_synthetic,
    right_rail,
    override_risk_field,
    review_risk_register,
    risk_candidates,
    risk_demo_data_status,
    risk_health,
    risk_receipts,
    risk_register,
    risk_source_review,
    run_runway_cost_scan,
    run_app_ai_task,
    runway_health,
    scenario_run,
    scan_forensic_accounting,
    scan_risk_sources,
    search_rag_sources,
    strategist_generate,
    strategist_scenarios,
    suite_summary,
    update_risk,
    create_runway_savings_plan,
)


router = APIRouter(tags=["finance-suite"])


class ReceiptRequest(BaseModel):
    kind: str = "local_review"
    summary: str = "Finance Suite local review receipt."
    source_refs: list[str] = []
    payload: dict = {}


class ImportRequest(BaseModel):
    filename: str = "finance-suite-demo.csv"
    csv_text: str | None = None


class ScenarioRequest(BaseModel):
    monthly_revenue: float = 28000
    monthly_costs: float = 24000
    cash_on_hand: float = 62000
    price_change_percent: float = 0


class ReportRequest(BaseModel):
    report_type: str = "local_finance_review_pack"


class RemoveSyntheticRequest(BaseModel):
    preview: bool = False


class GenieAskRequest(BaseModel):
    question: str = "What should I review in the local finance rows?"


class ProductBlockedActionRequest(BaseModel):
    action: str = "provider_send"


class EvidenceFilterRequest(BaseModel):
    product: str | None = None
    event_type: str | None = None
    query: str | None = None


class ReportsExportRequest(BaseModel):
    destination: str = "external_export"


class BrowserAssistPrepareRequest(BaseModel):
    platform: str = "xero"
    task: str = "reconcile_review"
    source: str = "ledger"


class BrowserAssistBlockRequest(BaseModel):
    platform: str = "xero"
    action: str = "submit"


class BrowserAssistDestinationReceiptRequest(BaseModel):
    platform: str = "xero"
    destination_receipt_id: str = "xero-human-receipt-demo"
    action: str = "human_saved_draft"
    human_summary: str = "Human operator completed this step inside the destination product and brought back the destination receipt."
    session_id: str | None = None
    evidence_ref: str | None = None


class BrowserAssistPayStubRequest(BaseModel):
    platform: str = "xero"
    employee_name: str | None = None
    pay_period_start: str | None = None
    pay_period_end: str | None = None
    pay_date: str | None = None
    gross_pay: float | None = None
    net_pay: float | None = None
    tax_withheld: float | None = None
    superannuation: float | None = None
    earnings: list[dict] = []
    deductions: list[dict] = []


class BrowserAssistSessionArtifactRequest(BaseModel):
    session_id: str


class RiskApproveRequest(BaseModel):
    candidate_id: str
    edits: dict = {}


class RiskUpdateRequest(BaseModel):
    risk_id: str
    updates: dict = {}


class RiskOverrideRequest(BaseModel):
    risk_id: str
    field: str
    value: object
    reason: str = "User reviewed and overrode local risk suggestion."
    locked_by_user: bool = False
    reviewed_by: str = "local_user"


class RiskMergeRequest(BaseModel):
    primary_risk_id: str
    secondary_risk_id: str
    reason: str = "Related local risk signals."


class RiskArchiveRequest(BaseModel):
    risk_id: str
    reason: str = "Archived after local review."


class RiskReviewRequest(BaseModel):
    reviewed_by: str = "local_user"
    notes: str = "Local risk review completed."


class RiskSourceIndexRequest(BaseModel):
    include_nas: bool = False
    max_nas_files: int = 25
    max_seconds: float = 8.0


class RagSearchRequest(BaseModel):
    query: str = "runway risk"
    limit: int = 8


class RagSourceRequest(BaseModel):
    name: str = "User supplied source"
    source_scope: str = "internal"
    source_type: str = "manual"
    text: str | None = None
    path: str | None = None
    url: str | None = None
    citation: str | None = None


class CrossAppDispatchRequest(BaseModel):
    destinations: list[str] | None = None
    reason: str = "automatic local cross-app dispatch"


class CrossAppDestinationReceiptRequest(BaseModel):
    destination_id: str
    packet_id: str
    destination_receipt_id: str
    human_summary: str = "Destination app or human operator accepted this Finance Suite packet."


class AppAiTaskRequest(BaseModel):
    task_requested: str = "Summarise Fat Lady Sang training-services cashflow, ledger exceptions and runway review points."
    model_tier: str = "free"


def _section_payload(section: str) -> dict:
    summary = suite_summary()
    modules = {module["id"]: module for module in summary["modules"]}
    if section in modules:
        active = modules[section]
    elif section == "ledger":
        active = modules["ledger"]
    elif section == "risk":
        active = {
            "id": "risk",
            "name": "Fin Strategist Risk Intelligence",
            "role": "Local/internal business risk decision support",
            "status": "DONE_LOCAL_INTERNAL_RISK_INTELLIGENCE_ONLY",
            "surfaces": [
                "Risk dashboard and posture counts",
                "Risk register with evidence-backed fields",
                "Draft candidates from deterministic local source scanning",
                "Scenario risk lab, assumptions and fragility view",
                "Mitigation planner and decision gate",
                "Source intelligence / RAG-ready manifests",
                "Overrides, review history, receipts and synthetic controls",
            ],
        }
    elif section == "forensics":
        active = {
            "id": "forensics",
            "name": "Ledger Forensic Accounting",
            "role": "Local/internal forensic accounting review signals",
            "status": "DONE_LOCAL_INTERNAL_LEDGER_FORENSICS_ONLY",
            "surfaces": [
                "forensic dashboard",
                "duplicate and split pattern review",
                "high-value and round-amount review",
                "payroll/pay-slip consistency review",
                "source-document checklist",
                "case register and evidence receipts",
            ],
        }
    elif section == "rag":
        active = {
            "id": "rag",
            "name": "Sources & Search",
            "role": "Local/internal retrieval over approved sources",
            "status": "DONE_LOCAL_INTERNAL_RAG_SOURCE_INTELLIGENCE_ONLY",
            "surfaces": [
                "local source search",
                "internal and external source registry",
                "approved source indexing",
                "exact NAS exclusions",
                "citation-backed risk/runway source review",
                "provider/vector approval boundary",
            ],
        }
    elif section == "cross-app":
        active = {
            "id": "cross-app",
            "name": "App Handoffs",
            "role": "Automatic local handoff packets for AMTL apps",
            "status": "DONE_LOCAL_INTERNAL_CROSS_APP_COMMUNICATIONS_ONLY",
            "surfaces": [
                "Elaine briefing packets",
                "Baldrick runtime status packets",
                "Costanza customer finance signal drafts",
                "Ripple revenue signal packets",
                "Spark ROI and offer signal packets",
                "Workshop and Beast route proof packets",
                "Chronicle evidence/memory adapter packets",
                "CK Writer report briefs",
                "Digital Sentinel vendor risk packets",
                "Concierge human-review task drafts",
                "Pre-Sales commercial assumption packets",
            ],
        }
    else:
        active = {
            "id": section,
            "name": section.title(),
            "role": "Finance Suite surface",
            "status": "local_wrapper_ready",
            "surfaces": [],
        }
    return {"summary": summary, "active": active}


DISPLAY_STATUS_LABELS = {
    "local_wrapper_ready": "Ready",
    "existing_app_preserved": "Preserved",
    "local_scenario_engine_ready": "Scenario engine ready",
    "local_runway_control_ready": "Runway control ready",
    "local_reference_only": "Reference only",
}


def _display_text(value: Any) -> str:
    text = str(value)
    replacements = {
        "Finance Admin / Proof": "Finance Admin / Readiness",
        "Workshop Truth": "Workshop Status",
        "Beast/Gateway Truth": "Beast/Gateway Status",
        "registry truth": "registry status",
        "route truth": "route status",
        "local/manual": "manual/private",
        "local proof": "evidence",
        "Local/internal": "Private",
        "local/internal": "private",
        "blocked_approval_required": "Approval required",
        "local_stub_unavailable": "Connector unavailable",
        "bank_sync": "Bank sync",
        "accounting_write": "Accounting write",
        "bas_lodgement": "BAS lodgement",
        "payroll_mutation": "Payroll change",
        "pay_stub_finalise": "Pay stub finalise",
        "provider_send": "Provider send",
        "gateway_registration": "Gateway registration",
        "investment_advice": "Investment advice",
        "tax_advice": "Tax advice",
        "legal_advice": "Legal advice",
        "browser_final_submit": "Browser final submit",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    if text in DISPLAY_STATUS_LABELS:
        return DISPLAY_STATUS_LABELS[text]
    if text.startswith("DONE_LOCAL_INTERNAL_"):
        return "Done for private workspace"
    return text


def _html(section: str = "home") -> str:
    payload = _section_payload(section)
    summary = payload["summary"]
    active = payload["active"]
    nav_groups = [
        ("Overview", [("Home", "/finance/"), ("Sources & Search", "/finance/rag"), ("App Handoffs", "/finance/cross-app")]),
        ("Daily Finance", [("Genie", "/finance/genie"), ("The Ledger", "/finance/ledger"), ("Forensics", "/finance/ledger/forensics"), ("Imports", "/finance/imports")]),
        ("Strategy & Control", [("Fin Strategist", "/finance/strategist"), ("Risk Intelligence", "/finance/strategist/risk"), ("Runway Officer", "/finance/runway")]),
        ("Evidence & Admin", [("Reports", "/finance/reports"), ("Evidence", "/finance/evidence"), ("Browser Assist", "/finance/browser-assist"), ("Admin", "/finance/admin")]),
    ]
    nav_html = ""
    for group, links in nav_groups:
        links_html = "".join(
            f'<a class="nav-link {"active" if href.rstrip("/").endswith(section) or (section == "home" and href == "/finance/") else ""}" href="{href}">{label}</a>'
            for label, href in links
        )
        is_active_group = any(href.rstrip("/").endswith(section) or (section == "home" and href == "/finance/") for _, href in links)
        nav_html += f'<details class="nav-group" {"open" if is_active_group else ""}><summary>{escape(group)}</summary>{links_html}</details>'
    module_cards = "".join(
        f"""
        <article class="card">
          <p class="eyebrow">{escape(module["role"])}</p>
          <h3>{escape(module["name"])}</h3>
          <p>{escape(_display_text(module["status"]))}</p>
          <a href="{module["route"]}">Open</a>
        </article>
        """
        for module in summary["modules"]
    )
    surface_rows = "".join(f"<li>{escape(item)}</li>" for item in active.get("surfaces", []))
    blocked_rows = "".join(
        f"<li><strong>{escape(_display_text(row['action']))}</strong><span>{escape(_display_text(row['state']))}: {escape(_display_text(row['reason']))}</span></li>"
        for row in blocked_actions()
    )
    def render_tabs(prefix: str, labels: list[str], panel_bodies: list[str] | None = None) -> str:
        panel_bodies = panel_bodies or [f"<p>{escape(label)} workspace.</p>" for label in labels]
        buttons = "".join(
            f'<button class="tab-button {"active" if idx == 0 else ""}" data-tab-target="{prefix}-{idx}" onclick="openFinanceTab(event, \'{prefix}-{idx}\')">{escape(label)}</button>'
            for idx, label in enumerate(labels)
        )
        panels = "".join(
            f'<div id="{prefix}-{idx}" class="tab-panel {"active" if idx == 0 else ""}">{body}</div>'
            for idx, body in enumerate(panel_bodies)
        )
        return f'<div class="tabs" role="tablist">{buttons}</div><div class="tab-stage" data-layout="tabbed-centre">{panels}</div>'
    product_panel = ""
    if section in PRODUCTS:
        health = product_health(section)
        rail = right_rail(section)
        drilldowns = product_drilldowns(section)
        helper_html = "".join(f"<dt>{escape(key.replace('_', ' ').title())}</dt><dd>{escape(str(value))}</dd>" for key, value in rail.items())
        count_html = "".join(
            f'<a class="count" href="/finance/api/{section}/health#{escape(key)}"><strong>{escape(str(value))}</strong><span>{escape(key.replace("_", " "))}</span></a>'
            for key, value in health["counts"].items()
        )
        failure_html = "".join(f"<li><strong>{escape(row['state'])}</strong><span>{escape(row['message'])}</span></li>" for row in failure_states(section))
        if section == "genie":
            action_buttons = """
              <button onclick="financePost('/finance/api/genie/ask',{question:'What should I review in the local rows?'})">Ask Genie</button>
              <button onclick="financePost('/finance/api/genie/blocked-action',{action:'provider_send'})">Provider gate</button>
              <button onclick="financePost('/finance/api/genie/reload-synthetic',{})">Reload demo</button>
              <button onclick="financePost('/finance/api/genie/remove-synthetic',{preview:true})">Synthetic preview</button>
            """
            data_note = f"{len(drilldowns.get('context_sources', []))} context source rows available."
        elif section == "ledger":
            action_buttons = """
              <button onclick="financePost('/finance/api/ledger/import',{filename:'ui-ledger-fixture.csv'})">Import fixture</button>
              <button onclick="financePost('/finance/api/ledger/reconcile',{})">Reconcile draft</button>
              <button onclick="financePost('/finance/api/ledger/forensics/scan',{})">Run forensic scan</button>
              <button onclick="financePost('/finance/api/ledger/blocked-action',{action:'accounting_write'})">Accounting write gate</button>
              <button onclick="financePost('/finance/api/ledger/reload-synthetic',{})">Reload demo</button>
            """
            data_note = f"{len(drilldowns.get('entries', []))} ledger entries and {len(drilldowns.get('exceptions', []))} exceptions available."
        elif section == "runway":
            action_buttons = """
              <button onclick="financePost('/finance/api/runway/cost-scan',{})">Run cost scan</button>
              <button onclick="financePost('/finance/api/runway/savings-plan',{})">Draft savings plan</button>
              <button onclick="financePost('/finance/api/runway/blocked-action',{action:'accounting_write'})">Accounting write gate</button>
              <button onclick="financePost('/finance/api/runway/reload-synthetic',{})">Reload demo</button>
              <button onclick="financePost('/finance/api/runway/remove-synthetic',{preview:true})">Synthetic preview</button>
            """
            data_note = (
                f"{len(drilldowns.get('subscriptions', []))} subscriptions, "
                f"{len(drilldowns.get('vendors', []))} vendors and "
                f"{len(drilldowns.get('ai_costs', []))} AI cost rows available."
            )
        else:
            action_buttons = """
              <button onclick="financePost('/finance/api/strategist/generate',{cash_on_hand:32000,price_change_percent:8})">Generate scenario</button>
              <button onclick="financePost('/finance/api/strategist/blocked-action',{action:'investment_advice'})">Advice gate</button>
              <button onclick="financePost('/finance/api/strategist/reload-synthetic',{})">Reload demo</button>
              <button onclick="financePost('/finance/api/strategist/remove-synthetic',{preview:true})">Synthetic preview</button>
            """
            data_note = f"{len(drilldowns.get('scenarios', []))} scenarios available."
        product_tabs = render_tabs(
            f"{section}-product",
            PRODUCTS[section]["tabs"],
            [
                f"<h3>{escape(tab)}</h3><p>{escape(data_note)}</p><div class='counts'>{count_html}</div>" if idx == 0
                else f"<h3>{escape(tab)}</h3><p>Focused {escape(PRODUCTS[section]['name'])} workspace. Use the actions below to save receipts and review evidence.</p>"
                for idx, tab in enumerate(PRODUCTS[section]["tabs"])
            ],
        )
        product_panel = f"""
      <section class="panel" style="margin-top:14px">
        <h2>{escape(PRODUCTS[section]["name"])} workspace</h2>
        {product_tabs}
        <div class="action-row">{action_buttons}</div>
      </section>
      <template id="finance-right-rail-context">
        <dl class="helpers">{helper_html}</dl>
        <h3>Failure states</h3>
        <ul class="blocked-list">{failure_html}</ul>
      </template>
        """
    elif section in {"reports", "evidence", "admin", "browser-assist", "risk", "forensics", "rag", "cross-app"}:
        if section == "reports":
            health = reports_health()
            tab_labels = ["Genie Answers", "Ledger Entries & Exceptions", "Fin Strategist Scenario", "Risk Intelligence", "Approval Gates", "Receipts", "Admin"]
            buttons = """
              <button onclick="financePost('/finance/api/reports/generate',{report_type:'ui_full_local_pack'})">Generate local report</button>
              <button onclick="financePost('/finance/api/reports/export',{destination:'external_publish'})">External export gate</button>
              <button onclick="fetch('/finance/api/reports/receipts').then(r=>r.json()).then(j=>alert((j.receipts||[]).length+' report receipts'))">Show report receipts</button>
            """
        elif section == "evidence":
            health = evidence_health()
            tab_labels = ["Questions", "Imports", "Entries", "Exceptions", "Scenarios", "Risk Intelligence", "Browser Assist", "Receipts", "Blocked Actions", "Synthetic Controls"]
            buttons = """
              <button onclick="financePost('/finance/api/evidence/filter',{event_type:'receipt'})">Filter receipts</button>
              <button onclick="financePost('/finance/api/evidence/filter',{product:'ledger'})">Filter Ledger events</button>
              <button onclick="fetch('/finance/api/evidence/events').then(r=>r.json()).then(j=>alert((j.events||[]).length+' evidence events'))">Show events</button>
            """
        elif section == "browser-assist":
            health = browser_assist_health()
            tab_labels = ["Manual Login", "QuickBooks", "MYOB", "Xero", "Pay Stub / Pay Slip", "Copy-Ready Draft", "Session Artifact", "Destination-Owned Receipt", "Final Action Gate", "Receipts"]
            buttons = """
              <button onclick="financePost('/finance/api/browser-assist/prepare',{platform:'xero',task:'reconcile_review',source:'ledger'})">Prepare Xero assist</button>
              <button onclick="financePost('/finance/api/browser-assist/prepare',{platform:'quickbooks',task:'invoice_draft',source:'ledger'})">Prepare QuickBooks assist</button>
              <button onclick="financePost('/finance/api/browser-assist/pay-stub',{platform:'xero',employee_name:'Human review employee',gross_pay:1200,net_pay:980,tax_withheld:220})">Prepare pay stub draft</button>
              <button onclick="fetch('/finance/api/browser-assist/session-artifacts').then(r=>r.json()).then(j=>alert((j.artifacts||[]).length+' session artifacts'))">Show session artifacts</button>
              <button onclick="financePost('/finance/api/browser-assist/destination-receipts',{platform:'xero',destination_receipt_id:'human-xero-proof-demo',action:'human_saved_draft',human_summary:'Human operator manually completed or verified the step in Xero and brought this receipt back to Finance Suite.'})">Record destination receipt</button>
              <button onclick="financePost('/finance/api/browser-assist/block-final-action',{platform:'myob',action:'post'})">Final action gate</button>
            """
        elif section == "forensics":
            health = forensic_accounting_health()
            tab_labels = ["Dashboard", "Cases", "Duplicate Review", "Payroll Review", "Source Documents", "Evidence", "Receipts", "Limits"]
            buttons = """
              <button onclick="financePost('/finance/api/ledger/forensics/scan',{})">Run forensic scan</button>
              <button onclick="fetch('/finance/api/ledger/forensics/cases').then(r=>r.json()).then(j=>alert((j.cases||[]).length+' forensic cases'))">Show cases</button>
              <button onclick="fetch('/finance/api/ledger/forensics/receipts').then(r=>r.json()).then(j=>alert((j.receipts||[]).length+' forensic receipts'))">Show receipts</button>
            """
        elif section == "risk":
            health = risk_health()
            tab_labels = [
                "Risk Dashboard",
                "Risk Register",
                "Risk Candidates",
                "Scenario Risk Lab",
                "Assumptions & Fragility",
                "Mitigation Planner",
                "Decision Gate",
                "Source Intelligence",
                "Overrides & Review History",
                "Receipts",
            ]
            buttons = """
              <button onclick="financePost('/finance/api/risk/source-scan',{})">Scan local sources</button>
              <button onclick="financePost('/finance/api/risk/generate',{})">Generate candidates</button>
              <button onclick="financePost('/finance/api/risk/review',{reviewed_by:'local_user',notes:'UI local risk review'})">Review register</button>
              <button onclick="financePost('/finance/api/risk/remove-synthetic',{preview:true})">Synthetic preview</button>
              <button onclick="financePost('/finance/api/risk/reload-synthetic',{})">Reload demo</button>
              <button onclick="financePost('/finance/api/browser-assist/block-final-action',{platform:'xero',action:'submit'})">Final action gate</button>
            """
        elif section == "rag":
            health = rag_health()
            tab_labels = ["Search", "Sources", "Internal Sources", "External References", "Exclusions", "Receipts", "Limits"]
            buttons = """
              <button onclick="financePost('/finance/api/rag/source-index',{include_nas:false,max_nas_files:25,max_seconds:8})">Index approved sources</button>
              <button onclick="financePost('/finance/api/rag/search',{query:'runway vendor AI cost risk',limit:8})">Search sources</button>
              <button onclick="financePost('/finance/api/rag/sources',{name:'External reference example',source_scope:'external',source_type:'reference',url:'https://example.com/source',citation:'User supplied external reference only'})">Register external reference</button>
              <button onclick="fetch('/finance/api/rag/sources').then(r=>r.json()).then(j=>alert((j.sources||[]).length+' RAG sources'))">Show sources</button>
            """
        elif section == "cross-app":
            health = cross_app_health()
            tab_labels = ["Outbox", "Elaine", "Baldrick", "Costanza", "Ripple", "Spark", "Workshop / Beast", "Chronicle", "CK Writer", "Digital Sentinel", "Concierge", "Discovery Desk", "Receipts", "Limits"]
            buttons = """
              <button onclick="financePost('/finance/api/cross-app/dispatch',{reason:'UI approved local handoff dispatch'})">Prepare all packets</button>
              <button onclick="financePost('/finance/api/cross-app/dispatch',{destinations:['elaine','baldrick','ripple','spark'],reason:'UI priority dispatch'})">Dispatch priority apps</button>
              <button onclick="fetch('/finance/api/cross-app/outbox').then(r=>r.json()).then(j=>alert((j.packets||[]).length+' cross-app packets'))">Show outbox</button>
              <button onclick="fetch('/finance/api/cross-app/destinations').then(r=>r.json()).then(j=>alert(Object.keys(j.destinations||{}).length+' destinations'))">Show destinations</button>
            """
        else:
            health = admin_health()
            admin = admin_status(create_status_receipt=False)
            health = {**health, "counts": admin["counts"], "right_rail": {**right_rail("strategist"), "what": "Admin shows runtime, persistence, product statuses, gates and registry status.", "receipt_link": "/finance/api/admin/receipts"}, "failure_states": failure_states("strategist")}
            tab_labels = ["Runtime", "Persistence", "Product Statuses", "Risk Intelligence", "Synthetic Status", "Provider Gate", "Bank/API Gate", "Workshop Status", "Beast/Gateway Status", "Receipts"]
            buttons = """
              <button onclick="fetch('/finance/api/admin/status').then(r=>r.json()).then(j=>alert('PID '+j.runtime_pid+' / '+j.receipt_id))">Refresh status</button>
              <button onclick="financePost('/finance/api/restore-synthetic',{})">Restore synthetic data</button>
              <button onclick="financePost('/finance/api/remove-synthetic',{preview:true})">Preview synthetic removal</button>
              <button onclick="financePost('/finance/api/remove-synthetic',{preview:false})">Remove all synthetic data</button>
              <button onclick="financePost('/finance/api/reports/export',{destination:'admin_external_publish'})">Gateway/export gate</button>
              <button onclick="fetch('/finance/api/admin/receipts').then(r=>r.json()).then(j=>alert((j.receipts||[]).length+' admin receipts'))">Show admin receipts</button>
            """
        count_html = "".join(
            f'<a class="count" href="/finance/api/{section}/health#{escape(key)}"><strong>{escape(str(value))}</strong><span>{escape(key.replace("_", " "))}</span></a>'
            for key, value in health.get("counts", {}).items()
        )
        helper_html = "".join(f"<dt>{escape(key.replace('_', ' ').title())}</dt><dd>{escape(str(value))}</dd>" for key, value in health.get("right_rail", {}).items())
        failure_html = "".join(f"<li><strong>{escape(row['state'])}</strong><span>{escape(row['message'])}</span></li>" for row in health.get("failure_states", []))
        feature_tabs = render_tabs(
            f"{section}-surface",
            tab_labels,
            [
                f"<h3>{escape(_display_text(tab))}</h3><div class='counts'>{count_html}</div><p>{escape(_display_text(health.get('boundary', COMPLIANCE_BOUNDARY)))}</p>" if idx == 0
                else f"<h3>{escape(tab)}</h3><p>{escape(tab)} workspace. Relevant controls and receipts are below; external actions need approval.</p>"
                for idx, tab in enumerate(tab_labels)
            ],
        )
        product_panel = f"""
      <section class="panel" style="margin-top:14px">
        <h2>{escape(_display_text(health["product"]))} workspace</h2>
        {feature_tabs}
        <div class="action-row">{buttons}</div>
      </section>
      <template id="finance-right-rail-context">
        <dl class="helpers">{helper_html}</dl>
        <h3>Failure states</h3>
        <ul class="blocked-list">{failure_html}</ul>
      </template>
        """
    current_surface_tabs = render_tabs(
        f"{section}-current",
        ["Surface", "Menu Map", "Limits"],
        [
            f'<ul class="surface-list">{surface_rows or "<li>Suite home, evidence and administration surface.</li>"}</ul>',
            "<p>The left menu is grouped into Overview, Daily Finance, Strategy & Control, and Evidence & Admin. Groups collapse so the user is not forced through a long rail.</p>",
            f"<p>{escape(COMPLIANCE_BOUNDARY)}</p><p>Bank writes, tax lodgement, external provider calls, vector stores and accounting mutations need explicit approval before they can run.</p>",
        ],
    )
    synthetic_admin_panel = ""
    if section == "admin":
        synthetic_status = demo_data_status()
        demo_org = synthetic_status.get("demo_organisation", {})
        ai_ready = ai_provider_readiness()
        synthetic_admin_panel = f"""
      <section class="panel" style="margin-bottom:14px">
        <p class="eyebrow">Synthetic data manager</p>
        <h2>Demo data controls</h2>
        <p>Current demo organisation: <strong>{escape(str(demo_org.get("name", "Fat Lady Sang")))}</strong> - {escape(str(demo_org.get("service_line", "training services")))}. Synthetic rows are labelled and removable across Finance Suite.</p>
        <div class="counts">
          <span class="count"><strong>{escape(str(synthetic_status.get("fixture_rows", 0)))}</strong><span>synthetic rows</span></span>
          <span class="count"><strong>{escape(str(synthetic_status.get("suite_fixture_rows", 0)))}</strong><span>suite import rows</span></span>
          <span class="count"><strong>{escape(str(synthetic_status.get("synthetic_data_present", False))).lower()}</strong><span>synthetic present</span></span>
        </div>
        <div class="action-row">
          <button onclick="financePost('/finance/api/restore-synthetic',{{}})">Restore synthetic data</button>
          <button onclick="financePost('/finance/api/remove-synthetic',{{preview:true}})">Preview synthetic removal</button>
          <button onclick="financePost('/finance/api/remove-synthetic',{{preview:false}})">Remove all synthetic data</button>
        </div>
      </section>
      <section class="panel" style="margin-bottom:14px">
        <p class="eyebrow">App AI execution</p>
        <h2>Run analysis</h2>
        <p>App AI: feature not in this build.</p>
        <div class="action-row">
          <button onclick="fetch('/finance/api/ai/readiness').then(r=>r.json()).then(j=>alert(j.state+' / key configured '+j.key_configured))">Check app AI readiness</button>
          <button onclick="financePost('/finance/api/ai/run',{{task_requested:'Summarise Fat Lady Sang training-services cashflow, ledger exceptions and runway review points. Include caveats and human review steps.',model_tier:'free'}})">Ask app AI</button>
          <button onclick="financePost('/finance/api/ai/run',{{task_requested:'Create a short Finance Suite review note from current demo rows. Include caveats and human review steps.',model_tier:'free'}})">Run with app AI</button>
          <button onclick="fetch('/finance/api/ai/receipts').then(r=>r.json()).then(j=>alert((j.receipts||[]).length+' analysis receipts'))">Show analysis receipts</button>
        </div>
      </section>
        """
    return f"""<!doctype html>
<html lang="en-AU">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='6' fill='%2310120f'/%3E%3Cpath d='M7 21h18M9 17h14M11 13h10' stroke='%23c9a96e' stroke-width='3' stroke-linecap='round'/%3E%3C/svg%3E">
  <title>AMTL Finance Suite</title>
  <style>
    :root {{
      color-scheme: dark;
      --bg: #10120f;
      --panel: #171a15;
      --panel-2: #20241d;
      --line: #3a3429;
      --text: #f0eee7;
      --muted: #b9b1a0;
      --accent: #c9a96e;
      --green: #8ea78f;
      --risk: #dc8f86;
      font-family: "Segoe UI", Aptos, system-ui, sans-serif;
    }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; min-height: 100vh; background: linear-gradient(180deg, #12140f, var(--bg)); color: var(--text); }}
    a {{ color: var(--accent); text-decoration: none; }}
    .shell {{ display: grid; grid-template-columns: 260px minmax(0, 1fr) 330px; min-height: 100vh; }}
    nav, aside {{ background: rgba(17,20,16,.92); padding: 18px; border-color: var(--line); }}
    nav {{ border-right: 1px solid var(--line); }}
    aside {{ border-left: 1px solid var(--line); }}
    main {{ padding: 22px; min-width: 0; }}
    h1 {{ margin: 0 0 8px; font-size: 34px; line-height: 1.08; letter-spacing: 0; }}
    h2 {{ margin: 0 0 10px; font-size: 22px; }}
    h3 {{ margin: 0 0 8px; }}
    p {{ color: var(--muted); line-height: 1.45; }}
    .brand {{ margin-bottom: 22px; }}
    .brand strong {{ display: block; font-size: 18px; }}
    .nav-link {{ display: block; padding: 10px 9px; border-radius: 7px; color: var(--muted); }}
    .nav-link.active, .nav-link:hover {{ background: var(--panel-2); color: var(--text); }}
    .nav-group {{ border: 1px solid var(--line); border-radius: 8px; margin: 9px 0; background: rgba(32,36,29,.52); }}
    .nav-group summary {{ cursor: pointer; padding: 10px; color: var(--green); font-weight: 800; }}
    .nav-group .nav-link {{ margin: 0 8px 8px; }}
    .hero {{ display: grid; gap: 12px; margin-bottom: 18px; }}
    .pill-row {{ display: flex; flex-wrap: wrap; gap: 8px; }}
    .pill {{ border: 1px solid var(--line); background: var(--panel); color: var(--accent); padding: 6px 8px; border-radius: 6px; font-size: 12px; font-weight: 700; }}
    .tabs, .counts {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0; }}
    .tab-button, .tab, .count {{ border: 1px solid var(--line); background: #222719; border-radius: 7px; padding: 8px 9px; color: var(--text); }}
    .tab-button {{ text-align: center; min-width: 92px; }}
    .tab-button.active {{ border-color: var(--accent); color: var(--accent); }}
    .tab-stage {{ border: 1px solid var(--line); border-radius: 8px; background: rgba(16,18,15,.5); padding: 12px; min-height: 150px; }}
    .tab-panel {{ display: none; }}
    .tab-panel.active {{ display: block; }}
    .count {{ display: grid; min-width: 118px; }}
    .count strong {{ font-size: 20px; }}
    .count span {{ color: var(--muted); font-size: 12px; }}
    .helpers {{ display: grid; grid-template-columns: 130px minmax(0,1fr); gap: 8px 12px; }}
    .helpers dt {{ color: var(--green); font-weight: 800; }}
    .helpers dd {{ margin: 0; color: var(--muted); overflow-wrap: anywhere; }}
    .grid {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }}
    .card, .panel {{ border: 1px solid var(--line); background: var(--panel); border-radius: 8px; padding: 14px; min-width: 0; }}
    .card a {{ display: inline-block; margin-top: 8px; }}
    .eyebrow {{ margin: 0 0 6px; color: var(--green); font-size: 12px; font-weight: 800; text-transform: uppercase; }}
    .surface-list, .blocked-list {{ display: grid; gap: 8px; padding-left: 18px; color: var(--muted); }}
    .blocked-list span {{ display: block; color: var(--muted); margin-top: 3px; }}
    .action-row {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }}
    button {{ border: 1px solid var(--line); border-radius: 7px; padding: 10px; background: var(--panel-2); color: var(--text); text-align: left; }}
    .rail-box {{ border: 1px solid var(--line); border-radius: 8px; background: var(--panel); padding: 10px; margin: 10px 0; }}
    .rail-box summary {{ cursor: pointer; color: var(--accent); font-weight: 800; }}
    .warning {{ color: var(--risk); }}
    code {{ color: var(--green); overflow-wrap: anywhere; }}
    @media (max-width: 980px) {{
      .shell {{ grid-template-columns: 1fr; }}
      nav, aside {{ border: 0; border-bottom: 1px solid var(--line); }}
      .grid, .action-row {{ grid-template-columns: 1fr; }}
      h1 {{ font-size: 28px; }}
    }}
  </style>
</head>
<body>
  <div class="shell">
    <nav>
      <div class="brand">
        <strong>AMTL Finance Suite</strong>
        <p>Finance workbench for Genie, Ledger and Fin Strategist.</p>
      </div>
      {nav_html}
    </nav>
    <main>
      <section class="hero">
        <p class="eyebrow">{escape(_display_text(active["role"]))}</p>
        <h1>{escape(_display_text(active["name"]))}</h1>
        <p>{escape(_display_text(COMPLIANCE_BOUNDARY))}</p>
        <div class="pill-row">
          <span class="pill">manual/private data</span>
          <span class="pill">receipts on every action</span>
          <span class="pill">no live bank writes</span>
          <span class="pill">no tax lodgement</span>
        </div>
      </section>
      {synthetic_admin_panel}
      <section class="grid">{module_cards}</section>
      <section class="panel" style="margin-top:14px">
        <h2>Current surface</h2>
        {current_surface_tabs}
      </section>
      {product_panel}
      <section class="panel" style="margin-top:14px">
        <h2>Review actions</h2>
        <div class="action-row">
          <button onclick="fetch('/finance/api/receipts', {{method:'POST', headers:{{'content-type':'application/json'}}, body:JSON.stringify({{kind:'ui_receipt', summary:'Created from Finance Suite UI'}})}}).then(r=>r.json()).then(j=>alert(j.id))">Create receipt</button>
          <button onclick="fetch('/finance/api/imports/fixture', {{method:'POST', headers:{{'content-type':'application/json'}}, body:JSON.stringify({{filename:'ui-fixture.csv'}})}}).then(r=>r.json()).then(j=>alert(j.id))">Ingest fixture</button>
          <button onclick="fetch('/finance/api/reports/pack', {{method:'POST', headers:{{'content-type':'application/json'}}, body:JSON.stringify({{report_type:'ui_local_pack'}})}}).then(r=>r.json()).then(j=>alert(j.id))">Create report pack</button>
        </div>
      </section>
    </main>
    <aside>
      <h2>Context</h2>
      <details class="rail-box">
        <summary>Limits</summary>
        <p>Status: <code>{escape(_display_text(summary["status"]))}</code></p>
        <p>Evidence store: private workspace records.</p>
        <p class="warning">External integrations stay blocked until approval and destination receipts exist.</p>
      </details>
      <details class="rail-box">
        <summary>Details</summary>
        <div id="right-rail-context"></div>
      </details>
      <details class="rail-box">
        <summary>Approval gates</summary>
        <ul class="blocked-list">{blocked_rows}</ul>
      </details>
    </aside>
  </div>
  <script>
    function openFinanceTab(event, id) {{
      const stage = document.getElementById(id)?.closest('.panel');
      if (!stage) return;
      stage.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
      stage.querySelectorAll('.tab-button').forEach(button => button.classList.remove('active'));
      document.getElementById(id)?.classList.add('active');
      event.currentTarget.classList.add('active');
    }}
    const contextTemplate = document.getElementById('finance-right-rail-context');
    if (contextTemplate) {{
      document.getElementById('right-rail-context').append(contextTemplate.content.cloneNode(true));
    }} else {{
      document.getElementById('right-rail-context').innerHTML = '<p>Open a product or workspace to show focused details here.</p>';
    }}
    function financePost(url, payload) {{
      fetch(url, {{method:'POST', headers:{{'content-type':'application/json'}}, body:JSON.stringify(payload)}})
        .then(r=>r.json())
        .then(j=>alert(j.receipt_id || j.id || j.status || j.state || 'review action complete'))
        .catch(err=>alert('review action failed: '+err.message));
    }}
  </script>
</body>
</html>"""


def _risk_specialist_html(screen: str = "source-review") -> str:
    data = risk_source_review()
    health = risk_health()
    screens = {
        "source-review": {
            "title": "Risk Intelligence Source Review",
            "eyebrow": "source citations, confidence and gaps",
            "tabs": ["Candidate Inbox", "Source Citations", "Confidence & Gaps", "Category Mapper", "Override History"],
            "rows": data["source_records"][:12],
            "row_title": "Source records",
            "row_fields": ["source_type", "source_system", "title", "created_at"],
            "buttons": [
                ("Index Approved Sources", "/finance/api/risk/source-index", "{include_nas:false,max_nas_files:25,max_seconds:8}"),
                ("Scan Local Sources", "/finance/api/risk/source-scan", "{}"),
                ("Create Draft Candidates", "/finance/api/risk/generate", "{}"),
                ("Review Register", "/finance/api/risk/review", "{reviewed_by:'local_user',notes:'Source Review screen review'}"),
            ],
        },
        "candidates": {
            "title": "Risk Candidate Inbox",
            "eyebrow": "draft candidates before human approval",
            "tabs": ["Draft Candidates", "Low Confidence", "Missing Owner", "Source Evidence", "Approve/Edit"],
            "rows": data["candidates"][:12],
            "row_title": "Draft candidates",
            "row_fields": ["candidate_id", "suggested_category", "suggested_subcategory", "suggested_severity", "confidence"],
            "buttons": [
                ("Generate Candidates", "/finance/api/risk/generate", "{}"),
                ("Reload Demo", "/finance/api/risk/reload-synthetic", "{}"),
                ("Synthetic Preview", "/finance/api/risk/remove-synthetic", "{preview:true}"),
            ],
        },
        "mitigations": {
            "title": "Risk Mitigation Planner",
            "eyebrow": "controls, owners, cadence and next action",
            "tabs": ["Mitigation Plan", "Current Controls", "Contingency", "Owner", "Review Cadence"],
            "rows": data["risks"][:12],
            "row_title": "Risk rows",
            "row_fields": ["risk_id", "title", "owner", "mitigation_plan", "review_cadence"],
            "buttons": [
                ("Review Register", "/finance/api/risk/review", "{reviewed_by:'local_user',notes:'Mitigation Planner review'}"),
                ("Create Risk Report", "/finance/api/reports/generate", "{report_type:'risk_mitigation_pack'}"),
                ("Show Receipts", "/finance/api/risk/receipts", None),
            ],
        },
        "decision-gates": {
            "title": "Risk Decision Gates",
            "eyebrow": "do-not-proceed checks before external action",
            "tabs": ["Decision", "Required Evidence", "Missing Evidence", "Red Flags", "Safe Next Question"],
            "rows": data["decision_gates"][:12],
            "row_title": "Decision gates",
            "row_fields": ["decision_being_considered", "human_approval_needed", "missing_evidence", "red_flags", "safe_next_question"],
            "buttons": [
                ("Final Browser Action Gate", "/finance/api/browser-assist/block-final-action", "{platform:'xero',action:'submit'}"),
                ("External Export Gate", "/finance/api/reports/export", "{destination:'risk_decision_external_export'}"),
                ("Review Register", "/finance/api/risk/review", "{reviewed_by:'local_user',notes:'Decision Gate review'}"),
            ],
        },
        "overrides": {
            "title": "Risk Overrides & Review History",
            "eyebrow": "user changes preserve system suggestions",
            "tabs": ["Overrides", "Reviews", "Merges", "Archives", "Receipts"],
            "rows": (data["overrides"] or data["reviews"] or data["merges"] or data["archives"])[:12],
            "row_title": "Override and review records",
            "row_fields": ["risk_id", "field", "value", "reason", "created_at"],
            "buttons": [
                ("Review Register", "/finance/api/risk/review", "{reviewed_by:'local_user',notes:'Overrides screen review'}"),
                ("Show Register", "/finance/api/risk/register", None),
                ("Show Receipts", "/finance/api/risk/receipts", None),
            ],
        },
        "receipts": {
            "title": "Risk Receipts & Evidence",
            "eyebrow": "local proof of risk actions",
            "tabs": ["Receipts", "Evidence Events", "Reports", "Synthetic Controls", "Boundary"],
            "rows": data["receipts"][:12],
            "row_title": "Risk receipts",
            "row_fields": ["id", "kind", "summary", "created_at", "external_write"],
            "buttons": [
                ("Create Risk Report", "/finance/api/reports/generate", "{report_type:'risk_receipt_pack'}"),
                ("Filter Risk Evidence", "/finance/api/evidence/filter", "{product:'risk_intelligence'}"),
                ("Show Receipts", "/finance/api/risk/receipts", None),
            ],
        },
    }
    config = screens.get(screen, screens["source-review"])
    menu = [
        ("Source Review", "/finance/strategist/risk/source-review"),
        ("Candidates", "/finance/strategist/risk/candidates"),
        ("Mitigations", "/finance/strategist/risk/mitigations"),
        ("Decision Gates", "/finance/strategist/risk/decision-gates"),
        ("Overrides", "/finance/strategist/risk/overrides"),
        ("Receipts", "/finance/strategist/risk/receipts"),
        ("Main Risk", "/finance/strategist/risk"),
    ]
    menu_html = "".join(f'<a class="nav-link {"active" if href.endswith(screen) else ""}" href="{href}">{escape(label)}</a>' for label, href in menu)
    tabs = "".join(f'<span class="tab">{escape(tab)}</span>' for tab in config["tabs"])
    counts = "".join(
        f'<a class="count" href="/finance/api/risk/source-review#{escape(key)}"><strong>{escape(str(value))}</strong><span>{escape(key.replace("_", " "))}</span></a>'
        for key, value in data["counts"].items()
    )

    def value_for(row: dict, field: str) -> str:
        value = row.get(field, "")
        if isinstance(value, list):
            value = ", ".join(str(item) for item in value[:3])
        if isinstance(value, dict):
            value = "; ".join(f"{key}: {val}" for key, val in list(value.items())[:3])
        return escape(str(value if value is not None else ""))

    if config["rows"]:
        row_html = "".join(
            "<tr>" + "".join(f"<td>{value_for(row, field)}</td>" for field in config["row_fields"]) + "</tr>"
            for row in config["rows"]
        )
    else:
        row_html = f'<tr><td colspan="{len(config["row_fields"])}">No local rows yet. Use the screen actions to create draft local evidence.</td></tr>'
    headings = "".join(f"<th>{escape(field.replace('_', ' ').title())}</th>" for field in config["row_fields"])
    button_html = ""
    for label, url, payload in config["buttons"]:
        if payload is None:
            button_html += f"<button onclick=\"fetch('{url}').then(r=>r.json()).then(j=>alert(JSON.stringify(j).slice(0,220)))\">{escape(label)}</button>"
        else:
            button_html += f"<button onclick=\"financePost('{url}',{payload})\">{escape(label)}</button>"
    category_groups = "".join(
        f"<article><strong>{escape(group)}</strong><span>{escape(', '.join(items[:6]))}</span></article>"
        for group, items in health["category_groups"].items()
    )
    contract = "".join(f"<dt>{escape(key.replace('_', ' ').title())}</dt><dd>{escape(value)}</dd>" for key, value in data["screen_contract"].items())
    return f"""<!doctype html>
<html lang="en-AU">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(config["title"])}</title>
  <style>
    :root {{ color-scheme: dark; --bg:#10120f; --panel:#171a15; --panel2:#20241d; --line:#3a3429; --text:#f0eee7; --muted:#b9b1a0; --accent:#c9a96e; --green:#8ea78f; --risk:#dc8f86; font-family:"Segoe UI", Aptos, system-ui, sans-serif; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; background:var(--bg); color:var(--text); }}
    .shell {{ display:grid; grid-template-columns:250px minmax(0,1fr) 340px; min-height:100vh; }}
    nav, aside {{ padding:18px; background:#111410; border-color:var(--line); }}
    nav {{ border-right:1px solid var(--line); }}
    aside {{ border-left:1px solid var(--line); }}
    main {{ padding:22px; min-width:0; }}
    a {{ color:var(--accent); text-decoration:none; }}
    .nav-link {{ display:block; padding:10px; border-radius:7px; color:var(--muted); }}
    .nav-link.active, .nav-link:hover {{ background:var(--panel2); color:var(--text); }}
    h1 {{ margin:0 0 8px; font-size:32px; letter-spacing:0; }}
    h2 {{ margin:0 0 10px; font-size:21px; }}
    p, td, dd, span {{ color:var(--muted); }}
    .eyebrow {{ color:var(--green); font-size:12px; font-weight:800; text-transform:uppercase; margin:0 0 8px; }}
    .panel {{ border:1px solid var(--line); background:var(--panel); border-radius:8px; padding:14px; margin-top:14px; }}
    .tabs, .counts, .actions {{ display:flex; flex-wrap:wrap; gap:8px; margin:10px 0; }}
    .tab, .count {{ border:1px solid var(--line); background:var(--panel2); border-radius:7px; padding:8px 9px; }}
    .count {{ display:grid; min-width:112px; }}
    .count strong {{ font-size:20px; color:var(--text); }}
    button {{ border:1px solid var(--line); border-radius:7px; padding:10px; background:var(--panel2); color:var(--text); }}
    table {{ width:100%; border-collapse:collapse; table-layout:fixed; }}
    th, td {{ border-bottom:1px solid var(--line); padding:9px; text-align:left; vertical-align:top; overflow-wrap:anywhere; }}
    th {{ color:var(--green); font-size:12px; text-transform:uppercase; }}
    .category-grid {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }}
    .category-grid article {{ border:1px solid var(--line); border-radius:7px; padding:10px; background:var(--panel2); }}
    .category-grid span {{ display:block; margin-top:6px; }}
    dl {{ display:grid; grid-template-columns:140px minmax(0,1fr); gap:8px 12px; }}
    dt {{ color:var(--green); font-weight:800; }}
    dd {{ margin:0; overflow-wrap:anywhere; }}
    .warning {{ color:var(--risk); }}
    @media (max-width:980px) {{ .shell {{ grid-template-columns:1fr; }} nav, aside {{ border:0; border-bottom:1px solid var(--line); }} .category-grid {{ grid-template-columns:1fr; }} h1 {{ font-size:26px; }} }}
  </style>
</head>
<body>
  <div class="shell">
    <nav>
      <strong>Risk Intelligence</strong>
      <p>Dedicated local/internal screens.</p>
      {menu_html}
    </nav>
    <main>
      <p class="eyebrow">{escape(config["eyebrow"])}</p>
      <h1>{escape(config["title"])}</h1>
      <p>{escape(data["boundary"])}</p>
      <section class="panel">
        <h2>Screen controls</h2>
        <div class="tabs">{tabs}</div>
        <div class="counts">{counts}</div>
        <div class="actions">{button_html}</div>
      </section>
      <section class="panel">
        <h2>{escape(config["row_title"])}</h2>
        <table><thead><tr>{headings}</tr></thead><tbody>{row_html}</tbody></table>
      </section>
      <section class="panel">
        <h2>Risk category mapper</h2>
        <div class="category-grid">{category_groups}</div>
      </section>
    </main>
    <aside>
      <h2>Screen contract</h2>
      <dl>{contract}</dl>
      <p class="warning">Approved local/RAG source indexing is allowed with the two named NAS exclusions. Automatic population creates drafts only. Human review owns approval, overrides and any destination action.</p>
      <p>API: <code>/finance/api/risk/source-review</code></p>
    </aside>
  </div>
  <script>
    function financePost(url, payload) {{
      fetch(url, {{method:'POST', headers:{{'content-type':'application/json'}}, body:JSON.stringify(payload)}})
        .then(r=>r.json())
        .then(j=>alert(j.receipt_id || j.id || j.status || j.state || JSON.stringify(j).slice(0,180)))
        .catch(err=>alert('local action failed: '+err.message));
    }}
  </script>
</body>
</html>"""


@router.get("/finance", response_class=HTMLResponse)
@router.get("/finance/", response_class=HTMLResponse)
async def finance_home():
    return HTMLResponse(_html("home"))


@router.get("/finance/strategist/risk", response_class=HTMLResponse)
async def finance_strategist_risk():
    return HTMLResponse(_html("risk"))


@router.get("/finance/strategist/risk/source-review", response_class=HTMLResponse)
async def finance_strategist_risk_source_review():
    return HTMLResponse(_risk_specialist_html("source-review"))


@router.get("/finance/strategist/risk/candidates", response_class=HTMLResponse)
async def finance_strategist_risk_candidates_page():
    return HTMLResponse(_risk_specialist_html("candidates"))


@router.get("/finance/strategist/risk/mitigations", response_class=HTMLResponse)
async def finance_strategist_risk_mitigations_page():
    return HTMLResponse(_risk_specialist_html("mitigations"))


@router.get("/finance/strategist/risk/decision-gates", response_class=HTMLResponse)
async def finance_strategist_risk_decision_gates_page():
    return HTMLResponse(_risk_specialist_html("decision-gates"))


@router.get("/finance/strategist/risk/overrides", response_class=HTMLResponse)
async def finance_strategist_risk_overrides_page():
    return HTMLResponse(_risk_specialist_html("overrides"))


@router.get("/finance/strategist/risk/receipts", response_class=HTMLResponse)
async def finance_strategist_risk_receipts_page():
    return HTMLResponse(_risk_specialist_html("receipts"))


@router.get("/finance/ledger/forensics", response_class=HTMLResponse)
async def finance_ledger_forensics_page():
    return HTMLResponse(_html("forensics"))


@router.get("/finance/rag", response_class=HTMLResponse)
async def finance_rag_page():
    return HTMLResponse(_html("rag"))


@router.get("/finance/runway", response_class=HTMLResponse)
async def finance_runway_page():
    return HTMLResponse(_html("runway"))


@router.get("/finance/cross-app", response_class=HTMLResponse)
async def finance_cross_app_page():
    return HTMLResponse(_html("cross-app"))


@router.get("/finance/{section}", response_class=HTMLResponse)
async def finance_section(section: str):
    if section == "api":
        raise HTTPException(status_code=404, detail="Use /finance/api/... routes.")
    allowed = {"genie", "ledger", "strategist", "reports", "imports", "evidence", "admin", "browser-assist", "rag", "runway", "cross-app"}
    if section not in allowed:
        raise HTTPException(status_code=404, detail="Finance Suite route not found.")
    return HTMLResponse(_html(section))


@router.get("/finance/api/health")
async def finance_health():
    return {
        "product": "AMTL Finance Suite",
        "status": "DONE_LOCAL_INTERNAL_FINANCE_SUITE_ONLY",
        "mode": "local_internal_only",
        "boundary": COMPLIANCE_BOUNDARY,
        "modules": [
            {
                "id": module["id"],
                "name": module["name"],
                "route": module["route"],
                "status": module["status"],
            }
            for module in MODULES
        ],
        "blocked_actions": "see /finance/api/summary",
        "local_paths": {
            "suite_routes": [
                "/finance/",
                "/finance/genie",
                "/finance/ledger",
                "/finance/strategist",
                "/finance/strategist/risk",
                "/finance/rag",
                "/finance/runway",
                "/finance/ledger/forensics",
                "/finance/reports",
                "/finance/imports",
                "/finance/evidence",
                "/finance/browser-assist",
                "/finance/admin",
            ],
            "deep_summary": "/finance/api/summary",
        },
        "health_contract": "fast_liveness_only",
        "deep_summary_note": "Use /finance/api/summary for counts and state-backed product details.",
    }


@router.get("/finance/api/summary")
async def finance_summary():
    return suite_summary()


@router.get("/finance/api/receipts")
async def finance_receipts():
    return {"receipts": receipts()}


@router.post("/finance/api/receipts")
async def finance_create_receipt(request: ReceiptRequest):
    return create_receipt(request.kind, request.summary, request.source_refs, request.payload)


@router.get("/finance/api/demo-data-status")
async def finance_demo_data_status():
    return demo_data_status()


@router.get("/finance/api/ai/readiness")
async def finance_ai_readiness():
    return ai_provider_readiness()


@router.post("/finance/api/ai/run")
async def finance_ai_run(request: AppAiTaskRequest):
    return await run_app_ai_task(request.task_requested, request.model_tier)


@router.get("/finance/api/ai/receipts")
async def finance_ai_receipts():
    return {"receipts": ai_task_receipts()}


@router.post("/finance/api/remove-synthetic")
async def finance_remove_synthetic(request: RemoveSyntheticRequest):
    return remove_synthetic(preview=request.preview)


@router.post("/finance/api/restore-synthetic")
async def finance_restore_synthetic():
    return restore_synthetic()


@router.post("/finance/api/imports/fixture")
async def finance_fixture_import(request: ImportRequest):
    try:
        return ingest_fixture(request.csv_text, request.filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/strategist/scenario")
async def finance_scenario(request: ScenarioRequest):
    return scenario_run(
        monthly_revenue=request.monthly_revenue,
        monthly_costs=request.monthly_costs,
        cash_on_hand=request.cash_on_hand,
        price_change_percent=request.price_change_percent,
    )


@router.post("/finance/api/reports/pack")
async def finance_report_pack(request: ReportRequest):
    return create_report_pack(request.report_type)


@router.get("/finance/api/reports/health")
async def finance_reports_health():
    return reports_health()


@router.post("/finance/api/reports/generate")
async def finance_reports_generate(request: ReportRequest):
    return generate_finance_report(request.report_type)


@router.get("/finance/api/reports/receipts")
async def finance_reports_receipts():
    return {"receipts": reports_receipts()}


@router.post("/finance/api/reports/export")
async def finance_reports_export(request: ReportsExportRequest):
    return blocked_external_export("reports")


@router.get("/finance/api/evidence/health")
async def finance_evidence_health():
    return evidence_health()


@router.get("/finance/api/evidence/events")
async def finance_evidence_events():
    return {"events": evidence_events()}


@router.post("/finance/api/evidence/filter")
async def finance_evidence_filter(request: EvidenceFilterRequest):
    return filter_evidence(product=request.product, event_type=request.event_type, query=request.query)


@router.get("/finance/api/evidence/receipts")
async def finance_evidence_receipts():
    return {"receipts": evidence_receipts()}


@router.get("/finance/api/admin/health")
async def finance_admin_health():
    return admin_health()


@router.get("/finance/api/admin/status")
async def finance_admin_status():
    return admin_status()


@router.get("/finance/api/admin/receipts")
async def finance_admin_receipts():
    return {"receipts": admin_receipts()}


@router.get("/finance/api/browser-assist/health")
async def finance_browser_assist_health():
    return browser_assist_health()


@router.post("/finance/api/browser-assist/prepare")
async def finance_browser_assist_prepare(request: BrowserAssistPrepareRequest):
    try:
        return prepare_browser_assist(request.platform, request.task, request.source)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/browser-assist/pay-stub")
async def finance_browser_assist_pay_stub(request: BrowserAssistPayStubRequest):
    try:
        return prepare_pay_stub_assist(
            request.platform,
            request.employee_name,
            request.pay_period_start,
            request.pay_period_end,
            request.pay_date,
            request.gross_pay,
            request.net_pay,
            request.tax_withheld,
            request.superannuation,
            request.earnings,
            request.deductions,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/browser-assist/block-final-action")
async def finance_browser_assist_block_final_action(request: BrowserAssistBlockRequest):
    try:
        return block_browser_assist_final_action(request.platform, request.action)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/browser-assist/destination-receipts")
async def finance_browser_assist_destination_receipt(request: BrowserAssistDestinationReceiptRequest):
    try:
        return record_destination_owned_receipt(
            request.platform,
            request.destination_receipt_id,
            request.action,
            request.human_summary,
            request.session_id,
            request.evidence_ref,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/finance/api/browser-assist/destination-receipts")
async def finance_browser_assist_destination_receipts():
    return {"destination_receipts": destination_owned_receipts()}


@router.get("/finance/api/browser-assist/receipts")
async def finance_browser_assist_receipts():
    return {"receipts": browser_assist_receipts()}


@router.get("/finance/api/browser-assist/session-artifacts")
async def finance_browser_assist_session_artifacts(session_id: str | None = None):
    return {"artifacts": browser_assist_artifacts(session_id)}


@router.post("/finance/api/browser-assist/session-artifacts")
async def finance_browser_assist_create_session_artifact(request: BrowserAssistSessionArtifactRequest):
    try:
        return create_browser_assist_session_artifact(request.session_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/finance/api/risk/health")
async def finance_risk_health():
    return risk_health()


@router.get("/finance/api/risk/source-review")
async def finance_risk_source_review():
    return risk_source_review()


@router.post("/finance/api/risk/source-index")
async def finance_risk_source_index(request: RiskSourceIndexRequest):
    return index_risk_sources(
        include_nas=request.include_nas,
        max_nas_files=request.max_nas_files,
        max_seconds=request.max_seconds,
    )


@router.get("/finance/api/risk/register")
async def finance_risk_register():
    return risk_register()


@router.get("/finance/api/risk/candidates")
async def finance_risk_candidates():
    return risk_candidates()


@router.post("/finance/api/risk/source-scan")
async def finance_risk_source_scan():
    return scan_risk_sources()


@router.get("/finance/api/risk/source-scan")
async def finance_risk_source_scan_get():
    return scan_risk_sources()


@router.post("/finance/api/risk/generate")
async def finance_risk_generate():
    return generate_risk_candidates()


@router.post("/finance/api/risk/approve")
async def finance_risk_approve(request: RiskApproveRequest):
    try:
        return approve_risk_candidate(request.candidate_id, request.edits)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/risk/update")
async def finance_risk_update(request: RiskUpdateRequest):
    try:
        return update_risk(request.risk_id, request.updates)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/risk/override")
async def finance_risk_override(request: RiskOverrideRequest):
    try:
        return override_risk_field(
            request.risk_id,
            request.field,
            request.value,
            request.reason,
            request.locked_by_user,
            request.reviewed_by,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/risk/merge")
async def finance_risk_merge(request: RiskMergeRequest):
    try:
        return merge_risks(request.primary_risk_id, request.secondary_risk_id, request.reason)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/risk/archive")
async def finance_risk_archive(request: RiskArchiveRequest):
    try:
        return archive_risk(request.risk_id, request.reason)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/risk/review")
async def finance_risk_review(request: RiskReviewRequest):
    return review_risk_register(request.reviewed_by, request.notes)


@router.get("/finance/api/risk/receipts")
async def finance_risk_receipts():
    return {"receipts": risk_receipts()}


@router.get("/finance/api/risk/demo-data-status")
async def finance_risk_demo_data_status():
    return risk_demo_data_status()


@router.post("/finance/api/risk/remove-synthetic")
async def finance_risk_remove_synthetic(request: RemoveSyntheticRequest):
    return remove_risk_synthetic(preview=request.preview)


@router.post("/finance/api/risk/reload-synthetic")
async def finance_risk_reload_synthetic():
    return reload_risk_synthetic()


@router.get("/finance/api/rag/status")
async def finance_rag_status():
    return rag_health()


@router.get("/finance/api/rag/sources")
async def finance_rag_sources():
    return rag_sources()


@router.post("/finance/api/rag/sources")
async def finance_rag_register_source(request: RagSourceRequest):
    try:
        return register_rag_source(
            request.name,
            request.source_scope,
            request.source_type,
            request.text,
            request.path,
            request.url,
            request.citation,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/rag/search")
async def finance_rag_search(request: RagSearchRequest):
    return search_rag_sources(request.query, request.limit)


@router.post("/finance/api/rag/source-index")
async def finance_rag_source_index(request: RiskSourceIndexRequest):
    return index_risk_sources(
        include_nas=request.include_nas,
        max_nas_files=request.max_nas_files,
        max_seconds=request.max_seconds,
    )


@router.get("/finance/api/runway/health")
async def finance_runway_health():
    return runway_health()


@router.post("/finance/api/runway/cost-scan")
async def finance_runway_cost_scan():
    return run_runway_cost_scan()


@router.post("/finance/api/runway/savings-plan")
async def finance_runway_savings_plan():
    return create_runway_savings_plan()


@router.get("/finance/api/cross-app/health")
async def finance_cross_app_health():
    return cross_app_health()


@router.get("/finance/api/cross-app/destinations")
async def finance_cross_app_destinations():
    return cross_app_destinations()


@router.get("/finance/api/cross-app/outbox")
async def finance_cross_app_outbox(destination_id: str | None = None, signal_type: str | None = None):
    return cross_app_outbox(destination_id=destination_id, signal_type=signal_type)


@router.post("/finance/api/cross-app/dispatch")
async def finance_cross_app_dispatch(request: CrossAppDispatchRequest):
    try:
        return dispatch_cross_app_packets(request.destinations, request.reason)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/finance/api/cross-app/destination-receipts")
async def finance_cross_app_destination_receipts():
    return {"destination_receipts": cross_app_destination_receipts(), "boundary": COMPLIANCE_BOUNDARY}


@router.post("/finance/api/cross-app/destination-receipts")
async def finance_cross_app_destination_receipt(request: CrossAppDestinationReceiptRequest):
    try:
        return record_cross_app_destination_receipt(
            request.destination_id,
            request.packet_id,
            request.destination_receipt_id,
            request.human_summary,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/finance/api/external-actions/{action}")
async def finance_external_action(action: str):
    return external_action_status(action)


@router.get("/finance/api/blocked-actions")
async def finance_blocked_actions():
    return {"blocked_actions": blocked_actions()}


@router.get("/finance/api/{product}/health")
async def finance_product_health(product: str):
    try:
        return product_health(product)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/finance/api/{product}/receipts")
async def finance_product_receipts(product: str):
    try:
        return {"receipts": product_receipts(product)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/finance/api/{product}/demo-data-status")
async def finance_product_demo_data_status(product: str):
    try:
        return product_demo_data_status(product)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/{product}/remove-synthetic")
async def finance_product_remove_synthetic(product: str, request: RemoveSyntheticRequest):
    try:
        return remove_product_synthetic(product, preview=request.preview)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/{product}/reload-synthetic")
async def finance_product_reload_synthetic(product: str):
    try:
        return reload_product_synthetic(product)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/{product}/blocked-action")
async def finance_product_blocked_action(product: str, request: ProductBlockedActionRequest):
    try:
        return product_blocked_action(product, request.action)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/finance/api/genie/ask")
async def finance_genie_ask(request: GenieAskRequest):
    return genie_ask(request.question)


@router.post("/finance/api/ledger/import")
async def finance_ledger_import(request: ImportRequest):
    try:
        return ledger_import(request.csv_text, request.filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/finance/api/ledger/entries")
async def finance_ledger_entries():
    return ledger_entries()


@router.post("/finance/api/ledger/reconcile")
async def finance_ledger_reconcile():
    return ledger_reconcile()


@router.get("/finance/api/ledger/forensics/health")
async def finance_ledger_forensics_health():
    return forensic_accounting_health()


@router.post("/finance/api/ledger/forensics/scan")
async def finance_ledger_forensics_scan():
    return scan_forensic_accounting()


@router.get("/finance/api/ledger/forensics/cases")
async def finance_ledger_forensics_cases():
    return {"cases": forensic_cases(), "boundary": COMPLIANCE_BOUNDARY}


@router.get("/finance/api/ledger/forensics/receipts")
async def finance_ledger_forensics_receipts():
    return {"receipts": forensic_receipts()}


@router.get("/finance/api/strategist/scenarios")
async def finance_strategist_scenarios():
    return strategist_scenarios()


@router.post("/finance/api/strategist/generate")
async def finance_strategist_generate(request: ScenarioRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
    return strategist_generate(payload)
