# Author: Mani Padisetti
"""Transaction routes."""

from fastapi import APIRouter, HTTPException, Query
from app.database import get_db
from app.models.transactions import TransactionCreate, TransactionUpdate

router = APIRouter(prefix="/transactions", tags=["transactions"])


@router.get("")
async def list_transactions(
    source: str | None = None, is_reconciled: bool | None = None,
    category: str | None = None, search: str | None = None,
    from_date: str | None = None, to_date: str | None = None,
    page: int = Query(default=1, ge=1), limit: int = Query(default=50, ge=1, le=500),
):
    with get_db() as conn:
        query = "SELECT * FROM transactions WHERE 1=1"
        count_query = "SELECT COUNT(*) FROM transactions WHERE 1=1"
        params = []
        if source:
            query += " AND source = ?"; count_query += " AND source = ?"; params.append(source)
        if is_reconciled is not None:
            query += " AND is_reconciled = ?"; count_query += " AND is_reconciled = ?"
            params.append(1 if is_reconciled else 0)
        if category:
            query += " AND category = ?"; count_query += " AND category = ?"; params.append(category)
        if search:
            query += " AND (description LIKE ? OR reference LIKE ?)"
            count_query += " AND (description LIKE ? OR reference LIKE ?)"
            params.extend([f"%{search}%", f"%{search}%"])
        if from_date:
            query += " AND date >= ?"; count_query += " AND date >= ?"; params.append(from_date)
        if to_date:
            query += " AND date <= ?"; count_query += " AND date <= ?"; params.append(to_date)
        total = conn.execute(count_query, params).fetchone()[0]
        query += " ORDER BY date DESC, id DESC"
        offset = (page - 1) * limit
        query += " LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = conn.execute(query, params).fetchall()
        return {"transactions": [dict(r) for r in rows], "total": total,
                "page": page, "limit": limit,
                "pages": (total + limit - 1) // limit if total > 0 else 1}


@router.get("/stats")
async def transaction_stats():
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        reconciled = conn.execute("SELECT COUNT(*) FROM transactions WHERE is_reconciled = 1").fetchone()[0]
        income = conn.execute("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE amount > 0").fetchone()[0]
        expenses = conn.execute("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE amount < 0").fetchone()[0]
        by_source = conn.execute("SELECT source, COUNT(*) as count FROM transactions GROUP BY source").fetchall()
        return {"total": total, "reconciled": reconciled, "unreconciled": total - reconciled,
                "total_income": round(income, 2), "total_expenses": round(abs(expenses), 2),
                "net": round(income + expenses, 2),
                "by_source": {r["source"]: r["count"] for r in by_source}}


@router.get("/{transaction_id}")
async def get_transaction(transaction_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM transactions WHERE id = ?", (transaction_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Transaction not found")
        return dict(row)


@router.post("", status_code=201)
async def create_transaction(txn: TransactionCreate):
    with get_db() as conn:
        if txn.account_id:
            account = conn.execute("SELECT id FROM accounts WHERE id = ?", (txn.account_id,)).fetchone()
            if not account:
                raise HTTPException(status_code=400, detail="Invalid account_id")
        cursor = conn.execute(
            """INSERT INTO transactions (date, description, amount, balance, reference, source, category, account_id, bank_account)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (txn.date, txn.description, txn.amount, txn.balance, txn.reference,
             txn.source.value, txn.category, txn.account_id, txn.bank_account),
        )
        row = conn.execute("SELECT * FROM transactions WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.put("/{transaction_id}")
async def update_transaction(transaction_id: int, txn: TransactionUpdate):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM transactions WHERE id = ?", (transaction_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Transaction not found")
        updates = {}
        if txn.description is not None:
            updates["description"] = txn.description
        if txn.category is not None:
            updates["category"] = txn.category
        if txn.account_id is not None:
            account = conn.execute("SELECT id FROM accounts WHERE id = ?", (txn.account_id,)).fetchone()
            if not account:
                raise HTTPException(status_code=400, detail="Invalid account_id")
            updates["account_id"] = txn.account_id
        if txn.is_reconciled is not None:
            updates["is_reconciled"] = 1 if txn.is_reconciled else 0
        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates) + ", updated_at = datetime('now')"
            values = list(updates.values()) + [transaction_id]
            conn.execute(f"UPDATE transactions SET {set_clause} WHERE id = ?", values)
        row = conn.execute("SELECT * FROM transactions WHERE id = ?", (transaction_id,)).fetchone()
        return dict(row)


@router.delete("/{transaction_id}")
async def delete_transaction(transaction_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM transactions WHERE id = ?", (transaction_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Transaction not found")
        journal = conn.execute("SELECT COUNT(*) FROM journal_entries WHERE transaction_id = ?", (transaction_id,)).fetchone()[0]
        if journal > 0:
            raise HTTPException(status_code=400, detail="Cannot delete transaction with journal entries")
        conn.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
        return {"deleted": True, "id": transaction_id}
