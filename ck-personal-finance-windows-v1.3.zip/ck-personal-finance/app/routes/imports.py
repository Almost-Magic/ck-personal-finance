# Author: Mani Padisetti
"""Import routes — CSV upload, preview, confirm, mapping rules."""

from fastapi import APIRouter, HTTPException, UploadFile, File
from app.database import get_db
from app.models.imports import MappingRuleCreate, MappingRuleUpdate, CategoriseRequest
from app.services.import_engine import parse_csv, confirm_import, ai_categorise

router = APIRouter(prefix="/imports", tags=["imports"])


@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    content = await file.read()
    text = content.decode("utf-8-sig")  # Handle BOM

    if file.filename.lower().endswith(".csv"):
        result = parse_csv(text, file.filename)
    else:
        raise HTTPException(status_code=400, detail="Only CSV files are supported")

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/upload-text")
async def upload_text(filename: str, content: str):
    """Upload CSV as text (for testing without multipart)."""
    result = parse_csv(content, filename)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/{batch_id}/confirm")
async def confirm_batch(batch_id: int):
    result = confirm_import(batch_id)
    if "error" in result:
        raise HTTPException(status_code=400 if "already" in result["error"] else 404,
                            detail=result["error"])
    return result


@router.get("/batches")
async def list_batches():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, filename, file_type, total_rows, imported, skipped, duplicates, status, created_at, confirmed_at FROM import_batches ORDER BY id DESC"
        ).fetchall()
        return [dict(r) for r in rows]


@router.get("/batches/{batch_id}")
async def get_batch(batch_id: int):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM import_batches WHERE id = ?", (batch_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Batch not found")
        return dict(row)


# --- Mapping Rules ---

@router.get("/rules")
async def list_rules():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM mapping_rules ORDER BY priority DESC, id").fetchall()
        return [dict(r) for r in rows]


@router.post("/rules", status_code=201)
async def create_rule(rule: MappingRuleCreate):
    with get_db() as conn:
        cursor = conn.execute(
            "INSERT INTO mapping_rules (pattern, account_id, category, priority) VALUES (?, ?, ?, ?)",
            (rule.pattern, rule.account_id, rule.category, rule.priority),
        )
        row = conn.execute("SELECT * FROM mapping_rules WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


@router.put("/rules/{rule_id}")
async def update_rule(rule_id: int, rule: MappingRuleUpdate):
    with get_db() as conn:
        existing = conn.execute("SELECT * FROM mapping_rules WHERE id = ?", (rule_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Rule not found")
        updates = {}
        if rule.pattern is not None:
            updates["pattern"] = rule.pattern
        if rule.account_id is not None:
            updates["account_id"] = rule.account_id
        if rule.category is not None:
            updates["category"] = rule.category
        if rule.priority is not None:
            updates["priority"] = rule.priority
        if rule.is_active is not None:
            updates["is_active"] = 1 if rule.is_active else 0
        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [rule_id]
            conn.execute(f"UPDATE mapping_rules SET {set_clause} WHERE id = ?", values)
        row = conn.execute("SELECT * FROM mapping_rules WHERE id = ?", (rule_id,)).fetchone()
        return dict(row)


@router.delete("/rules/{rule_id}")
async def delete_rule(rule_id: int):
    with get_db() as conn:
        existing = conn.execute("SELECT id FROM mapping_rules WHERE id = ?", (rule_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail="Rule not found")
        conn.execute("DELETE FROM mapping_rules WHERE id = ?", (rule_id,))
        return {"deleted": True, "id": rule_id}


# --- AI Categorisation ---

@router.post("/categorise")
async def categorise(req: CategoriseRequest):
    if not req.descriptions:
        raise HTTPException(status_code=400, detail="No descriptions provided")
    return await ai_categorise(req.descriptions)
