"""CK Personal Finance local/internal cockpit truth endpoints."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from pydantic import BaseModel

from app.services.personal_finance_store import (
    APP_MODE,
    DEMO_MODE,
    SQLITE_SCHEMA_SQL,
    WORKFLOW_IDS,
    audit_delivery,
    create_local_receipt,
    create_report_export,
    get_drilldown,
    get_persistence_snapshot,
    index_nas_sources,
    index_approved_rag_sources,
    save_user_upload,
    init_personal_finance_store,
    search_rag,
    using_sqlite,
)

from app.services.local_ai import (
    complete as local_ai_complete,
    model_policy as local_ai_policy,
    route as local_ai_route,
)

router = APIRouter(prefix="/personal-finance", tags=["personal-finance"])


@router.get("/launch-identity")
async def launch_identity(request: Request):
    """Read-only readiness proof for this launch's own browser helper.

    Answers only to the per-instance launch token (X-CKPF-Stop-Token header);
    a wrong or missing token gets 401. Reading this never stops the app.
    When no token file is configured the probe stays disabled (always 401).
    """
    import secrets as _secrets

    from app.config import get_stop_token
    expected = get_stop_token()
    token = request.headers.get("X-CKPF-Stop-Token") or ""
    if not expected or not token or not _secrets.compare_digest(token, expected):
        raise HTTPException(status_code=401, detail="Unknown launch token.")
    return {"product": "CK Personal Finance", "ready": True}


class ReceiptRequest(BaseModel):
    decision_type: str = "weekly_review"
    context: str = "Local CK Personal Finance review action."


class ReportRequest(BaseModel):
    report_type: str = "local_review_pack"


class RagSearchRequest(BaseModel):
    query: str = "tax evidence"
    limit: int = 5


class AiRouteRequest(BaseModel):
    task_kind: str = "field_explanation"
    reasoning_level: str = "low"


class AiCompleteRequest(BaseModel):
    prompt: str
    task_kind: str = "ask_money"
    reasoning_level: str = "low"


class NasIndexRequest(BaseModel):
    max_files: int = 120
    max_chunks_per_file: int = 3


SAFE_LOCAL_WORKFLOWS = [
    ("dashboard", "Dashboard", "DONE", "public/index.html", "Calm overview, user controls, privacy boundary, and live proof panels"),
    ("accounts", "Accounts", "DONE", "app/services/personal_finance_store.py", "Personal account groups persist with source state and drilldown rows"),
    ("transactions", "Transactions", "DONE", "app/services/personal_finance_store.py", "Import rollback receipts, source confidence, and local drilldown are wired"),
    ("income", "Income", "DONE", "app/services/personal_finance_store.py", "Household income appears in report/export and scenario payloads"),
    ("expenses", "Expenses", "DONE", "app/services/personal_finance_store.py", "Bills/subscriptions are represented through reminders, scenarios, and report rows"),
    ("cashflow", "Cashflow", "DONE", "app/services/personal_finance_store.py", "Local scenarios and review-pack export show cash movement without external writes"),
    ("budget", "Budget", "DONE", "app/services/personal_finance_store.py", "Local review pack and field helpers cover budget variance and calm explanations"),
    ("savings-goals", "Savings goals", "DONE", "app/services/personal_finance_store.py", "Savings goals persist and drill into named rows"),
    ("debt-loans", "Debt and loans", "DONE", "app/services/personal_finance_store.py", "Debt plans persist with repayment scenario support"),
    ("net-worth", "Net worth", "DONE", "app/services/personal_finance_store.py", "Account groups include assets/liabilities/super and report exports link to source rows"),
    ("tax-evidence", "Tax and document evidence", "DONE", "app/services/personal_finance_store.py", "Approved source docs are indexed for local text search with disclaimers"),
    ("receipts-files", "Receipts and files", "DONE", "app/services/personal_finance_store.py", "Document evidence and local receipts persist; external send remains disabled"),
    ("alerts-reminders", "Alerts and reminders", "DONE", "app/services/personal_finance_store.py", "Local reminder records exist with cadence, due date, and source refs"),
    ("reports", "Reports", "DONE", "app/services/personal_finance_store.py", "Report/export receipts are local, source-linked, and marked not sent"),
    ("scenario-planner", "Scenario planner", "DONE", "app/services/personal_finance_store.py", "Local what-if scenarios persist with inputs, outputs, and no-advice boundary"),
    ("privacy-risk", "Risk and privacy boundaries", "DONE", "app/routes/personal_finance.py", "No advice, no bank API, external AI disabled, no external write"),
    ("import-reconcile", "Import and reconcile", "DONE", "app/services/personal_finance_store.py", "Preview-only rollback receipts and source confidence are visible"),
    ("local-notes", "Local notes and decisions", "DONE", "app/services/personal_finance_store.py", "Decision receipts persist without external write"),
    ("cross-app", "Cross-app handoffs", "DONE", "app/services/personal_finance_store.py", "Draft-only handoff records exist for AMTL apps; no receiver mutation"),
    ("admin-settings", "Admin and settings", "DONE", "app/routes/personal_finance.py", "Admin proof is behind Admin/Proof and includes DB/RAG/route truth"),
    ("nas-source-indexing", "NAS source indexing", "DONE", "app/services/personal_finance_store.py", "Feature not in this build"),
    ("external-action-gates", "External action gates", "DONE", "app/routes/personal_finance.py", "Bank/source/write/deploy actions are explicit approval targets with receipts, not silent UI buttons"),
    ("user-csv-pdf-upload", "User CSV/PDF upload", "DONE", "app/routes/personal_finance.py", "Users can provide local CSV or PDF evidence; files are stored locally, indexed, and receipt-backed with external_send=false"),
]


BUTTONS = [
    {"id": "review-week", "label": "Create review receipt", "truth": "posts_local_decision_receipt", "status": "wired"},
    {"id": "import-preview", "label": "Show import rollback", "truth": "reads_import_rollback_receipts", "status": "wired"},
    {"id": "export-report", "label": "Create local report", "truth": "posts_local_report_export_receipt", "status": "wired"},
    {"id": "rag-search", "label": "Search evidence", "truth": "runs_local_text_search", "status": "wired"},
    {"id": "copy-privacy", "label": "Copy privacy receipt", "truth": "copies_static_local_boundary_receipt", "status": "wired"},
    {"id": "upload-csv-pdf", "label": "Upload CSV/PDF", "truth": "stores_user_file_locally_indexes_evidence_and_returns_receipt", "status": "wired"},
]


def _matrix() -> list[dict[str, str]]:
    return [
        {
            "id": row_id,
            "surface": surface,
            "status": "PARTIAL",
            "implementation_location": location,
            "evidence_path": "app/services/personal_finance_store.py",
            "test_or_browser_proof": "focused API tests, route proof, browser QA, five-loop audit",
            "gap": result,
            "exact_next_fix": "Verify the full user journey; stored records do not establish an implemented workflow.",
        }
        for row_id, surface, status, location, result in SAFE_LOCAL_WORKFLOWS
    ]


@router.get("/cockpit")
def cockpit():
    """Return the local/internal CK Personal Finance delivery truth."""

    try:
        init_personal_finance_store()
        persistence = get_persistence_snapshot()
        dependency_error = None
    except Exception as exc:
        persistence = {
            "store": APP_MODE,
            "runtime_state": "unavailable",
            "search_contract": {"method": "text", "rag_status": "unavailable"},
            "profile": None,
            "table_counts": {"finance_document_evidence": 0},
            "savings_goals": [],
            "debt_plans": [],
            "latest_receipts": [],
            "blocked_external_actions": [
                "live_bank_connection",
                "provider_or_model_send",
                "regulated_financial_advice",
                "external_write",
            ],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        dependency_error = "Local SQLite storage is unavailable. Check the data folder."
    matrix = _matrix()
    done = sum(1 for row in matrix if row["status"] == "DONE")
    partial = sum(1 for row in matrix if row["status"] == "PARTIAL")
    missing = sum(1 for row in matrix if row["status"] == "NOT IMPLEMENTED")
    local_complete = using_sqlite() and dependency_error is None
    reason = (
        "Local records are available. Workflow completion requires independent testing; external AI is disabled."
        if local_complete
        else "Local SQLite storage could not be opened."
    )
    return {
        "product": "CK Personal Finance",
        "mode": "synthetic_demo" if DEMO_MODE else "local_internal_private",
        "source_truth": {
            "active_tree": "C:/AMTL/repos/elaine-complete-record-push/Source and Brand/Finance App/The Ledger",
            "recovered_app_name": "The Ledger",
            "recovered_positioning": "Recovered finance app adapted to CK Personal Finance local/internal scope",
            "ck_personal_finance_fit": "local_records_available" if local_complete else "fallback_partial",
        },
        "claim": {
            "done_local_internal": False,
            "mani_100_allowed": False,
            "database_ready": local_complete,
            "reason": reason,
        },
        "privacy": {
            "regulated_financial_advice": "not_provided",
            "bank_api_connection": "disabled_without_explicit_approval",
            "provider_or_model_send": "external_providers_disabled",
            "external_write": False,
            "demo_data_label_required": True,
        },
        "ai_provider": {"message": "Feature not in this build", "provider_called": False},
        "database": {
            "configured_path": "CKPF_DATA_DIR/personal-finance.sqlite3",
            "store_kind": APP_MODE,
            "sqlite_truth": "pass_active_runtime" if local_complete else "unavailable",
            "search_truth": persistence["search_contract"],
            "dependency_error": dependency_error,
        },
        "rag": {
            "needed_for_receipts_statements_documents": True,
            "configured": persistence["table_counts"]["finance_document_evidence"] > 0,
            "truth": persistence["search_contract"]["rag_status"],
        },
        "persistence": persistence,
        "counts": {"done": done, "partial": partial, "not_implemented": missing, "total": len(matrix)},
        "matrix": matrix,
        "buttons": BUTTONS,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


@router.get("/actions")
def actions():
    """Return safe local actions for the browser cockpit."""

    return {
        "safe_actions": [
            "create_local_review_receipt",
            "show_import_rollback_receipts",
            "create_local_report_export",
            "search_local_rag_evidence",
            "show_local_review_policy",
            "upload_user_csv_or_pdf_local_evidence",
            "copy_privacy_boundary_receipt",
            "open_named_row_drilldown",
        ],
        "blocked_actions": [
            "regulated_financial_advice",
            "live_bank_connection",
            "external_provider_model_send",
            "source_system_write",
            "public_release_or_deploy",
        ],
        "next_best_slice": "Start with the exact stored rows, then create a review receipt or download a report.",
    }


@router.get("/beyond-local/status")
def beyond_local_status():
    return {
        "product": "CK Personal Finance",
        "status": "LOCAL_DEMO_EXTERNAL_ACTIONS_DISABLED",
        "done": ["local_records", "local_review_receipts", "local_report_download"],
        "partial": ["Full workflow and real-data deployment verification remain outstanding."],
        "missing": [],
        "blocked": [{"item": item} for item in ["live_bank_cdr_connection", "external_provider_execution", "public_deployment"]],
    }


@router.get("/persistence")
def persistence():
    return get_persistence_snapshot()


@router.get("/sqlite-schema")
def sqlite_schema():
    return {
        "product": "CK Personal Finance",
        "schema_sql": SQLITE_SCHEMA_SQL.strip(),
        "credential_boundary": "No database password or secret is exposed by this endpoint.",
        "external_write": False,
    }


@router.post("/receipts")
def receipts(request: ReceiptRequest):
    return create_local_receipt(request.decision_type, request.context)


@router.get("/drilldown/{surface}")
def drilldown(surface: str):
    return get_drilldown(surface)


@router.post("/reports")
def reports(request: ReportRequest):
    return create_report_export(request.report_type)


@router.post("/rag/index")
def rag_index():
    return index_approved_rag_sources()


@router.post("/sources/nas/index")
def nas_index(request: NasIndexRequest):
    return index_nas_sources(request.max_files, request.max_chunks_per_file)


@router.post("/uploads")
def upload_local_evidence(file: UploadFile = File(...)):
    suffix = (file.filename or "").lower().rsplit(".", 1)[-1]
    if suffix not in {"csv", "pdf"}:
        raise HTTPException(status_code=400, detail="Only CSV and PDF uploads are accepted.")
    try:
        return save_user_upload(file.file, file.filename or "upload", file.content_type)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/rag/search")
def rag_search_get(q: str = "tax evidence", limit: int = 5):
    return search_rag(q, limit)


@router.post("/rag/search")
def rag_search_post(request: RagSearchRequest):
    return search_rag(request.query, request.limit)


@router.get("/ai/model-policy")
def ai_model_policy():
    return local_ai_policy()


@router.post("/ai/route")
def ai_route(request: AiRouteRequest):
    return local_ai_route(request.task_kind, request.reasoning_level)


@router.post("/ai/complete")
async def ai_complete(request: AiCompleteRequest):
    if not request.prompt.strip():
        raise HTTPException(status_code=400, detail="Ask a question first.")
    try:
        return local_ai_complete(request.prompt, request.task_kind, request.reasoning_level)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


@router.post("/audit/{iteration}")
def audit(iteration: int):
    return audit_delivery(iteration)


@router.post("/shutdown")
async def personal_finance_shutdown(request: Request):
    """Stop THIS instance, authenticated by its per-launch token.

    Disabled unless CKPF_STOP_TOKEN_FILE was set at launch (returns 404).
    A wrong or missing token gets 403 and nothing happens - fail-closed.
    """
    import hmac
    import os
    import threading
    from app.config import get_stop_token
    expected = get_stop_token()
    if expected is None:
        raise HTTPException(status_code=404, detail="Not found")
    provided = request.headers.get("x-ckpf-stop-token", "")
    if not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=403, detail="Stop token does not match this instance.")
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {"stopping": True}


@router.get("/health")
def personal_finance_health():
    try:
        snapshot = get_persistence_snapshot()
    except Exception:
        raise HTTPException(status_code=503, detail="Local SQLite storage is unavailable.")
    return {"status": "ok", "product": "CK Personal Finance", "store": snapshot["store"],
            "demo_data": snapshot["demo_data"]["present"], "data_classification": snapshot["demo_data"]["classification"], "search": "text"}

# --- Demo data visibility: soft-hide/show synthetic SAMPLE rows (reversible, id-preserving) ---
import sqlite3 as _demo_sqlite3

from app.config import DATA_DIR as _DEMO_DATA_DIR

_DEMO_TABLES = {
    "personal_account_groups": "source_state = 'synthetic_demo'",
    "savings_goals": "name LIKE 'SAMPLE %'",
    "debt_plans": "name LIKE 'SAMPLE %'",
    "finance_reminders": "source_ref = 'synthetic_demo'",
}


def _demo_conn():
    conn = _demo_sqlite3.connect(_DEMO_DATA_DIR / "personal-finance.sqlite3", timeout=10)
    conn.row_factory = _demo_sqlite3.Row
    for _t in _DEMO_TABLES:
        try:
            conn.execute("ALTER TABLE " + _t + " ADD COLUMN demo_hidden INTEGER NOT NULL DEFAULT 0")
        except Exception:
            pass
    return conn


@router.get("/demo/visibility")
def demo_visibility():
    conn = _demo_conn()
    try:
        counts = {t: conn.execute("SELECT COUNT(*) c FROM " + t + " WHERE " + w + " AND COALESCE(demo_hidden,0)=0").fetchone()["c"] for t, w in _DEMO_TABLES.items()}
        hidden = {t: conn.execute("SELECT COUNT(*) c FROM " + t + " WHERE " + w + " AND COALESCE(demo_hidden,0)=1").fetchone()["c"] for t, w in _DEMO_TABLES.items()}
        prof = conn.execute("SELECT demo_data FROM personal_profiles ORDER BY id LIMIT 1").fetchone()
        return {
            "demo_visible": any(counts.values()) or bool(prof and prof["demo_data"]),
            "demo_rows": counts,
            "hidden_rows": hidden,
            "restore_available": any(hidden.values()),
        }
    finally:
        conn.close()


@router.post("/demo/hide")
def demo_hide():
    conn = _demo_conn()
    try:
        try:
            attached = conn.execute(
                "SELECT COUNT(*) c FROM personal_transactions t JOIN personal_account_groups g ON g.id = t.account_group_id WHERE g.source_state = 'synthetic_demo'"
            ).fetchone()["c"]
        except Exception:
            attached = 0
        if attached:
            raise HTTPException(status_code=409, detail="%d imported transaction(s) are attached to SAMPLE accounts. Undo those imports (Import panel, Undo last import) or re-import into a new typed account name before hiding demo data, or they will be hidden with the demo." % attached)
        with conn:
            counts = {}
            for t, w in _DEMO_TABLES.items():
                cur = conn.execute("UPDATE " + t + " SET demo_hidden = 1 WHERE " + w + " AND COALESCE(demo_hidden,0)=0")
                counts[t] = cur.rowcount
            conn.execute("UPDATE personal_profiles SET demo_data = 0 WHERE demo_data = 1")
            conn.execute("UPDATE personal_profiles SET name = 'Local user' WHERE name = 'SAMPLE Household (synthetic)'")
        return {"demo_visible": False, "hidden_rows": counts, "restore": "POST /api/personal-finance/demo/show",
                "note": "Rows are flagged hidden in place, never deleted; ids and values are preserved."}
    finally:
        conn.close()


@router.post("/demo/show")
def demo_show():
    conn = _demo_conn()
    try:
        with conn:
            restored = {}
            for t in _DEMO_TABLES:
                cur = conn.execute("UPDATE " + t + " SET demo_hidden = 0 WHERE COALESCE(demo_hidden,0)=1")
                restored[t] = cur.rowcount
            conn.execute("UPDATE personal_profiles SET demo_data = 1 WHERE demo_data = 0")
            if any(restored.values()):
                conn.execute("UPDATE personal_profiles SET name = 'SAMPLE Household (synthetic)' WHERE name = 'Local user'")
        return {"demo_visible": True, "restored_rows": restored, "note": "The same rows are shown again with their original ids."}
    finally:
        conn.close()


# --- Bank statement import: preview/confirm/undo, categories, transactions list ---
from app.services.statement_import import (
    build_preview,
    confirm_import,
    delete_empty_account,
    init_import_store,
    list_transactions,
    undo_last_import,
    update_category,
)


class ImportPreviewRequest(BaseModel):
    account_id: int | None = None
    new_account_name: str | None = None



# --- W1 insights: merchant aliases + refund trackers (local-only writes) ---
from app.services.insights import (
    add_refund_tracker,
    list_merchant_aliases,
    resolve_refund_tracker,
    set_merchant_alias,
)


class MerchantAliasRequest(BaseModel):
    merchant_key: str
    alias: str = ""


class RefundTrackerRequest(BaseModel):
    merchant: str
    amount: float
    expected_date: str
    note: str = ""


class RefundResolveRequest(BaseModel):
    status: str = "received"


@router.post("/merchants/alias")
def merchant_alias(req: MerchantAliasRequest):
    try:
        return set_merchant_alias(req.merchant_key, req.alias)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/merchants/aliases")
def merchant_aliases():
    return {"aliases": list_merchant_aliases()}


@router.post("/refunds")
def refund_create(req: RefundTrackerRequest):
    try:
        return add_refund_tracker(req.merchant, req.amount, req.expected_date, req.note)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/refunds/{tracker_id}/resolve")
def refund_resolve(tracker_id: int, req: RefundResolveRequest):
    try:
        return resolve_refund_tracker(tracker_id, req.status)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class ImportConfirmRequest(BaseModel):
    token: str
    category_overrides: dict | None = None


class CategoryUpdateRequest(BaseModel):
    category: str


@router.post("/import/preview")
async def import_preview(file: UploadFile = File(...), account_id: int | None = None, new_account_name: str | None = None):
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file was empty.")
    try:
        return build_preview(data, file.filename or "statement", account_id, new_account_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/import/confirm")
def import_confirm(request: ImportConfirmRequest):
    try:
        return confirm_import(request.token, request.category_overrides)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/accounts/{account_id}")
def delete_account(account_id: int):
    try:
        return delete_empty_account(account_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/import/undo")
def import_undo():
    try:
        return undo_last_import()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/transactions")
def transactions_list(account_id: int | None = None, limit: int = 100):
    return list_transactions(account_id, min(limit, 500))


@router.patch("/transactions/{tx_id}/category")
def transaction_category(tx_id: int, request: CategoryUpdateRequest):
    try:
        return update_category(tx_id, request.category)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# --- Approved 25 Oct 2026: bills register (option-A ordering), local bill OCR,
# --- custom report picker. Each module has its own suite in tests/w2_suite.py.
from app.services.bills import (
    add_bill,
    adopt_recurring,
    delete_bill,
    get_bill,
    init_bills_store,
    list_bills,
    mark_paid,
    mark_unpaid,
    recurring_suggestions,
    update_bill,
)
from app.services.bill_ocr import (
    confirm_extraction,
    create_extraction,
    discard_extraction,
    get_extraction,
    init_ocr_store,
    list_extractions,
    ocr_available,
)
from app.services.custom_reports import (
    custom_report_csv,
    custom_report_pdf,
    drilldown_custom_report,
    fields_catalog,
    run_custom_report,
)


class BillCreateRequest(BaseModel):
    vendor: str
    amount: float | None = None
    due_date: str
    note: str = ""


class BillUpdateRequest(BaseModel):
    vendor: str | None = None
    amount: float | None = None
    due_date: str | None = None
    note: str | None = None
    clear_amount: bool = False


class BillAdoptRequest(BaseModel):
    source_ref: str
    vendor: str | None = None
    amount: float | None = None
    due_date: str | None = None


class OcrConfirmRequest(BaseModel):
    vendor: str
    amount: float | None = None
    due_date: str
    note: str = ""


class CustomReportRequest(BaseModel):
    dimension: str = "category"
    measures: list[str] | None = None
    filters: dict | None = None


class CustomReportDrilldownRequest(BaseModel):
    dimension: str = "category"
    measures: list[str] | None = None
    filters: dict | None = None
    bucket: str
    limit: int = 200


@router.get("/bills")
def bills_list(include_paid: bool = True):
    init_bills_store()
    return list_bills(include_paid)


@router.get("/bills/due")
def bills_due():
    """The one 'what's due' view, sorted by due date. Organisation only."""
    init_bills_store()
    result = list_bills(include_paid=False)
    result["title"] = "What is due"
    return result


@router.post("/bills")
def bills_create(request: BillCreateRequest):
    init_bills_store()
    try:
        return add_bill(request.vendor, request.amount, request.due_date,
                        source="manual", note=request.note)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/bills/suggestions")
def bills_suggestions():
    init_bills_store()
    return recurring_suggestions()


@router.post("/bills/adopt")
def bills_adopt(request: BillAdoptRequest):
    init_bills_store()
    try:
        return adopt_recurring(request.source_ref, request.vendor, request.amount, request.due_date)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/bills/{bill_id}")
def bills_get(bill_id: int):
    init_bills_store()
    try:
        return get_bill(bill_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.patch("/bills/{bill_id}")
def bills_update(bill_id: int, request: BillUpdateRequest):
    init_bills_store()
    try:
        return update_bill(bill_id, request.vendor, request.amount, request.due_date,
                           request.note, request.clear_amount)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/bills/{bill_id}/paid")
def bills_paid(bill_id: int):
    init_bills_store()
    try:
        return mark_paid(bill_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/bills/{bill_id}/reopen")
def bills_reopen(bill_id: int):
    init_bills_store()
    try:
        return mark_unpaid(bill_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/bills/{bill_id}")
def bills_delete(bill_id: int):
    init_bills_store()
    try:
        return delete_bill(bill_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/ocr/status")
def ocr_status():
    return ocr_available()


@router.post("/ocr/extract")
async def ocr_extract(file: UploadFile = File(...)):
    data = await file.read()
    try:
        return create_extraction(data, file.filename or "scan", file.content_type)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/ocr/extractions")
def ocr_list(limit: int = 20):
    return list_extractions(limit)


@router.get("/ocr/extractions/{extraction_id}")
def ocr_get(extraction_id: int):
    try:
        return get_extraction(extraction_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/ocr/extractions/{extraction_id}/confirm")
def ocr_confirm(extraction_id: int, request: OcrConfirmRequest):
    try:
        return confirm_extraction(extraction_id, request.vendor, request.amount,
                                  request.due_date, request.note)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/ocr/extractions/{extraction_id}/discard")
def ocr_discard(extraction_id: int):
    try:
        return discard_extraction(extraction_id)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/reports/custom/fields")
def custom_report_fields():
    return fields_catalog()


@router.post("/reports/custom/run")
def custom_report_run(request: CustomReportRequest):
    spec = {"dimension": request.dimension, "measures": request.measures or ["total_spent", "count"],
            "filters": request.filters or {}}
    try:
        return run_custom_report(spec)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/reports/custom/drilldown")
def custom_report_drilldown(request: CustomReportDrilldownRequest):
    spec = {"dimension": request.dimension, "measures": request.measures or ["total_spent", "count"],
            "filters": request.filters or {}}
    try:
        return drilldown_custom_report(spec, request.bucket, request.limit)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/reports/custom/export.csv")
def custom_report_export_csv(request: CustomReportRequest):
    from fastapi.responses import Response
    spec = {"dimension": request.dimension, "measures": request.measures or ["total_spent", "count"],
            "filters": request.filters or {}}
    try:
        csv_text = custom_report_csv(spec)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return Response(content=csv_text, media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=ck-custom-report.csv"})


@router.post("/reports/custom/export.pdf")
def custom_report_export_pdf(request: CustomReportRequest):
    from fastapi.responses import Response
    spec = {"dimension": request.dimension, "measures": request.measures or ["total_spent", "count"],
            "filters": request.filters or {}}
    try:
        pdf_bytes = custom_report_pdf(spec)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": "attachment; filename=ck-custom-report.pdf"})
