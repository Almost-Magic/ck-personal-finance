"""The Ledger â€” AI Accountant for Almost Magic Tech Lab.

Author: Mani Padisetti
Organisation: Almost Magic Tech Lab
Licence: PROPRIETARY
"""

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pathlib import Path
import os

from app.config import PORT, init_data_dir
from app.database import init_db
from app.services.finance_suite import load_state
from app.services.personal_finance_store import init_personal_finance_store
from app.routes import health, accounts, transactions, journals, reports, periods, adjustments, tax, narrative, imports, analytics, export, personal_finance, finance_suite

app = FastAPI(
    title="The Ledger",
    description="AI Accountant â€” Financial Intelligence for Almost Magic Tech Lab",
    version="1.0.0",
)


@app.on_event("startup")
async def startup():
    init_data_dir()
    init_db()
    init_personal_finance_store()
    load_state()
    from app.config import get_stop_token
    get_stop_token()  # writes the instance stop-token file when enabled
    max_run = int(os.environ.get("CKPF_MAX_RUN_SECONDS", "0") or 0)
    if max_run > 0:
        import asyncio

        async def _deadline():
            await asyncio.sleep(max_run)
            print("CKPF: run deadline reached (%ss), stopping." % max_run, flush=True)
            os._exit(0)

        asyncio.create_task(_deadline())


app.include_router(health.router, prefix="/api")
app.include_router(accounts.router, prefix="/api")
app.include_router(transactions.router, prefix="/api")
app.include_router(journals.router, prefix="/api")
app.include_router(reports.router, prefix="/api")
app.include_router(periods.router, prefix="/api")
app.include_router(adjustments.router, prefix="/api")
app.include_router(tax.router, prefix="/api")
app.include_router(narrative.router, prefix="/api")
app.include_router(imports.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(export.router, prefix="/api")
app.include_router(personal_finance.router, prefix="/api")
app.include_router(finance_suite.router)

public_dir = Path(__file__).parent / "public"
if public_dir.exists():
    app.mount("/static", StaticFiles(directory=str(public_dir)), name="static")


@app.api_route("/{full_path:path}", methods=["GET"])
async def spa_fallback(request: Request, full_path: str):
    if full_path.startswith("api/"):
        return JSONResponse(status_code=404, content={"error": "Not found"})
    index = public_dir / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return JSONResponse({"message": "The Ledger API", "docs": "/docs"})


@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=503, content={"error": "The local service could not complete this request. Check the database and try again."})




@app.middleware("http")
async def no_cache_dynamic(request: Request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path.startswith("/api/") or path == "/" or path.endswith(".html"):
        response.headers["Cache-Control"] = "no-cache"
    return response


@app.middleware("http")
async def demo_scope(request: Request, call_next):
    if os.environ.get("PF_DEMO_MODE") == "1":
        path = request.url.path
        outside_api_scope = path.startswith("/api/") and not (path.startswith("/api/personal-finance/") or path == "/api/health")
        if outside_api_scope or path == "/finance" or path.startswith("/finance/"):
            return JSONResponse(status_code=403, content={"detail": "Only CK Personal Finance is available in this demo."})
    return await call_next(request)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=PORT, reload=False)
