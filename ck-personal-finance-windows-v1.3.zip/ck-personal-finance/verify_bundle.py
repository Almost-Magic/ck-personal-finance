"""Recompute every sha256 in BUNDLE-MANIFEST.txt against the files next to it.

Run with the bundled runtime (double-click Verify-Bundle.bat) or any Python 3.
Prints BUNDLE VERIFIED when every listed file matches and every shipped file
(except the manifest itself) is listed.
"""
import hashlib
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
MANIFEST = os.path.join(ROOT, "BUNDLE-MANIFEST.txt")
SKIP = {"BUNDLE-MANIFEST.txt"}

bad = []
seen = set()
for line in open(MANIFEST, encoding="utf-8"):
    line = line.rstrip("\n")
    if not line.strip():
        continue
    parts = line.split("  ", 1)
    if len(parts) != 2 or len(parts[0]) != 64:
        bad.append(("malformed line", line[:80]))
        continue
    want, rel = parts
    if rel.startswith(("/", "./")) or ".." in rel.split("/") or rel in SKIP:
        bad.append(("bad path", rel))
        continue
    seen.add(rel)
    path = os.path.join(ROOT, *rel.split("/"))
    if not os.path.isfile(path):
        bad.append(("missing file", rel))
        continue
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != want:
        bad.append(("HASH MISMATCH", rel))

for base, dirs, files in os.walk(ROOT):
    dirs.sort()
    for f in sorted(files):
        rel = os.path.relpath(os.path.join(base, f), ROOT).replace(os.sep, "/")
        if rel not in SKIP and rel not in seen:
            bad.append(("not listed in manifest", rel))

if bad:
    for kind, rel in bad[:20]:
        print("FAIL", kind, rel)
    print("BUNDLE VERIFICATION FAILED: %d problem(s)" % len(bad))
    sys.exit(1)
print("BUNDLE VERIFIED: all %d listed files match BUNDLE-MANIFEST.txt" % len(seen))
