@echo off
cd /d "%~dp0"
title CK Personal Finance - keep this window open while you use the app
set "CKPF_DATA_DIR=%~dp0data"
set "PORT=5002"
set "PF_DEMO_MODE=1"
set "CKPF_MAX_RUN_SECONDS=7200"
set "CKPF_STOP_TOKEN_FILE=%~dp0data\shutdown.token"
if not exist "%~dp0data" mkdir "%~dp0data"
"%~dp0runtime\python\ck-ledger.exe" "%~dp0wait_stopped.py" check
if errorlevel 1 (
  echo Port 5002 is already in use. Close the other program or stop it, then try again.
  echo Refusing to launch over another listener.
  pause
  exit /b 1
)
if exist "%CKPF_STOP_TOKEN_FILE%" del /f "%CKPF_STOP_TOKEN_FILE%" >nul 2>&1
start "" /min "%~dp0runtime\python\ck-ledger.exe" "%~dp0open-browser.py"
"%~dp0runtime\python\ck-ledger.exe" server.py
