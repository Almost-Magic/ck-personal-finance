"""Synthetic SAMPLE data only. Fictional household. Idempotent."""
import sqlite3, sys
c = sqlite3.connect(sys.argv[1])
if c.execute("select count(*) from personal_profiles where demo_data=1").fetchone()[0]:
    print("already seeded"); sys.exit(0)
if c.execute("select count(*) from personal_account_groups").fetchone()[0]:
    print("refusing: store has non-demo rows"); sys.exit(1)
c.execute("update personal_profiles set name=?, demo_data=1 where id=(select min(id) from personal_profiles)", ("SAMPLE Household (synthetic)",))
p = c.execute("select id from personal_profiles where demo_data=1").fetchone()[0]
ins = lambda sql, rows: c.executemany(sql, [(p,)+r for r in rows])
ins("insert into personal_account_groups(profile_id,name,group_type,current_balance,source_state) values(?,?,?,?,?)",
    [("SAMPLE Everyday account","transaction",3250.40,"synthetic_demo"),("SAMPLE Savings","savings",12800.00,"synthetic_demo"),("SAMPLE Credit card","credit",-1460.25,"synthetic_demo")])
ins("insert into savings_goals(profile_id,name,target_amount,saved_amount,target_date,status) values(?,?,?,?,?,?)",
    [("SAMPLE Emergency fund",15000,9000,"2027-06-30","tracking"),("SAMPLE Holiday",4000,1200,"2027-03-31","tracking")])
ins("insert into debt_plans(profile_id,name,current_balance,repayment_amount,repayment_frequency,interest_rate,status) values(?,?,?,?,?,?,?)",
    [("SAMPLE Credit card",1460.25,250,"monthly",19.9,"tracking"),("SAMPLE Car loan",8400,310,"monthly",7.2,"tracking")])
ins("insert into finance_reminders(profile_id,title,due_date,cadence,lead_days,status,source_ref) values(?,?,?,?,?,?,?)",
    [("SAMPLE Car registration","2026-12-15","yearly",14,"scheduled","synthetic_demo"),("SAMPLE Insurance renewal","2027-01-20","yearly",21,"scheduled","synthetic_demo")])
c.commit(); print("seeded profile", p)
