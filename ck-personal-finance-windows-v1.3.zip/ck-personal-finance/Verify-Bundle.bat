@echo off
cd /d "%~dp0"
"%~dp0runtime\python\ck-ledger.exe" "%~dp0verify_bundle.py"
pause
