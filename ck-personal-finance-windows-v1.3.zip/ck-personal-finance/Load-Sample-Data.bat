@echo off
cd /d "%~dp0"
set "CKPF_DATA_DIR=%~dp0data"
"%~dp0runtime\python\ck-ledger.exe" -c "from app.config import init_data_dir; from app.database import init_db; from app.services.personal_finance_store import init_personal_finance_store; init_data_dir(); init_db(); init_personal_finance_store(); import runpy, sys; sys.argv = ['seed_demo.py', r'%~dp0data\personal-finance.sqlite3']; runpy.run_path('seed_demo.py', run_name='__main__')"
pause
