@echo off
cd /d "%~dp0"
set "PY=%~dp0runtime\python\ck-ledger.exe"

"%PY%" "%~dp0wait_stopped.py" check
if %errorlevel%==0 goto CONFIRM

if not exist "%~dp0data\shutdown.token" goto RUNNING
set /p TOKEN=<"%~dp0data\shutdown.token"
for /f %%C in ('curl.exe -s -o nul -w "%%{http_code}" -X POST -H "X-CKPF-Stop-Token: %TOKEN%" http://127.0.0.1:5002/api/personal-finance/shutdown 2^>nul') do set "CODE=%%C"
if not "%CODE%"=="200" goto RUNNING
"%PY%" "%~dp0wait_stopped.py" wait
"%PY%" "%~dp0wait_stopped.py" check
if %errorlevel%==0 goto CONFIRM

:RUNNING
echo The app is still running, so nothing was deleted.
echo Close the "CK Personal Finance" window first, then run this file again.
pause
exit /b 1

:CONFIRM
set /p "SURE=This deletes ALL your CK Personal Finance records in the data folder. Type YES to confirm: "
if /i "%SURE%"=="YES" (rmdir /s /q "%~dp0data" && echo Data folder removed.) else (echo Cancelled - nothing was deleted.)
pause
