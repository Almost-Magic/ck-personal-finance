"""Check readiness against the local launch token, then open the browser.

This protects against accidental port conflicts, not hostile local programs.
The free-port check and server bind are not atomic. The token is sent to
whichever local program wins the port, so it is not a local adversary boundary.

Started minimised by Start-Ledger.bat. Self-terminating: it either opens the
browser and exits 0, or gives up after 30 seconds and exits 1. It never keeps
running in the background.
"""
import json
import os
import time
import urllib.request
import webbrowser

APP_URL = "http://127.0.0.1:5002"
TOKEN_FILE = os.environ.get("CKPF_STOP_TOKEN_FILE",
                            os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "data", "shutdown.token"))


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _read_token(token_file):
    try:
        with open(token_file, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return None


def ready(token_file, base_url=APP_URL):
    """True only when the instance at base_url answers the launch-identity
    probe with this launch's exact token and the exact readiness body."""
    token = _read_token(token_file)
    if not token:
        return False
    req = urllib.request.Request(base_url + "/api/personal-finance/launch-identity",
                                 headers={"X-CKPF-Stop-Token": token})
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            body = resp.read(2049)
            if len(body) > 2048:
                return False
            data = json.loads(body, object_pairs_hook=unique_object)
            return (resp.status == 200 and type(data) is dict
                    and set(data) == {"product", "ready"}
                    and type(data["product"]) is str
                    and data["product"] == "CK Personal Finance"
                    and data["ready"] is True)
    except Exception:
        return False


def main():
    deadline = time.time() + 30
    while time.time() < deadline:
        if ready(TOKEN_FILE):
            webbrowser.open(APP_URL)
            return 0
        time.sleep(0.5)
    print("The app did not confirm its launch identity within 30 seconds.")
    time.sleep(8)
    raise SystemExit(1)


if __name__ == "__main__":
    main()
