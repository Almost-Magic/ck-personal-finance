CK PERSONAL FINANCE
A free personal finance tool from Almost Magic Tech Lab Pty Ltd
Version 1.0

WHAT THIS IS
CK Personal Finance helps you keep track of your money on your own computer: bring in your transactions, sort them, and see where your money goes. It is a record-keeping and planning tool. It is not financial, tax, legal or investment advice. See DISCLAIMER below.

WHAT YOU NEED
- A Windows 10 or Windows 11 computer (64-bit).
- About 300 MB of free disk space.
- Nothing else to install. Python is included in this folder.
- No internet connection is needed to use it.
- Bill OCR scanning uses the bundled Tesseract engine (a controlled
  PNG-only build) and the bundled PDFium renderer; no separate install.
  The Ask feature needs Ollama and a model you download yourself; it is
  NOT included in this download and never installed for you.

START IT
1. Unzip the whole folder somewhere you keep your files, for example your Documents folder. Do not run it from inside the zip.
2. Open the folder and double-click Start-Ledger.bat.
3. A black window opens and, after a few seconds, your web browser opens the app at http://127.0.0.1:5002. That address works only on your own computer.
4. Keep the black window open while you use the app - that window IS the app. To stop the app, close the window or double-click Stop-Ledger.bat. Stop-Ledger.bat ends the app and confirms that nothing is left running.
5. The app also stops itself after 2 hours. That is a built-in safety limit so it can never be left running by accident. Double-click Start-Ledger.bat again whenever you want to continue - everything you entered is kept.

If Windows shows a blue "Windows protected your PC" box the first time: this happens with any program that is not from a large publisher. Do not continue past it automatically. First check the download with Verify-Bundle.bat (see CHECK THE DOWNLOAD below) and make sure you downloaded it from our page. Only if the bundle verifies, click More info, then Run anyway. If your firewall asks about network access, you can choose Cancel; the app does not need it.

CHECK THE DOWNLOAD (OPTIONAL)
Double-click Verify-Bundle.bat. It checks every file in the folder against BUNDLE-MANIFEST.txt (the list of checksums we shipped) and prints BUNDLE VERIFIED if everything matches.

WHERE YOUR DATA LIVES
Everything you enter is saved in the folder named data, next to Start-Ledger.bat. To back up, copy that folder somewhere safe. To move to a new computer, copy the whole folder.
Deleting the data folder deletes your records. There is no copy anywhere else.

YOUR PRIVACY
Your information stays on your computer. We never receive it, and the app does not send it anywhere. There are no accounts, no sign-up and no tracking.

WHAT IT DOES NOT DO
It does not connect to your bank. It does not use online AI services. It does not move money.

REMOVE IT
Double-click Stop-Ledger.bat (or close the black window), then delete the folder. That removes the app and your data. To delete only your records and keep the app, double-click Remove-Data.bat.

LICENCE AND TERMS
This is free to use. The program code remains the property of Almost Magic Tech Lab Pty Ltd and is not open source. Read LICENCE.txt, TERMS.txt and PRIVACY.txt in this folder for the full wording. Governing law: New South Wales, Australia.

DISCLAIMER
CK Personal Finance is provided as is. Figures, categories and projections are only as good as the information you enter. It is not financial advice. Speak to a licensed adviser, accountant or tax agent before making financial or tax decisions. To the extent the law allows, we are not liable for losses from using it. Nothing here limits rights you have under the Australian Consumer Law that cannot be excluded.

HELP
Email advisory@almostmagic.net.au. We will do our best to reply, but this free tool does not come with a support guarantee.

Almost Magic Tech Lab Pty Ltd, ABN 38 689 272 731
Unit 17, 206-212 Great Western Highway, Kingswood NSW 2747

OCR trust boundary: the packaged engine/model/DLLs must be present and regular
files; a broken bundle fails loudly rather than silently switching engines.
In source/development mode ONLY, if runtime/ocr is wholly absent, OCR uses the
Tesseract found on PATH. That installed program is trusted as local software,
not hash-verified by CK. Do not use an untrusted PATH or modified runtime.
