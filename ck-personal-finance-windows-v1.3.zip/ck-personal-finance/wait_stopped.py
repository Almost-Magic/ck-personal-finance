"""Confirm the app has stopped: is anything still listening on its port?

  wait_stopped.py check  - exit 0 if the port is free now, 1 if occupied
  wait_stopped.py wait   - poll up to 15 seconds, exit 0 once free, 1 on timeout

Nothing is killed here. This only OBSERVES, so a wrong answer can never
harm another program. Used by Stop-Ledger.bat and Remove-Data.bat.
"""
import socket
import sys
import time

PORT = 5002


def listening():
    s = socket.socket()
    try:
        return s.connect_ex(("127.0.0.1", PORT)) == 0
    finally:
        s.close()


mode = sys.argv[1] if len(sys.argv) > 1 else "wait"
if mode == "check":
    sys.exit(1 if listening() else 0)
deadline = time.time() + 15
while time.time() < deadline:
    if not listening():
        sys.exit(0)
    time.sleep(0.5)
sys.exit(1)
